'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Layers, PenTool, Image as ImageIcon, FileText, BarChart3, Lock, Zap, Smartphone } from 'lucide-react'

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Layers className="h-5 w-5" />
            </div>
            <span className="text-xl font-bold">No-Code CMS</span>
          </div>
          <Button asChild>
            <Link href="/admin/login">
              <Lock className="mr-2 h-4 w-4" />
              Admin Login
            </Link>
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <h1 className="text-5xl font-bold tracking-tight sm:text-6xl mb-6">
          Build Beautiful Websites
          <span className="block text-primary">Without Coding</span>
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
          A powerful, intuitive content management system that lets you create, manage, and publish
          stunning websites with ease.
        </p>
        <div className="flex gap-4 justify-center">
          <Button size="lg" asChild>
            <Link href="/admin/login">
              Get Started
            </Link>
          </Button>
          <Button size="lg" variant="outline" asChild>
            <a href="#features">
              Learn More
            </a>
          </Button>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="container mx-auto px-4 py-20">
        <h2 className="text-3xl font-bold text-center mb-12">Everything You Need</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <PenTool className="h-10 w-10 text-primary mb-2" />
              <CardTitle>Intuitive Editor</CardTitle>
              <CardDescription>
                Create and edit content with our modern, user-friendly rich text editor
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <FileText className="h-10 w-10 text-primary mb-2" />
              <CardTitle>Page Management</CardTitle>
              <CardDescription>
                Easily create, organize, and publish pages with full SEO control
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <Layers className="h-10 w-10 text-primary mb-2" />
              <CardTitle>Blog System</CardTitle>
              <CardDescription>
                Built-in blogging with categories, tags, and comment management
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <ImageIcon className="h-10 w-10 text-primary mb-2" />
              <CardTitle>Media Library</CardTitle>
              <CardDescription>
                Upload and manage images, videos, and documents with ease
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <BarChart3 className="h-10 w-10 text-primary mb-2" />
              <CardTitle>Analytics Dashboard</CardTitle>
              <CardDescription>
                Track your site's performance with detailed insights and metrics
              </CardDescription>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader>
              <Smartphone className="h-10 w-10 text-primary mb-2" />
              <CardTitle>Responsive Design</CardTitle>
              <CardDescription>
                Every page looks great on any device with mobile-first approach
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="container mx-auto px-4 py-20 bg-muted/30 rounded-3xl my-12">
        <h2 className="text-3xl font-bold text-center mb-12">Why Choose No-Code CMS?</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="text-center">
            <Zap className="h-12 w-12 text-primary mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">Lightning Fast</h3>
            <p className="text-muted-foreground">
              Built on Next.js for optimal performance and SEO
            </p>
          </div>
          <div className="text-center">
            <Lock className="h-12 w-12 text-primary mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">Secure & Reliable</h3>
            <p className="text-muted-foreground">
              Enterprise-grade security with role-based access control
            </p>
          </div>
          <div className="text-center">
            <Smartphone className="h-12 w-12 text-primary mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">User Friendly</h3>
            <p className="text-muted-foreground">
              Designed for non-technical users with modern UI
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <Card className="max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle className="text-3xl">Ready to Get Started?</CardTitle>
            <CardDescription className="text-base">
              Join thousands of users who have built their websites with No-Code CMS
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button size="lg" asChild>
              <Link href="/admin/login">
                Start Building Today
              </Link>
            </Button>
          </CardContent>
        </Card>
      </section>

      {/* Footer */}
      <footer className="border-t mt-20">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                <Layers className="h-5 w-5" />
              </div>
              <span className="font-semibold">No-Code CMS</span>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2024 No-Code CMS. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
