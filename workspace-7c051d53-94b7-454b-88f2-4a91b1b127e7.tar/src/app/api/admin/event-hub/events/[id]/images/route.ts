import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

// POST /api/admin/event-hub/events/[id]/images - Add event image (P1)
export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || (session.user as any).role !== 'admin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await req.json()
    const { url, alt, caption, position } = body

    if (!url) {
      return NextResponse.json({ error: 'Image URL is required' }, { status: 400 })
    }

    // Verify event exists
    const event = await db.event.findUnique({
      where: { id: params.id },
    })

    if (!event) {
      return NextResponse.json({ error: 'Event not found' }, { status: 404 })
    }

    // Create event image
    const image = await db.eventImage.create({
      data: {
        url,
        alt,
        caption,
        position: position || 0,
        eventId: params.id,
      },
    })

    return NextResponse.json(image, { status: 201 })
  } catch (error) {
    console.error('Error creating event image:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// PUT /api/admin/event-hub/events/[id]/images/[imageId] - Update event image (P1)
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string; imageId: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || (session.user as any).role !== 'admin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await req.json()
    const { url, alt, caption, position } = body

    // Update image
    const image = await db.eventImage.update({
      where: {
        id: params.imageId,
        eventId: params.id,
      },
      data: {
        url,
        alt,
        caption,
        position: position || 0,
      },
    })

    return NextResponse.json(image)
  } catch (error) {
    console.error('Error updating event image:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// DELETE /api/admin/event-hub/events/[id]/images/[imageId] - Delete event image (P1)
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string; imageId: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || (session.user as any).role !== 'admin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Delete image
    await db.eventImage.delete({
      where: {
        id: params.imageId,
        eventId: params.id,
      },
    })

    return NextResponse.json({ message: 'Event image deleted successfully' })
  } catch (error) {
    console.error('Error deleting event image:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
