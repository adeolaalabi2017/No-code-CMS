import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

// GET /api/admin/event-hub/events - Get all events
export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const status = searchParams.get('status')
    const search = searchParams.get('search')

    const where: any = {}
    if (status) {
      where.status = status
    }
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
        { location: { contains: search, mode: 'insensitive' } },
      ]
    }

    const events = await db.event.findMany({
      where,
      include: {
        _count: {
          select: {
            tickets: true,
          },
        },
        tickets: {
          select: {
            id: true,
            name: true,
            email: true,
            quantity: true,
          },
          orderBy: { createdAt: 'desc' },
          take: 5,
        },
      },
      orderBy: [
        { date: 'asc' },
        { createdAt: 'desc' },
      ],
    })

    return NextResponse.json(events)
  } catch (error) {
    console.error('Error fetching events:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// POST /api/admin/event-hub/events - Create a new event
export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await req.json()
    const { name, slug, description, date, time, location, price, capacity, status } = body

    if (!name || !slug || !date) {
      return NextResponse.json({ error: 'Name, slug, and date are required' }, { status: 400 })
    }

    const event = await db.event.create({
      data: {
        name,
        slug,
        description,
        date: new Date(date),
        time,
        location,
        price: price ? parseFloat(price) : null,
        capacity: capacity ? parseInt(capacity) : null,
        status: status || 'upcoming',
      },
      include: {
        _count: {
          select: {
            tickets: true,
          },
        },
        tickets: {
          select: {
            id: true,
            name: true,
            email: true,
            quantity: true,
          },
        },
      },
    })

    return NextResponse.json(event, { status: 201 })
  } catch (error) {
    console.error('Error creating event:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
