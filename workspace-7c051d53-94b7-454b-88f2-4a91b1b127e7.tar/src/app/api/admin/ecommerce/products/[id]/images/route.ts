import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

// POST /api/admin/ecommerce/products/[id]/images - Add product image (P1)
export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || (session.user as any).role !== 'admin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await req.json()
    const { url, alt, caption, position } = body

    if (!url) {
      return NextResponse.json({ error: 'Image URL is required' }, { status: 400 })
    }

    // Verify product exists
    const product = await db.product.findUnique({
      where: { id: params.id },
    })

    if (!product) {
      return NextResponse.json({ error: 'Product not found' }, { status: 404 })
    }

    // Create product image
    const image = await db.productImage.create({
      data: {
        url,
        alt,
        caption,
        position: position || 0,
        productId: params.id,
      },
    })

    return NextResponse.json(image, { status: 201 })
  } catch (error) {
    console.error('Error creating product image:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// PUT /api/admin/ecommerce/products/[id]/images/[imageId] - Update product image (P1)
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string; imageId: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || (session.user as any).role !== 'admin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await req.json()
    const { url, alt, caption, position } = body

    // Update image
    const image = await db.productImage.update({
      where: {
        id: params.imageId,
        productId: params.id,
      },
      data: {
        url,
        alt,
        caption,
        position: position || 0,
      },
    })

    return NextResponse.json(image)
  } catch (error) {
    console.error('Error updating product image:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// DELETE /api/admin/ecommerce/products/[id]/images/[imageId] - Delete product image (P1)
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string; imageId: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || (session.user as any).role !== 'admin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Delete image
    await db.productImage.delete({
      where: {
        id: params.imageId,
        productId: params.id,
      },
    })

    return NextResponse.json({ message: 'Product image deleted successfully' })
  } catch (error) {
    console.error('Error deleting product image:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
