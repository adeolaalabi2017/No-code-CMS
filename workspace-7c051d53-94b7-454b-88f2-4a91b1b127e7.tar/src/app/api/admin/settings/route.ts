import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

// GET /api/admin/settings - Get all settings
export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const category = searchParams.get('category')

    const where: any = {}
    if (category) {
      where.category = category
    }

    const settings = await db.setting.findMany({
      where,
      orderBy: { key: 'asc' },
    })

    return NextResponse.json(settings)
  } catch (error) {
    console.error('Error fetching settings:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// POST /api/admin/settings - Create or update settings
export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await req.json()
    const settings = Array.isArray(body) ? body : [body]

    const results = await Promise.all(
      settings.map(async (setting: { key: string; value: string; category: string; description?: string }) => {
        const existing = await db.setting.findUnique({
          where: { key: setting.key },
        })

        if (existing) {
          return db.setting.update({
            where: { key: setting.key },
            data: { value: setting.value },
          })
        } else {
          return db.setting.create({
            data: {
              key: setting.key,
              value: setting.value,
              category: setting.category,
              description: setting.description,
            },
          })
        }
      })
    )

    return NextResponse.json(results)
  } catch (error) {
    console.error('Error saving settings:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
