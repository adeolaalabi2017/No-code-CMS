import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

// GET /api/admin/themes - Get all themes
export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || (session.user as any).role !== 'admin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const type = searchParams.get('type')

    const where: any = {}
    if (type) {
      where.type = type
    }

    const themes = await db.theme.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: {
        _count: {
          select: {
            pages: true,
            posts: true,
            events: true,
            portfolioItems: true,
          },
        },
      },
    })

    return NextResponse.json(themes)
  } catch (error) {
    console.error('Error fetching themes:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// POST /api/admin/themes - Create a new theme
export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || (session.user as any).role !== 'admin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await req.json()
    const { name, slug, type, description, isActive } = body

    if (!name || !slug || !type) {
      return NextResponse.json({ error: 'Name, slug, and type are required' }, { status: 400 })
    }

    const theme = await db.theme.create({
      data: {
        name,
        slug,
        type,
        description,
        isActive: isActive || false,
      },
    })

    return NextResponse.json(theme, { status: 201 })
  } catch (error) {
    console.error('Error creating theme:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
