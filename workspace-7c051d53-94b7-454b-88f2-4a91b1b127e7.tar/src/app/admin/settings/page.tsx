'use client'

import { useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Save, Globe, Mail, Layout, Shield } from 'lucide-react'
import { toast } from 'sonner'

interface Setting {
  id: string
  key: string
  value: string | null
  type: string
  category: string
  description: string | null
}

const defaultSettings = {
  general: [
    { key: 'site_name', label: 'Site Name', type: 'text', placeholder: 'My Awesome Site', description: 'The name of your website' },
    { key: 'site_description', label: 'Site Description', type: 'textarea', placeholder: 'A brief description of your site', description: 'Used for SEO and social sharing' },
    { key: 'site_logo', label: 'Logo URL', type: 'text', placeholder: '/logo.svg', description: 'URL to your site logo' },
  ],
  seo: [
    { key: 'meta_title_template', label: 'Meta Title Template', type: 'text', placeholder: '%title% - %sitename%', description: 'Template for page meta titles' },
    { key: 'meta_description_template', label: 'Meta Description Template', type: 'textarea', placeholder: 'Default meta description', description: 'Template for page meta descriptions' },
    { key: 'google_analytics_id', label: 'Google Analytics ID', type: 'text', placeholder: 'UA-XXXXXXXXX-X', description: 'Your Google Analytics tracking ID' },
  ],
  smtp: [
    { key: 'smtp_host', label: 'SMTP Host', type: 'text', placeholder: 'smtp.example.com', description: 'Your SMTP server hostname' },
    { key: 'smtp_port', label: 'SMTP Port', type: 'text', placeholder: '587', description: 'SMTP server port' },
    { key: 'smtp_user', label: 'SMTP Username', type: 'text', placeholder: 'user@example.com', description: 'SMTP authentication username' },
    { key: 'smtp_password', label: 'SMTP Password', type: 'password', placeholder: '••••••••', description: 'SMTP authentication password' },
    { key: 'smtp_from_email', label: 'From Email', type: 'text', placeholder: 'noreply@example.com', description: 'Default sender email address' },
  ],
}

export default function SettingsPage() {
  const [settings, setSettings] = useState<Setting[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [formData, setFormData] = useState<Record<string, string>>({})

  const fetchSettings = async () => {
    try {
      const response = await fetch('/api/admin/settings')
      if (!response.ok) throw new Error('Failed to fetch settings')
      const data = await response.json()
      setSettings(data)

      // Convert to key-value object
      const dataMap: Record<string, string> = {}
      data.forEach((setting: Setting) => {
        if (setting.value !== null) {
          dataMap[setting.key] = setting.value
        }
      })
      setFormData(dataMap)
    } catch (error) {
      toast.error('Failed to load settings')
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchSettings()
  }, [])

  const handleSave = async (category: string) => {
    setIsSaving(true)
    try {
      const settingsToSave = Object.entries(formData)
        .filter(([key]) => {
          const config = [...defaultSettings.general, ...defaultSettings.seo, ...defaultSettings.smtp]
            .find(s => s.key === key)
          return config !== undefined
        })
        .map(([key, value]) => ({
          key,
          value,
          category,
        }))

      const response = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settingsToSave),
      })

      if (!response.ok) throw new Error('Failed to save settings')

      toast.success('Settings saved successfully')
      fetchSettings()
    } catch (error) {
      toast.error('Failed to save settings')
    } finally {
      setIsSaving(false)
    }
  }

  const renderField = (config: any) => {
    const value = formData[config.key] || ''

    if (config.type === 'textarea') {
      return (
        <Textarea
          value={value}
          onChange={(e) => setFormData({ ...formData, [config.key]: e.target.value })}
          placeholder={config.placeholder}
          disabled={isSaving}
          rows={3}
        />
      )
    }

    if (config.type === 'password') {
      return (
        <Input
          type="password"
          value={value}
          onChange={(e) => setFormData({ ...formData, [config.key]: e.target.value })}
          placeholder={config.placeholder}
          disabled={isSaving}
        />
      )
    }

    return (
      <Input
        type={config.type}
        value={value}
        onChange={(e) => setFormData({ ...formData, [config.key]: e.target.value })}
        placeholder={config.placeholder}
        disabled={isSaving}
      />
    )
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
          <p className="text-muted-foreground">Manage your site configuration</p>
        </div>
        <Card>
          <CardContent className="p-6">
            <div className="space-y-6">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="space-y-2">
                  <div className="h-4 w-32 bg-muted animate-pulse rounded" />
                  <div className="h-10 bg-muted animate-pulse rounded" />
                  <div className="h-3 w-48 bg-muted animate-pulse rounded" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
          <p className="text-muted-foreground">Manage your site configuration</p>
        </div>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList>
          <TabsTrigger value="general">
            <Globe className="mr-2 h-4 w-4" />
            General
          </TabsTrigger>
          <TabsTrigger value="seo">
            <Layout className="mr-2 h-4 w-4" />
            SEO
          </TabsTrigger>
          <TabsTrigger value="smtp">
            <Mail className="mr-2 h-4 w-4" />
            Email
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>Basic site configuration</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {defaultSettings.general.map((config) => (
                <div key={config.key} className="space-y-2">
                  <Label htmlFor={config.key}>{config.label}</Label>
                  {renderField(config)}
                  {config.description && (
                    <p className="text-sm text-muted-foreground">{config.description}</p>
                  )}
                </div>
              ))}
              <div className="flex justify-end pt-4">
                <Button onClick={() => handleSave('general')} disabled={isSaving}>
                  {isSaving ? 'Saving...' : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Save Changes
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="seo">
          <Card>
            <CardHeader>
              <CardTitle>SEO Settings</CardTitle>
              <CardDescription>Search engine optimization configuration</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {defaultSettings.seo.map((config) => (
                <div key={config.key} className="space-y-2">
                  <Label htmlFor={config.key}>{config.label}</Label>
                  {renderField(config)}
                  {config.description && (
                    <p className="text-sm text-muted-foreground">{config.description}</p>
                  )}
                </div>
              ))}
              <div className="flex justify-end pt-4">
                <Button onClick={() => handleSave('seo')} disabled={isSaving}>
                  {isSaving ? 'Saving...' : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Save Changes
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="smtp">
          <Card>
            <CardHeader>
              <CardTitle>Email Configuration</CardTitle>
              <CardDescription>SMTP settings for email delivery</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {defaultSettings.smtp.map((config) => (
                <div key={config.key} className="space-y-2">
                  <Label htmlFor={config.key}>{config.label}</Label>
                  {renderField(config)}
                  {config.description && (
                    <p className="text-sm text-muted-foreground">{config.description}</p>
                  )}
                </div>
              ))}
              <div className="flex justify-end pt-4">
                <Button onClick={() => handleSave('smtp')} disabled={isSaving}>
                  {isSaving ? 'Saving...' : (
                    <>
                      <Save className="mr-2 h-4 w-4" />
                      Save Changes
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
