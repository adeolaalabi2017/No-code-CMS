'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { FolderKanban, Grid, List, MoreHorizontal, Eye, Edit, Trash2, Loader2, Plus, Image as ImageIcon, Upload, Award, Briefcase, Heart, Tag, X } from 'lucide-react'
import { toast } from 'sonner'
import Link from 'next/link'

interface PortfolioImage {
  id: string
  url: string
  alt: string | null
  caption: string | null
  position: number
}

interface PortfolioItem {
  id: string
  title: string
  slug: string
  description: string | null
  type: string
  status: string
  createdAt: string
  publishedAt: string | null
  images: PortfolioImage[]
  tags: {
    tag: {
      id: string
      name: string
      slug: string
    }
  }[]
}

export default function PortfolioPage() {
  const { data: session } = useSession()
  const [items, setItems] = useState<PortfolioItem[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [viewType, setViewType] = useState<'grid' | 'list'>('grid')
  const [typeFilter, setTypeFilter] = useState('all')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isDeletingImage, setIsDeletingImage] = useState<string | null>(null)
  const [imageFormData, setImageFormData] = useState({
    url: '',
    alt: '',
    caption: '',
    position: 0,
  })

  const isAdmin = (session?.user as any)?.role === 'admin'

  const fetchItems = async () => {
    try {
      const response = await fetch('/api/admin/portfolio/items')
      if (!response.ok) throw new Error('Failed to fetch portfolio items')

      const data = await response.json()
      setItems(data)
    } catch (error) {
      console.error('Error fetching portfolio items:', error)
      toast.error('Failed to load portfolio items')
    } finally {
      setIsLoading(false)
    }
  }

  const handleAddImage = async (e: React.FormEvent, itemId: string) => {
    e.preventDefault()

    if (!imageFormData.url.trim()) {
      toast.error('Image URL is required')
      return
    }

    setIsSubmitting(true)
    try {
      const response = await fetch(`/api/admin/portfolio/items/${itemId}/images`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(imageFormData),
      })

      if (!response.ok) throw new Error('Failed to add portfolio item image')

      toast.success('Portfolio item image added successfully')
      setIsDialogOpen(false)
      setImageFormData({
        url: '',
        alt: '',
        caption: '',
        position: 0,
      })
      fetchItems()
    } catch (error) {
      toast.error('Failed to add portfolio item image')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteImage = async (itemId: string, imageId: string) => {
    if (!confirm('Are you sure you want to delete this image?')) return

    setIsDeletingImage(imageId)
    try {
      const response = await fetch(`/api/admin/portfolio/items/${itemId}/images/${imageId}`, {
        method: 'DELETE',
      })

      if (!response.ok) throw new Error('Failed to delete portfolio item image')

      toast.success('Portfolio item image deleted successfully')
      fetchItems()
    } catch (error) {
      toast.error('Failed to delete portfolio item image')
    } finally {
      setIsDeletingImage(null)
    }
  }

  useEffect(() => {
    fetchItems()
  }, [])

  const getStatusBadge = (status: string) => {
    const styles = {
      draft: 'bg-gray-100 text-gray-800',
      published: 'bg-green-100 text-green-800',
      archived: 'bg-purple-100 text-purple-800',
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[status as keyof typeof styles]}`}>
        {status}
      </span>
    )
  }

  const getTypeBadge = (type: string) => {
    const styles = {
      project: 'bg-blue-100 text-blue-800',
      experience: 'bg-purple-100 text-purple-800',
      testimonial: 'bg-pink-100 text-pink-800',
    }
    const icons = {
      project: <Briefcase className="h-3 w-3" />,
      experience: <Award className="h-3 w-3" />,
      testimonial: <Heart className="h-3 w-3" />,
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium flex items-center gap-2 ${styles[type as keyof typeof styles]}`}>
        {icons[type as keyof typeof icons]}
        {type}
      </span>
    )
  }

  const filteredItems = items.filter(item => {
    if (typeFilter !== 'all' && item.type !== typeFilter) return false
    return true
  })

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Portfolio</h1>
            <p className="text-muted-foreground">Loading portfolio items...</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <select
            value={viewType}
            onChange={(e) => setViewType(e.target.value as 'grid' | 'list')}
            className="border border-border rounded-md px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
          >
            <option value="grid">Grid View</option>
            <option value="list">List View</option>
          </select>
        </div>
      </div>
      <Card>
        <CardContent className="p-6">
          <div className="h-96 bg-muted animate-pulse rounded" />
        </CardContent>
      </Card>
    </div>
    )
  }

  if (items.length === 0) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Portfolio</h1>
            <p className="text-muted-foreground">No portfolio items yet</p>
          </div>
          {isAdmin && (
            <Button variant="outline" size="sm">
              Create Item (coming soon)
            </Button>
          )}
        </div>
        <div className="flex items-center gap-2">
          <select
            value={viewType}
            onChange={(e) => setViewType(e.target.value as 'grid' | 'list')}
            className="border border-border rounded-md px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
          >
            <option value="grid">Grid View</option>
            <option value="list">List View</option>
          </select>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="All Types" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="project">Projects</SelectItem>
              <SelectItem value="experience">Experience</SelectItem>
              <SelectItem value="testimonial">Testimonials</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    )
  }

  const renderGridView = () => {
    return (
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredItems.map((item) => (
          <Card key={item.id} className="overflow-hidden">
            <CardHeader className="pb-0">
              <div className="flex items-start justify-between space-y-2">
                <div>
                  <div className="flex items-center gap-3">
                    <div className="aspect-square rounded-lg overflow-hidden border relative">
                      {item.images.length > 0 ? (
                        <img
                          src={item.images[0].url}
                          alt={item.images[0].alt || item.title}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full bg-primary/10 flex items-center justify-center">
                          <ImageIcon className="h-8 w-8 text-primary/60" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center justify-between">
                        <h3 className="text-lg font-semibold">{item.title}</h3>
                        <div className="flex items-center gap-2">
                          {getStatusBadge(item.status)}
                          <span className="text-xs text-muted-foreground">
                            {new Date(item.createdAt).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'short',
                              day: 'numeric',
                            })}
                          </span>
                        </div>
                      </div>
                      {item.slug && (
                        <p className="text-sm text-muted-foreground font-mono">/{item.slug}</p>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  {item.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {item.tags.map(({ tag }) => (
                        <Badge key={tag.id} variant="secondary" className="text-xs">
                          {tag.name}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="aspect-square relative bg-muted">
                {item.images.length > 0 ? (
                  <img
                    src={item.images[0].url}
                    alt={item.images[0].alt || item.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <ImageIcon className="h-16 w-16 text-muted-foreground" />
                  </div>
                )}
                {item.description && (
                  <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/60 to-transparent">
                    <p className="text-sm text-white font-medium">{item.description}</p>
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter className="p-4 pt-0">
              <div className="flex items-center justify-between">
                <div className="flex gap-2">
                  <Badge variant="secondary">{item.images.length} images</Badge>
                  {item.tags.length > 0 && <Badge variant="secondary">{item.tags.length} tags</Badge>}
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Actions</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem>
                      <Eye className="mr-2 h-4 w-4" />
                      View Item
                    </DropdownMenuItem>
                    {isAdmin && (
                      <>
                        <DropdownMenuItem>
                          <Edit className="mr-2 h-4 w-4" />
                          Edit Item (coming soon)
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          onClick={() => setIsDialogOpen(true)}
                        >
                          <Plus className="mr-2 h-4 w-4" />
                          Add Image
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => {
                            if (confirm(`Are you sure you want to delete "${item.title}"?`)) {
                              // Delete functionality would go here
                            }
                          }}
                          className="text-destructive"
                        >
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete Item
                        </DropdownMenuItem>
                      </>
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardFooter>
          </Card>
        ))}
      </div>
    )
  }

  const renderListView = () => {
    return (
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Item</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Tags</TableHead>
              <TableHead>Images</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Created</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredItems.map((item) => (
              <TableRow key={item.id}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    {item.images.length > 0 ? (
                      <img
                        src={item.images[0].url}
                        alt={item.images[0].alt || item.title}
                        className="h-10 w-10 rounded object-cover"
                      />
                    ) : (
                      <div className="h-10 w-10 rounded bg-primary/10 flex items-center justify-center">
                        <ImageIcon className="h-5 w-5 text-primary/60" />
                      </div>
                    )}
                    <div>
                      <div className="font-medium">{item.title}</div>
                      {item.slug && (
                        <div className="text-xs text-muted-foreground">{item.slug}</div>
                      )}
                    </div>
                  </div>
                </TableCell>
                <TableCell>{getTypeBadge(item.type)}</TableCell>
                <TableCell>
                  <div className="flex flex-wrap gap-1">
                    {item.tags.length > 0 ? (
                      item.tags.map(({ tag }) => (
                        <Badge key={tag.id} variant="secondary" className="text-xs">
                          {tag.name}
                        </Badge>
                      ))
                    ) : (
                      <span className="text-sm text-muted-foreground">-</span>
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="secondary">{item.images.length}</Badge>
                </TableCell>
                <TableCell>{getStatusBadge(item.status)}</TableCell>
                <TableCell>
                  {new Date(item.createdAt).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                  })}
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem>
                        <Eye className="mr-2 h-4 w-4" />
                        View Item
                      </DropdownMenuItem>
                      {isAdmin && (
                        <>
                          <DropdownMenuItem>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit Item (coming soon)
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            onClick={() => setIsDialogOpen(true)}
                          >
                            <Plus className="mr-2 h-4 w-4" />
                            Add Image
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => {
                              if (confirm(`Are you sure you want to delete "${item.title}"?`)) {
                                // Delete functionality would go here
                              }
                            }}
                            className="text-destructive"
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete Item
                          </DropdownMenuItem>
                        </>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Portfolio</h1>
          <p className="text-muted-foreground">Showcase your work and projects</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="All Types" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="project">Projects</SelectItem>
              <SelectItem value="experience">Experience</SelectItem>
              <SelectItem value="testimonial">Testimonials</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {filteredItems.length === 0 ? (
        <div className="text-center py-12">
          <FolderKanban className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">No portfolio items yet</h3>
          <p className="text-muted-foreground">
            {isAdmin ? 'Create your first portfolio item' : 'Ask an admin to add portfolio items'}
          </p>
        </div>
      ) : (
        <>
          {viewType === 'grid' ? renderGridView() : renderListView()}
        </>
      )}

      {/* Add Image Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <form onSubmit={(e) => handleAddImage(e, isDialogOpen ? items[0]?.id : '')}>
            <DialogHeader>
              <DialogTitle>Add Portfolio Item Image</DialogTitle>
              <DialogDescription>
                Add an image to the portfolio item
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="image-url">Image URL *</Label>
                <Input
                  id="image-url"
                  value={imageFormData.url}
                  onChange={(e) => setImageFormData({ ...imageFormData, url: e.target.value })}
                  placeholder="https://example.com/image.jpg"
                  required
                  disabled={isSubmitting}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="image-alt">Alt Text</Label>
                <Input
                  id="image-alt"
                  value={imageFormData.alt}
                  onChange={(e) => setImageFormData({ ...imageFormData, alt: e.target.value })}
                  placeholder="Portfolio item image alt text"
                  disabled={isSubmitting}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="image-caption">Caption</Label>
                <Input
                  id="image-caption"
                  value={imageFormData.caption}
                  onChange={(e) => setImageFormData({ ...imageFormData, caption: e.target.value })}
                  placeholder="Image caption"
                  disabled={isSubmitting}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="image-position">Position</Label>
                <Input
                  id="image-position"
                  type="number"
                  min="0"
                  value={imageFormData.position}
                  onChange={(e) => setImageFormData({ ...imageFormData, position: parseInt(e.target.value) })}
                  placeholder="0"
                  disabled={isSubmitting}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsDialogOpen(false)}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Adding...
                  </>
                ) : (
                  <>
                    <Upload className="mr-2 h-4 w-4" />
                    Add Image
                  </>
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
