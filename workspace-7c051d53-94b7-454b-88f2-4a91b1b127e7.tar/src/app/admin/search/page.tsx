'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Search, Plus, MoreHorizontal, Edit, Trash2, Eye, Check, Calendar, FileText, User as UserIcon, Loader2, MessageSquare, ShoppingBag, LayoutGrid, LayoutList, FolderKanban, Settings, Download } from 'lucide-react'
import { toast } from 'sonner'

interface SearchResult {
  type: string
  title: string
  description: string
  id: string
  slug: string
  entity: string
  createdAt: string
  author?: {
    name: string
    image: string
  }
}

interface SearchHistory {
  id: string
  query: string
  resultsCount: number
  searchType: string
  createdAt: string
}

export default function UnifiedSearchPage() {
  const { data: session } = useSession()
  const [searchQuery, setSearchQuery] = useState('')
  const [searchType, setSearchType] = useState<'all' | 'forum' | 'marketplace' | 'ecommerce' | 'directory' | 'event-hub' | 'portfolio'>('all')
  const [results, setResults] = useState<SearchResult[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [searchHistory, setSearchHistory] = useState<SearchHistory[]>([])
  const [isHistoryDialogOpen, setIsHistoryDialogOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const isAdmin = (session?.user as any)?.role === 'admin'

  const handleSearch = async () => {
    if (!searchQuery.trim()) return

    setIsLoading(true)
    try {
      const params = new URLSearchParams()
      params.append('q', searchQuery)
      params.append('type', searchType)

      const response = await fetch(`/api/admin/search?${params.toString()}`)
      if (!response.ok) throw new Error('Failed to search')

      const data = await response.json()
      setResults(data.results)

      // Add to search history
      if (isAdmin) {
        const newHistoryItem: SearchHistory = {
          id: `history-${Date.now()}`,
          query: searchQuery,
          resultsCount: data.results.length,
          searchType: searchType,
          createdAt: new Date().toISOString(),
        }

        setSearchHistory(prev => [newHistoryItem, ...prev.slice(0, 49)])
      }
    } catch (error) {
      console.error('Error searching:', error)
      toast.error('Failed to search')
    } finally {
      setIsLoading(false)
    }
  }

  const handleClearHistory = async () => {
    try {
      await fetch('/api/admin/search/history', {
        method: 'DELETE',
      })

      toast.success('Search history cleared')
      setSearchHistory([])
    } catch (error) {
      toast.error('Failed to clear search history')
    }
  }

  const getEntityTypeIcon = (entity: string) => {
    const icons = {
      thread: <MessageSquare className="h-4 w-4 text-blue-600" />,
      post: <FileText className="h-4 w-4 text-green-600" />,
      product: <ShoppingBag className="h-4 w-4 text-purple-600" />,
      order: <ShoppingBag className="h-4 w-4 text-orange-600" />,
      vendor: <User as UserIcon className="h-4 w-4 text-pink-600" />,
      listing: <FolderKanban className="h-4 w-4 text-cyan-600" />,
      event: <Calendar className="h-4 w-4 text-red-600" />,
      ticket: <FileText className="h-4 w-4 text-yellow-600" />,
      review: <Star className="h-4 w-4 text-amber-600" />,
      portfolio: <LayoutGrid className="h-4 w-4 text-indigo-600" />,
      user: <UserIcon className="h-4 w-4 text-gray-600" />,
      media: <ImageIcon className="h-4 w-4 text-teal-600" />,
    }
    return icons[entity as keyof typeof icons] || <FileText className="h-4 w-4 text-gray-600" />
  }

  const getThemeBadge = (type: string) => {
    const styles = {
      forum: 'bg-blue-100 text-blue-800',
      marketplace: 'bg-purple-100 text-purple-800',
      ecommerce: 'bg-pink-100 text-pink-800',
      directory: 'bg-cyan-100 text-cyan-800',
      'event-hub': 'bg-red-100 text-red-800',
      portfolio: 'bg-indigo-100 text-indigo-800',
      'all': 'bg-gray-100 text-gray-800',
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[type as keyof typeof styles]}`}>
        {type === 'all' ? 'All Themes' : type.charAt(0).toUpperCase() + type.slice(1)}
      </span>
    )
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Universal Search</h1>
              <p className="text-muted-foreground">Searching across all themes...</p>
          </div>
          <Badge variant="secondary">{results.length} results</Badge>
        </div>
      </div>
      <Card>
        <CardContent className="p-6">
          <div className="h-96 bg-muted animate-pulse rounded" />
        </CardContent>
      </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Universal Search</h1>
          <p className="text-muted-foreground">Search across all themes and content types</p>
        </div>
        <div className="flex items-center gap-2">
          {isAdmin && (
            <Button onClick={() => setIsHistoryDialogOpen(true)} variant="outline">
              <History className="mr-2 h-4 w-4" />
              Search History
            </Button>
          )}
          <Button onClick={() => window.print()} variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export Results
          </Button>
          {isAdmin && (
            <Button variant="outline">
              <Settings className="mr-2 h-4 w-4" />
              Settings (coming soon)
            </Button>
          )}
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Search Input Card */}
        <Card>
          <CardHeader>
            <CardTitle>Search Query</CardTitle>
            <CardDescription>
              Enter your search query to find content across all themes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              <div className="flex-1">
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search forums, marketplace, e-commerce, directory, events, portfolio..."
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  className="w-full"
                />
                <Button onClick={handleSearch} disabled={isLoading}>
                  <Search className="mr-2 h-4 w-4" />
                  {isLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <>Search</>
                  )}
                </Button>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex-1">
                <Label htmlFor="search-type">Content Type</Label>
                <Select id="search-type" value={searchType} onValueChange={setSearchType}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Themes" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Themes</SelectItem>
                    <SelectItem value="forum">Forum</SelectItem>
                    <SelectItem value="marketplace">Marketplace</SelectItem>
                    <SelectItem value="ecommerce">E-commerce</SelectItem>
                    <SelectItem value="directory">Directory</SelectItem>
                    <SelectItem value="event-hub">Event Hub</SelectItem>
                    <SelectItem value="portfolio">Portfolio</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex-1">
                <Badge variant="secondary">{getThemeBadge(searchType)}</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Popular Searches */}
        {searchHistory.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Popular Searches</CardTitle>
              <CardDescription>
                Most frequently searched queries across all themes
              </CardDescription>
              <div className="flex items-center gap-2">
                <div className="flex-1">
                  <div className="text-sm text-muted-foreground">
                    {searchHistory.length} searches saved
                  </div>
                </div>
                {isAdmin && (
                  <Button variant="ghost" size="icon" onClick={handleClearHistory}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                )}
              </div>
            </divHeader>
            <CardContent>
              <div className="space-y-2">
                {searchHistory.slice(0, 5).map((historyItem) => (
                  <div key={historyItem.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg hover:bg-muted/50 transition">
                    <div className="flex items-center gap-3">
                      <Search className="h-4 w-4 text-muted-foreground" />
                      <div className="flex-1">
                        <div className="font-medium">{historyItem.query}</div>
                        <div className="text-xs text-muted-foreground">
                          {historyItem.resultsCount} results • {new Date(historyItem.createdAt).toLocaleDateString('en-US', {
                            month: 'short',
                            day: 'numeric',
                          })}
                        </div>
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {getThemeBadge(historyItem.searchType)}
                    </div>
                  </div>
                </div>
              ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Search Results */}
        <Card>
          <CardHeader>
            <CardTitle>Search Results</CardTitle>
            <CardDescription>
              Found {results.length} results across {searchType === 'all' ? 'all themes' : searchType}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {results.length === 0 ? (
              <div className="text-center py-12">
                <Search className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No results found</h3>
                <p className="text-muted-foreground">
                  Try adjusting your search query or search type
                </p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Result</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Entity</TableHead>
                    <TableHead>Theme</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {results.map((result) => (
                    <TableRow key={result.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          {getEntityTypeIcon(result.entity)}
                          <div className="ml-3">
                            <div className="font-medium">{result.title}</div>
                            {result.description && (
                              <div className="text-xs text-muted-foreground mt-1">
                                {result.description}
                              </div>
                            )}
                            <div className="text-xs text-muted-foreground mt-1">
                              {result.slug}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{result.entity}</Badge>
                      </TableCell>
                      <TableCell>
                        {result.author && result.author.name && (
                          <div className="flex items-center gap-2">
                            {result.author.image ? (
                              <img
                                src={result.author.image}
                                alt={result.author.name}
                                className="h-6 w-6 rounded-full object-cover"
                              />
                            ) : (
                              <div className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center">
                                <UserIcon className="h-3 w-3 text-primary/60" />
                              </div>
                            )}
                            <div className="text-sm">{result.author.name}</div>
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        {getThemeBadge(result.type)}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <div className="text-xs text-muted-foreground">
                            {new Date(result.createdAt).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'short',
                              day: 'numeric',
                            })}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <Eye className="mr-2 h-4 w-4" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Calendar className="mr-2 h-4 w-4" />
                              View Created Date
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit (coming soon)
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              className="text-destructive"
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete Result (coming soon)
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Search History Dialog */}
      <Dialog open={isHistoryDialogOpen} onOpenChange={setIsHistoryDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Search History</DialogTitle>
            <DialogDescription>
              View and manage your search history
            </DialogDescription>
          </DialogHeader>
          <CardContent>
            {searchHistory.length === 0 ? (
              <div className="text-center py-6">
                <History className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No search history</h3>
                <p className="text-muted-foreground">
                  Your recent searches will appear here
                </p>
              </div>
            ) : (
              <div className="max-h-96 overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Query</TableHead>
                      <TableHead>Results</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {searchHistory.map((historyItem) => (
                      <TableRow key={historyItem.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Search className="h-4 w-4 text-muted-foreground" />
                            <div className="font-medium">{historyItem.query}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary">{historyItem.resultsCount}</Badge>
                        </TableCell>
                        <TableCell>
                          {getThemeBadge(historyItem.searchType)}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <div className="text-xs text-muted-foreground">
                              {new Date(historyItem.createdAt).toLocaleDateString('en-US', {
                                year: 'numeric',
                                month: 'short',
                                day: 'numeric',
                              })}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              setSearchQuery(historyItem.query)
                              setSearchType(historyItem.searchType as any)
                              handleSearch()
                              setIsHistoryDialogOpen(false)
                            }}
                          >
                            <Search className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Dialog>
    </div>
  )
}
