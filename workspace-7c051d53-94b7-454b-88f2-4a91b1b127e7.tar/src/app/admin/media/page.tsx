'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { FileImage, Folder, Search, Upload, Trash2, Edit, Loader2, MoreHorizontal, Eye, Image as ImageIcon, Download, Info, Calendar, ExternalLink, X } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SearchSelectTrigger, SelectValue } from '@/components/ui/select'
import { toast } from 'sonner'

interface Media {
  id: string
  filename: string
  originalName: string
  mimeType: string
  size: number
  url: string
  alt: string | null
  caption: string | null
  uploadedBy: {
    id: string
    name: string
    image: string
  }
  createdAt: string
}

export default function MediaLibraryPage() {
  const { data: session } = useSession()
  const [media, setMedia] = useState<Media[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [typeFilter, setTypeFilter] = useState('all')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isDeleting, setIsDeleting] = useState<string | null>(null)
  const [imageFormData, setImageFormData] = useState({
    url: '',
    alt: '',
    caption: '',
  })
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)

  const isAdmin = (session?.user as any)?.role === 'admin'

  const fetchMedia = async () => {
    try {
      const params = new URLSearchParams()
      if (typeFilter !== 'all') {
        params.append('type', typeFilter)
      }
      if (searchQuery) {
        params.append('search', searchQuery)
      }

      const response = await fetch(`/api/admin/media?${params.toString()}`)
      if (!response.ok) throw new Error('Failed to fetch media')

      const data = await response.json()
      setMedia(data)
    } catch (error) {
      console.error('Error fetching media:', error)
      toast.error('Failed to load media')
    } finally {
      setIsLoading(false)
    }
  }

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!uploadedFile) {
      toast.error('File is required')
      return
    }

    setIsSubmitting(true)
    try {
      const formData = new FormData()
      formData.append('file', uploadedFile)
      formData.append('alt', imageFormData.alt)
      formData.append('caption', imageFormData.caption)

      const response = await fetch('/api/admin/media/upload', {
        method: 'POST',
        body: formData,
      })

      if (!response.ok) throw new Error('Failed to upload media')

      toast.success('Media uploaded successfully')
      setIsDialogOpen(false)
      setUploadedFile(null)
      setImageFormData({
        url: '',
        alt: '',
        caption: '',
      })
      fetchMedia()
    } catch (error) {
      toast.error('Failed to upload media')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteMedia = async (mediaId: string, filename: string) => {
    if (!confirm(`Are you sure you want to delete "${filename}"?`)) return

    setIsDeleting(mediaId)
    try {
      const response = await fetch(`/api/admin/media/${mediaId}`, {
        method: 'DELETE',
      })

      if (!response.ok) throw new Error('Failed to delete media')

      toast.success('Media deleted successfully')
      fetchMedia()
    } catch (error) {
      toast.error('Failed to delete media')
    } finally {
      setIsDeleting(null)
    }
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const formatMimeType = (mimeType: string) => {
    if (mimeType.startsWith('image/')) return 'Image'
    if (mimeType.startsWith('video/')) return 'Video'
    if (mimeType.startsWith('audio/')) return 'Audio'
    if (mimeType === 'application/pdf') return 'PDF'
    return 'File'
  }

  const getStatusBadge = (status: string) => {
    const styles = {
      active: 'bg-green-100 text-green-800',
      deleted: 'bg-red-100 text-red-800',
      draft: 'bg-gray-100 text-gray-800',
      published: 'bg-blue-100 text-blue-800',
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[status as keyof typeof styles]}`}>
        {status}
      </span>
    )
  }

  useEffect(() => {
    fetchMedia()
  }, [searchQuery, typeFilter])

  const filteredMedia = media.filter(item => {
    if (typeFilter !== 'all') {
      if (typeFilter === 'image' && !item.mimeType.startsWith('image/')) return false
      if (typeFilter === 'video' && !item.mimeType.startsWith('video/')) return false
      if (typeFilter === 'audio' && !item.mimeType.startsWith('audio/')) return false
      if (typeFilter === 'document' && item.mimeType !== 'application/pdf') return false
    }
    if (searchQuery) {
      const search = searchQuery.toLowerCase()
      return (
        item.filename.toLowerCase().includes(search) ||
        item.originalName.toLowerCase().includes(search) ||
        item.alt?.toLowerCase().includes(search) ||
        item.caption?.toLowerCase().includes(search)
      )
    }
    return true
  })

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Media Library</h1>
          <p className="text-muted-foreground">Loading media...</p>
        </div>
        <Card>
          <CardContent className="p-6">
            <div className="h-96 bg-muted animate-pulse rounded" />
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Media Library</h1>
          <p className="text-muted-foreground">Manage all your media assets</p>
        </div>
        <div className="flex items-center gap-2">
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search media..."
            className="w-[250px]"
          />
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="All Types" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="image">Images</SelectItem>
              <SelectItem value="video">Videos</SelectItem>
              <SelectItem value="audio">Audio</SelectItem>
              <SelectItem value="document">Documents</SelectItem>
            </SelectContent>
          </Select>
          {isAdmin && (
            <Button onClick={() => setIsDialogOpen(true)}>
              <Upload className="mr-2 h-4 w-4" />
              Upload Media
            </Button>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2 mb-4">
        <Badge variant="secondary">{filteredMedia.length} items</Badge>
      </div>

      {filteredMedia.length === 0 ? (
        <div className="text-center py-12">
          <FolderOpen className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">No media yet</h3>
          <p className="text-muted-foreground">
            {isAdmin ? 'Upload your first media asset' : 'Ask an admin to upload media'}
          </p>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filteredMedia.map((item) => (
            <Card key={item.id} className="overflow-hidden">
              <CardHeader className="p-0 pb-2">
                <div className="relative">
                  {item.mimeType.startsWith('image/') ? (
                    <img
                      src={item.url}
                      alt={item.alt || item.filename}
                      className="w-full aspect-square object-cover"
                    />
                  ) : item.mimeType.startsWith('video/') ? (
                    <div className="w-full aspect-square bg-muted flex items-center justify-center">
                      <FileVideo className="h-12 w-12 text-muted-foreground" />
                    </div>
                  ) : (
                    <div className="w-full aspect-square bg-muted flex items-center justify-center">
                      <FileImage className="h-12 w-12 text-muted-foreground" />
                    </div>
                  )}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="absolute top-2 right-2 bg-white/80 hover:bg-white">
                        {isDeleting === item.id ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <MoreHorizontal className="h-4 w-4" />
                        )}
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem>
                        <Eye className="mr-2 h-4 w-4" />
                        View Media
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Download className="mr-2 h-4 w-4" />
                        Download
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <ExternalLink className="mr-2 h-4 w-4" />
                        Copy URL
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Info className="mr-2 h-4 w-4" />
                        View Details (coming soon)
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        onClick={() => handleDeleteMedia(item.id, item.filename)}
                        className="text-destructive"
                        disabled={isDeleting === item.id}
                      >
                        <Trash2 className="mr-2 h-4 w-4" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <div className="space-y-3">
                  <div className="font-medium text-sm">{item.originalName}</div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">{formatMimeType(item.mimeType)}</Badge>
                    <Badge variant="outline">{formatFileSize(item.size)}</Badge>
                  </div>
                  {item.alt && (
                    <div className="text-xs text-muted-foreground">
                      <span className="font-medium">Alt:</span> {item.alt}
                    </div>
                  )}
                  {item.caption && (
                    <div className="text-xs text-muted-foreground">
                      <span className="font-medium">Caption:</span> {item.caption}
                    </div>
                  )}
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      <span>Uploaded</span>
                      <span>{new Date(item.createdAt).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                      })}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span>By</span>
                      <span>{item.uploadedBy.name}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Upload Media Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <form onSubmit={handleUpload}>
            <DialogHeader>
              <DialogTitle>Upload Media</DialogTitle>
              <DialogDescription>
                Upload files to your media library
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="file">File *</Label>
                <Input
                  id="file"
                  type="file"
                  onChange={(e) => {
                    const file = e.target.files?.[0]
                    if (file) {
                      setUploadedFile(file)
                    }
                  }}
                  className="w-full"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="alt">Alt Text</Label>
                <Input
                  id="alt"
                  value={imageFormData.alt}
                  onChange={(e) => setImageFormData({ ...imageFormData, alt: e.target.value })}
                  placeholder="Media alt text"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="caption">Caption</Label>
                <Input
                  id="caption"
                  value={imageFormData.caption}
                  onChange={(e) => setImageFormData({ ...imageFormData, caption: e.target.value })}
                  placeholder="Media caption"
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsDialogOpen(false)}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Uploading...
                  </>
                ) : (
                  <>
                    <Upload className="mr-2 h-4 w-4" />
                    Upload Media
                  </>
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
