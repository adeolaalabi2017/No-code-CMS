'use client'

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { MoreHorizontal, Plus, Edit, Trash2, Layers, Eye, Loader2 } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { toast } from 'sonner'

interface Theme {
  id: string
  name: string
  slug: string
  type: string
  description: string | null
  version: string
  isActive: boolean
  screenshot: string | null
  _count: {
    pages: number
    posts: number
    events: number
    portfolioItems: number
  }
}

export default function ThemesPage() {
  const { data: session } = useSession()
  const [themes, setThemes] = useState<Theme[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [typeFilter, setTypeFilter] = useState('all')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isDeleting, setIsDeleting] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    name: '',
    slug: '',
    type: 'portfolio' as 'forum' | 'marketplace' | 'ecommerce' | 'directory' | 'events' | 'portfolio',
    description: '',
    screenshot: '',
  })

  const fetchThemes = async () => {
    try {
      const params = new URLSearchParams()
      if (typeFilter !== 'all') params.append('type', typeFilter)

      const response = await fetch(`/api/admin/themes?${params.toString()}`)
      if (!response.ok) throw new Error('Failed to fetch themes')
      const data = await response.json()
      setThemes(data)
    } catch (error) {
      toast.error('Failed to load themes')
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchThemes()
  }, [typeFilter])

  const handleActivate = async (themeId: string) => {
    try {
      const response = await fetch(`/api/admin/themes/${themeId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: true }),
      })

      if (!response.ok) throw new Error('Failed to activate theme')

      toast.success('Theme activated successfully')
      fetchThemes()
    } catch (error) {
      toast.error('Failed to activate theme')
    }
  }

  const handleDeactivate = async (themeId: string) => {
    try {
      const response = await fetch(`/api/admin/themes/${themeId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: false }),
      })

      if (!response.ok) throw new Error('Failed to deactivate theme')

      toast.success('Theme deactivated successfully')
      fetchThemes()
    } catch (error) {
      toast.error('Failed to deactivate theme')
    }
  }

  const handleDelete = async (themeId: string, name: string) => {
    if (!confirm(`Are you sure you want to delete theme "${name}"?`)) return

    setIsDeleting(themeId)
    try {
      const response = await fetch(`/api/admin/themes/${themeId}`, {
        method: 'DELETE',
      })

      if (!response.ok) throw new Error('Failed to delete theme')

      toast.success('Theme deleted successfully')
      fetchThemes()
    } catch (error) {
      toast.error('Failed to delete theme')
    } finally {
      setIsDeleting(null)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.name.trim() || !formData.slug.trim()) {
      toast.error('Name and slug are required')
      return
    }

    setIsSubmitting(true)
    try {
      const response = await fetch('/api/admin/themes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      })

      if (!response.ok) throw new Error('Failed to create theme')

      toast.success('Theme created successfully')
      setIsDialogOpen(false)
      setFormData({
        name: '',
        slug: '',
        type: 'portfolio',
        description: '',
        screenshot: '',
      })
      fetchThemes()
    } catch (error) {
      toast.error('Failed to create theme')
    } finally {
      setIsSubmitting(false)
    }
  }

  const getTypeBadge = (type: string) => {
    const styles = {
      forum: 'bg-purple-100 text-purple-800',
      marketplace: 'bg-blue-100 text-blue-800',
      ecommerce: 'bg-green-100 text-green-800',
      directory: 'bg-yellow-100 text-yellow-800',
      events: 'bg-pink-100 text-pink-800',
      portfolio: 'bg-orange-100 text-orange-800',
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[type as keyof typeof styles]}`}>
        {type}
      </span>
    )
  }

  const isAdmin = (session?.user as any)?.role === 'admin'

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Themes</h1>
          <p className="text-muted-foreground">Manage and activate themes for your CMS</p>
        </div>
        <Card>
          <CardContent className="p-6">
            <div className="space-y-4">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="h-24 bg-muted animate-pulse rounded" />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Themes</h1>
          <p className="text-muted-foreground">Manage and activate themes for your CMS</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="All Types" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="forum">Forum</SelectItem>
              <SelectItem value="marketplace">Marketplace</SelectItem>
              <SelectItem value="ecommerce">E-commerce</SelectItem>
              <SelectItem value="directory">Directory</SelectItem>
              <SelectItem value="events">Events</SelectItem>
              <SelectItem value="portfolio">Portfolio</SelectItem>
            </SelectContent>
          </Select>
        </div>
        {isAdmin && (
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                New Theme
              </Button>
            </DialogTrigger>
            <DialogContent>
              <form onSubmit={handleSubmit}>
                <DialogHeader>
                  <DialogTitle>Create New Theme</DialogTitle>
                  <DialogDescription>
                    Add a new theme type to your CMS
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="name">Name *</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="Forum Theme"
                        required
                        disabled={isSubmitting}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="slug">Slug *</Label>
                      <Input
                        id="slug"
                        value={formData.slug}
                        onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                        placeholder="forum-theme"
                        required
                        disabled={isSubmitting}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="type">Type *</Label>
                    <Select
                      value={formData.type}
                      onValueChange={(value) => setFormData({ ...formData, type: value as any })}
                      disabled={isSubmitting}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="forum">Forum</SelectItem>
                        <SelectItem value="marketplace">Marketplace</SelectItem>
                        <SelectItem value="ecommerce">E-commerce</SelectItem>
                        <SelectItem value="directory">Directory</SelectItem>
                        <SelectItem value="events">Events</SelectItem>
                        <SelectItem value="portfolio">Portfolio</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Input
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      placeholder="A theme for community forums"
                      disabled={isSubmitting}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="screenshot">Screenshot URL</Label>
                    <Input
                      id="screenshot"
                      value={formData.screenshot}
                      onChange={(e) => setFormData({ ...formData, screenshot: e.target.value })}
                      placeholder="https://example.com/theme-preview.png"
                      disabled={isSubmitting}
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsDialogOpen(false)}
                    disabled={isSubmitting}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? 'Creating...' : 'Create Theme'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Themes</CardTitle>
          <CardDescription>
            Choose and activate themes to enable different features
          </CardDescription>
        </CardHeader>
        <CardContent>
          {themes.length === 0 ? (
            <div className="text-center py-12">
              <Layers className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No themes yet</h3>
              <p className="text-muted-foreground">
                {isAdmin ? 'Create your first theme to get started' : 'Ask an admin to create themes'}
              </p>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Theme</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Content</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {themes.map((theme) => (
                    <TableRow key={theme.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          {theme.screenshot ? (
                            <div className="h-12 w-12 rounded bg-muted overflow-hidden">
                              <img
                                src={theme.screenshot}
                                alt={theme.name}
                                className="h-full w-full object-cover"
                              />
                            </div>
                          ) : (
                            <div className="h-12 w-12 rounded bg-primary/10 flex items-center justify-center">
                              <Layers className="h-6 w-6 text-primary/60" />
                            </div>
                          )}
                          <div>
                            <div className="font-medium">{theme.name}</div>
                            <div className="text-sm text-muted-foreground">/{theme.slug}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{getTypeBadge(theme.type)}</TableCell>
                      <TableCell>
                        <div className="flex gap-2 text-sm">
                          {theme._count.pages > 0 && (
                            <span>{theme._count.pages} pages</span>
                          )}
                          {theme._count.posts > 0 && (
                            <span>{theme._count.posts} posts</span>
                          )}
                          {theme._count.events > 0 && (
                            <span>{theme._count.events} events</span>
                          )}
                          {theme._count.portfolioItems > 0 && (
                            <span>{theme._count.portfolioItems} items</span>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        {theme.isActive ? (
                          <Badge className="bg-green-100 text-green-800">Active</Badge>
                        ) : (
                          <Badge variant="secondary">Inactive</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" disabled={isDeleting === theme.id}>
                              {isDeleting === theme.id ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : (
                                <MoreHorizontal className="h-4 w-4" />
                              )}
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            {theme.isActive ? (
                              <DropdownMenuItem onClick={() => handleDeactivate(theme.id)}>
                                <Eye className="mr-2 h-4 w-4" />
                                Deactivate
                              </DropdownMenuItem>
                            ) : (
                              <DropdownMenuItem onClick={() => handleActivate(theme.id)}>
                                <Eye className="mr-2 h-4 w-4" />
                                Activate
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit (coming soon)
                            </DropdownMenuItem>
                            {isAdmin && (
                              <>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem
                                  onClick={() => handleDelete(theme.id, theme.name)}
                                  className="text-destructive"
                                  disabled={isDeleting === theme.id}
                                >
                                  <Trash2 className="mr-2 h-4 w-4" />
                                  Delete
                                </DropdownMenuItem>
                              </>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
