'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  BarChart,
  Bar,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
} from 'recharts'
import { TrendingUp, DollarSign, Users, MessageSquare, ShoppingCart, Eye, Calendar, BarChart3, PieChart as PieChartIcon } from 'lucide-react'
import { toast } from 'sonner'

interface OverviewStats {
  totalUsers: number
  totalThreads: number
  totalPosts: number
  totalVendors: number
  totalListings: number
  totalProducts: number
  totalOrders: number
  newUsers: number
  newThreads: number
  newPosts: number
  newVendors: number
  newListings: number
  newProducts: number
  newOrders: number
  totalViews: number
  totalReplies: number
  totalReviews: number
  totalTickets: number
  totalRevenue: number
}

interface EngagementData {
  period: string
  startDate: string
  threadCount: number
  postCount: number
  threadEngagement: number
  vendorCount: number
  reviewCount: number
  topThreads: {
    id: string
    title: string
    posts: number
    createdAt: string
  }[]
  topVendors: {
    id: string
    name: string
    listings: number
    reviews: number
    createdAt: string
  }[]
  topReviews: {
    id: string
    rating: number
    title: string
    createdAt: string
  }[]
}

export default function AnalyticsDashboard() {
  const { data: session } = useSession()
  const [overviewStats, setOverviewStats] = useState<OverviewStats | null>(null)
  const [engagementData, setEngagementData] = useState<EngagementData | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [dateRange, setDateRange] = useState('30') // 30 days default
  const [activeTab, setActiveTab] = useState<'overview' | 'engagement'>('overview')

  const isAdmin = (session?.user as any)?.role === 'admin'

  const fetchOverview = async () => {
    try {
      const params = new URLSearchParams()
      if (dateRange) {
        params.append('startDate', new Date(Date.now() - parseInt(dateRange) * 24 * 60 * 60 * 1000).toISOString())
        params.append('endDate', new Date().toISOString())
      }

      const response = await fetch(`/api/admin/analytics-overview?${params.toString()}`)
      if (!response.ok) throw new Error('Failed to fetch overview')

      const data = await response.json()
      setOverviewStats(data.overview)
    } catch (error) {
      console.error('Error fetching overview:', error)
      toast.error('Failed to load overview data')
    } finally {
      setIsLoading(false)
    }
  }

  const fetchEngagement = async () => {
    try {
      const params = new URLSearchParams()
      params.append('days', dateRange)

      const response = await fetch(`/api/admin/analytics-overview/engagement?${params.toString()}`)
      if (!response.ok) throw new Error('Failed to fetch engagement')

      const data = await response.json()
      setEngagementData(data.engagement)
    } catch (error) {
      console.error('Error fetching engagement:', error)
      toast.error('Failed to load engagement data')
    }
  }

  useEffect(() => {
    fetchOverview()
    if (activeTab === 'engagement') {
      fetchEngagement()
    }
  }, [dateRange, activeTab])

  const formatRevenue = (revenue: number) => {
    return `$${revenue.toFixed(2)}`
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    })
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Analytics Dashboard</h1>
          <p className="text-muted-foreground">Loading analytics...</p>
        </div>
        <div className="grid gap-6 md:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="h-32 bg-muted animate-pulse rounded" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Analytics Dashboard</h1>
          <p className="text-muted-foreground">Monitor performance and growth</p>
        </div>
        <div className="flex items-center gap-2">
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Select Period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Last 7 Days</SelectItem>
              <SelectItem value="30">Last 30 Days</SelectItem>
              <SelectItem value="90">Last 90 Days</SelectItem>
              <SelectItem value="365">Last Year</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex gap-2 mb-4">
        <Button
          variant={activeTab === 'overview' ? 'default' : 'outline'}
          onClick={() => setActiveTab('overview')}
        >
          <BarChart3 className="mr-2 h-4 w-4" />
          Overview
        </Button>
        <Button
          variant={activeTab === 'engagement' ? 'default' : 'outline'}
          onClick={() => setActiveTab('engagement')}
        >
          <TrendingUp className="mr-2 h-4 w-4" />
          Engagement
        </Button>
      </div>

      {activeTab === 'overview' && overviewStats && (
        <div className="grid gap-6 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Users
              </CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overviewStats.totalUsers.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                +{overviewStats.newUsers} new
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Threads
              </CardTitle>
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overviewStats.totalThreads.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                +{overviewStats.newThreads} new
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Posts
              </CardTitle>
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overviewStats.totalPosts.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                +{overviewStats.newPosts} new
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Vendors
              </CardTitle>
              <ShoppingCart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overviewStats.totalVendors.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                +{overviewStats.newVendors} new
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Listings
              </CardTitle>
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overviewStats.totalListings.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                +{overviewStats.newListings} new
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Products
              </CardTitle>
              <ShoppingCart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overviewStats.totalProducts.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                +{overviewStats.newProducts} new
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Orders
              </CardTitle>
              <ShoppingCart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overviewStats.totalOrders.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                +{overviewStats.newOrders} new
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Revenue
              </CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatRevenue(overviewStats.totalRevenue)}</div>
              <p className="text-xs text-muted-foreground">
                Total earnings
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Views
              </CardTitle>
              <Eye className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overviewStats.totalViews.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                Page views
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Replies
              </CardTitle>
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overviewStats.totalReplies.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                Forum replies
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Reviews
              </CardTitle>
              <MessageSquare className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overviewStats.totalReviews.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                Customer reviews
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Total Tickets
              </CardTitle>
              <ShoppingCart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{overviewStats.totalTickets.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                Event tickets
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Period
              </CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold">{dateRange} Days</div>
              <p className="text-xs text-muted-foreground">
                Data period
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === 'engagement' && engagementData && (
        <div className="grid gap-6 lg:grid-cols-2">
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle>Top Threads</CardTitle>
              <CardDescription>
                Most engaging discussions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={engagementData.topThreads}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="title" />
                  <YAxis />
                  <Tooltip
                    formatter={(value, name) => [
                      <div key={name}>
                        <div className="font-medium">{name}</div>
                        <div className="text-sm text-muted-foreground">{value} posts</div>
                      </div>
                    ]}
                  />
                  <Bar dataKey="posts" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Top Vendors</CardTitle>
                <CardDescription>
                  Best performing vendors
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {engagementData.topVendors.slice(0, 5).map((vendor) => (
                    <div key={vendor.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                      <div>
                        <div className="font-medium">{vendor.name}</div>
                        <div className="text-sm text-muted-foreground">{vendor.listings} listings</div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold">{vendor.reviews}</div>
                        <div className="text-xs text-muted-foreground">reviews</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Top Reviews</CardTitle>
                <CardDescription>
                  Highest rated reviews
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {engagementData.topReviews.slice(0, 5).map((review) => (
                    <div key={review.id} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                      <div>
                        <div className="font-medium">{review.title}</div>
                        <div className="text-xs text-muted-foreground">{formatDate(review.createdAt)}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold flex items-center gap-1">
                          <Star className="h-5 w-5 text-yellow-500 fill-current" />
                          {review.rating}
                        </div>
                        <div className="text-xs text-muted-foreground">rating</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  )
}
