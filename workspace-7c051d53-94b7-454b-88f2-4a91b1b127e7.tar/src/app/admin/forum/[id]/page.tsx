'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { MessageSquare, Reply, Plus, ArrowLeft, Loader2, User, Clock } from 'lucide-react'
import { toast } from 'sonner'
import Link from 'next/link'

interface ForumPost {
  id: string
  content: string
  createdAt: string
  threadId: string
  authorId: string
  author: {
    id: string
    name: string
    email: string
    image: string
  }
}

interface ForumThread {
  id: string
  title: string
  slug: string
  content: string
  status: string
  createdAt: string
  authorId: string
  author: {
    id: string
    name: string
    email: string
    image: string
  }
}

export default function ForumThreadPage({
  params,
}: {
  params: { id: string }
}) {
  const { data: session } = useSession()
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [posts, setPosts] = useState<ForumPost[]>([])
  const [thread, setThread] = useState<ForumThread | null>(null)
  const [newPostContent, setNewPostContent] = useState('')

  const fetchThread = async () => {
    try {
      const response = await fetch(`/api/admin/forum/threads`)
      if (!response.ok) throw new Error('Failed to fetch threads')

      const data = await response.json()
      const foundThread = data.find((t: ForumThread) => t.id === params.id)

      if (foundThread) {
        setThread(foundThread)
      } else {
        toast.error('Thread not found')
      }
    } catch (error) {
      console.error('Error fetching thread:', error)
      toast.error('Failed to load thread')
    }
  }

  const fetchPosts = async () => {
    try {
      const response = await fetch(`/api/admin/forum/posts?threadId=${params.id}`)
      if (!response.ok) throw new Error('Failed to fetch posts')

      const data = await response.json()
      setPosts(data)
    } catch (error) {
      console.error('Error fetching posts:', error)
      toast.error('Failed to load posts')
    } finally {
      setIsLoading(false)
    }
  }

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!newPostContent.trim()) {
      toast.error('Post content is required')
      return
    }

    setIsSubmitting(true)
    try {
      const response = await fetch('/api/admin/forum/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: newPostContent,
          threadId: params.id,
        }),
      })

      if (!response.ok) throw new Error('Failed to create post')

      toast.success('Reply posted successfully')
      setNewPostContent('')
      fetchPosts()
      fetchThread()
    } catch (error) {
      toast.error('Failed to post reply')
    } finally {
      setIsSubmitting(false)
    }
  }

  useEffect(() => {
    fetchThread()
    fetchPosts()
  }, [params.id])

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    })
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Link href="/admin/forum">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Forum Thread</h1>
            <p className="text-muted-foreground">Loading thread...</p>
          </div>
        </div>
        <Card>
          <CardContent className="p-6">
            <div className="h-96 bg-muted animate-pulse rounded" />
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!thread) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Link href="/admin/forum">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Thread Not Found</h1>
            <p className="text-muted-foreground">The thread you're looking for doesn't exist</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/admin/forum">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{thread.title}</h1>
            <p className="text-muted-foreground">/{thread.slug}</p>
          </div>
        </div>
        <Badge className={thread.status === 'open' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
          {thread.status}
        </Badge>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-3">
              {thread.author.image ? (
                <img
                  src={thread.author.image}
                  alt={thread.author.name || ''}
                  className="h-12 w-12 rounded-full object-cover"
                />
              ) : (
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <User className="h-6 w-6 text-primary/60" />
                </div>
              )}
              <div>
                <div className="font-medium">{thread.author.name}</div>
                <div className="text-sm text-muted-foreground">{thread.author.email}</div>
                <div className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                  <Clock className="h-3 w-3" />
                  <span>Created {formatDate(thread.createdAt)}</span>
                </div>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="p-6 bg-muted/50 rounded-lg">
              <p className="whitespace-pre-wrap">{thread.content}</p>
            </div>

            <form onSubmit={handleCreatePost}>
              <div className="space-y-4">
                <Textarea
                  value={newPostContent}
                  onChange={(e) => setNewPostContent(e.target.value)}
                  placeholder="Write a reply..."
                  rows={4}
                  className="resize-none"
                />
                <div className="flex items-center justify-between">
                  <p className="text-sm text-muted-foreground">
                    {posts.length} {posts.length === 1 ? 'reply' : 'replies'}
                  </p>
                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Posting...
                      </>
                    ) : (
                      <>
                        <Reply className="mr-2 h-4 w-4" />
                        Post Reply
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </form>

            {posts.length > 0 && (
              <div className="space-y-4 mt-8 pt-8 border-t">
                <h3 className="text-lg font-semibold">Replies ({posts.length})</h3>
                {posts.map((post) => (
                  <div key={post.id} className="p-4 bg-muted/30 rounded-lg space-y-3">
                    <div className="flex items-start gap-3">
                      {post.author.image ? (
                        <img
                          src={post.author.image}
                          alt={post.author.name || ''}
                          className="h-10 w-10 rounded-full object-cover"
                        />
                      ) : (
                        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <User className="h-5 w-5 text-primary/60" />
                        </div>
                      )}
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center justify-between">
                          <div className="font-medium">{post.author.name}</div>
                          <div className="text-xs text-muted-foreground flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            <span>{formatDate(post.createdAt)}</span>
                          </div>
                        </div>
                        <p className="whitespace-pre-wrap text-sm">{post.content}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
