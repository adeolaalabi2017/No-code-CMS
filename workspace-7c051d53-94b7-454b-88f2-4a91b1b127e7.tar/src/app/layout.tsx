import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Providers } from "@/components/providers";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "No-Code CMS - Build Your Website",
  description: "Modern no-code CMS platform for building beautiful websites without coding",
  keywords: ["No-Code", "CMS", "Website Builder", "Next.js", "TypeScript"],
  authors: [{ name: "No-Code CMS Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "No-Code CMS",
    description: "Build your website without coding",
    url: "https://chat.z.ai",
    siteName: "No-Code CMS",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "No-Code CMS",
    description: "Build your website without coding",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <Providers>
          {children}
          <Toaster />
        </Providers>
      </body>
    </html>
  );
}
