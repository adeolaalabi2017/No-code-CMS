'use client'

import dynamic from 'next/dynamic'

// Dynamically import MDXEditor to avoid SSR issues
const MDXEditor = dynamic(() => import('@mdxeditor/editor'), {
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="text-center">
        <div className="h-8 w-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <p className="text-sm text-muted-foreground">Loading editor...</p>
      </div>
    </div>
  ),
})

interface RichTextEditorProps {
  value: string
  onChange: (value: string) => void
  placeholder?: string
  readonly?: boolean
  height?: string
}

export function RichTextEditor({
  value,
  onChange,
  placeholder = "Start writing your content...",
  readonly = false,
  height = '400px',
}: RichTextEditorProps) {
  return (
    <div className="w-full">
      <div style={{ height }} className="border rounded-lg overflow-hidden">
        <MDXEditor
          markdown={value}
          onChange={onChange}
          placeholder={placeholder}
          readonly={readonly}
          className="w-full h-full"
        />
      </div>
    </div>
  )
}
