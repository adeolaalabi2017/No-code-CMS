'use client'

import { FC, useState } from 'react'
import dynamic from 'next/dynamic'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { toast } from 'sonner'
import { Image as ImageIcon, Link as LinkIcon, X } from 'lucide-react'

// Dynamically import MDXEditor to avoid SSR issues
const MDXEditor = dynamic(() => import('@mdxeditor/editor'), {
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center min-h-[400px]">
      <div className="text-center">
        <div className="h-8 w-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <p className="text-sm text-muted-foreground">Loading editor...</p>
      </div>
    </div>
  ),
})

interface RichTextEditorProps {
  value: string
  onChange: (value: string) => void
  placeholder?: string
  readonly?: boolean
  height?: string
  maxHeight?: string
  showToolbar?: boolean
}

interface InsertImageDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onInsert: (url: string, alt: string) => void
}

function InsertImageDialog({ open, onOpenChange, onInsert }: InsertImageDialogProps) {
  const [url, setUrl] = useState('')
  const [alt, setAlt] = useState('')

  const handleInsert = () => {
    if (!url) {
      toast.error('Please enter an image URL')
      return
    }
    onInsert(url, alt)
    setUrl('')
    setAlt('')
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Insert Image</DialogTitle>
          <DialogDescription>
            Add an image to your content
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="image-url">Image URL</Label>
            <Input
              id="image-url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://example.com/image.jpg"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="image-alt">Alt Text</Label>
            <Input
              id="image-alt"
              value={alt}
              onChange={(e) => setAlt(e.target.value)}
              placeholder="Image description for accessibility"
            />
          </div>
        </div>
        <div className="flex gap-2">
          <Button onClick={handleInsert} className="flex-1">
            Insert Image
          </Button>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
          >
            Cancel
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

export const RichTextEditor: FC<RichTextEditorProps> = ({
  value,
  onChange,
  placeholder = "Start writing your content...",
  readonly = false,
  height = '400px',
  maxHeight,
  showToolbar = true,
}) => {
  const [imageDialogOpen, setImageDialogOpen] = useState(false)

  const handleImageInsert = (url: string, alt: string) => {
    const imageMarkdown = `
![${alt || 'Image'}](${url}${alt ? ` "${alt}"` : ''})

`
    onChange(value + imageMarkdown)
    toast.success('Image inserted')
  }

  return (
    <div className="w-full space-y-2">
      <div className="flex items-center gap-2">
        <h3 className="text-sm font-medium">Content</h3>
        {!readonly && (
          <Dialog open={imageDialogOpen} onOpenChange={setImageDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <ImageIcon className="h-4 w-4 mr-2" />
                Insert Image
              </Button>
            </DialogTrigger>
            <InsertImageDialog
              open={imageDialogOpen}
              onOpenChange={setImageDialogOpen}
              onInsert={handleImageInsert}
            />
          </Dialog>
        )}
      </div>
      <div
        className="border rounded-lg overflow-hidden bg-background"
        style={{
          height: maxHeight ? 'auto' : height,
          maxHeight: maxHeight,
        }}
      >
        <MDXEditor
          markdown={value}
          onChange={onChange}
          placeholder={placeholder}
          readonly={readonly}
          className="w-full h-full"
        />
      </div>
      <div className="text-xs text-muted-foreground">
        <p>Tip: You can use Markdown syntax to format your content</p>
        <p className="mt-1">Supports: **bold**, *italic*, `code`, # headings, - lists, and more</p>
      </div>
    </div>
  )
}
