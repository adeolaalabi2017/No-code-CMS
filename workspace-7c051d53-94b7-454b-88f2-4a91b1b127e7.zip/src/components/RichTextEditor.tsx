import { useState } from 'react'
import { MDXEditor, MDXEditorMethods } from '@mdxeditor/editor'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Bold, Italic, Underline, Strikethrough, Code, List, Quote, Undo, Redo, Save } from 'lucide-react'
import { toast } from 'sonner'

interface RichTextEditorProps {
  markdown: string
  onSave: (markdown: string) => void
  placeholder?: string
}

export default function RichTextEditor({ markdown, onSave, placeholder = 'Write something...' }: RichTextEditorProps) {
  const [editorMarkdown, setEditorMarkdown] = useState(markdown)

  const handleSave = () => {
    onSave(editorMarkdown)
    toast.success('Content saved successfully')
  }

  const handleReset = () => {
    setEditorMarkdown(markdown)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Rich Text Editor</CardTitle>
        <CardDescription>
          Professional markdown editor with live preview
        </CardDescription>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleReset}>
            <Undo className="mr-2 h-4 w-4" />
            Reset
          </Button>
          <Button variant="outline" size="sm" onClick={handleSave}>
            <Save className="mr-2 h-4 w-4" />
            Save
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="border rounded-lg p-4">
          <MDXEditor
            markdown={editorMarkdown}
            onChange={setEditorMarkdown}
            placeholder={placeholder}
            height={400}
            components={{
              h1: ({ children }) => (
                <h1 className="text-3xl font-bold my-4">{children}</h1>
              ),
              h2: ({ children }) => (
                <h2 className="text-2xl font-bold my-3">{children}</h2>
              ),
              h3: ({ children }) => (
                <h3 className="text-xl font-bold my-2">{children}</h3>
              ),
              p: ({ children }) => (
                <p className="my-2 leading-7">{children}</p>
              ),
              ul: ({ children }) => (
                <ul className="list-disc list-inside my-2 space-y-1">{children}</ul>
              ),
              ol: ({ children }) => (
                <ol className="list-decimal list-inside my-2 space-y-1">{children}</ol>
              ),
              code: ({ children }) => (
                <code className="bg-muted p-4 rounded-lg my-2 block text-sm font-mono overflow-x-auto">{children}</code>
              ),
              blockquote: ({ children }) => (
                <blockquote className="border-l-4 pl-4 my-2 italic border-muted-foreground">{children}</blockquote>
              ),
              strong: ({ children }) => (
                <strong className="font-semibold">{children}</strong>
              ),
              em: ({ children }) => (
                <em className="italic">{children}</em>
              ),
              a: ({ children }) => (
                <a href="#" className="text-blue-600 hover:underline">{children}</a>
              ),
            }}
            plugins={[
              MDXEditorMethods.bold,
              MDXEditorMethods.italic,
              MDXEditorMethods.underline,
              MDXEditorMethods.strike,
              MDXEditorMethods.code,
              MDXEditorMethods.orderedList,
              MDXEditorMethods.unorderedList,
              MDXEditorMethods.blockquote,
            ]}
          />
        </div>
      </CardContent>
    </Card>
  )
}
