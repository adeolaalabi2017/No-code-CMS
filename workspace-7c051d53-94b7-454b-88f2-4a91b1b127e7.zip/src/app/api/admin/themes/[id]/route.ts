import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

// GET /api/admin/themes/[id] - Get a single theme
export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || (session.user as any).role !== 'admin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const theme = await db.theme.findUnique({
      where: { id: params.id },
      include: {
        _count: {
          select: {
            pages: true,
            posts: true,
            events: true,
            portfolioItems: true,
          },
        },
      },
    })

    if (!theme) {
      return NextResponse.json({ error: 'Theme not found' }, { status: 404 })
    }

    return NextResponse.json(theme)
  } catch (error) {
    console.error('Error fetching theme:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// PUT /api/admin/themes/[id] - Update a theme
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || (session.user as any).role !== 'admin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await req.json()
    const { name, slug, description, isActive, settings, screenshot } = body

    const theme = await db.theme.update({
      where: { id: params.id },
      data: {
        name,
        slug,
        description,
        isActive,
        settings,
        screenshot,
      },
    })

    return NextResponse.json(theme)
  } catch (error) {
    console.error('Error updating theme:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// DELETE /api/admin/themes/[id] - Delete a theme
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || (session.user as any).role !== 'admin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    await db.theme.delete({
      where: { id: params.id },
    })

    return NextResponse.json({ message: 'Theme deleted successfully' })
  } catch (error) {
    console.error('Error deleting theme:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
