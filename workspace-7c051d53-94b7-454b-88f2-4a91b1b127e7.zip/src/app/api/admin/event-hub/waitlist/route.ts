import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

// GET /api/admin/event-hub/waitlist - Get all waitlist entries (P1)
export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || (session.user as any).role !== 'admin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const eventId = searchParams.get('eventId')

    const where: any = {}
    if (eventId) {
      where.eventId = eventId
    }

    const waitlist = await db.waitlist.findMany({
      where,
      include: {
        event: {
          select: {
            id: true,
            name: true,
            date: true,
            time: true,
            location: true,
          },
        },
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json(waitlist)
  } catch (error) {
    console.error('Error fetching waitlist:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// POST /api/admin/event-hub/waitlist - Add user to waitlist (P1)
export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await req.json()
    const { eventId } = body

    if (!eventId) {
      return NextResponse.json({ error: 'Event ID is required' }, { status: 400 })
    }

    // Check if already on waitlist
    const existingWaitlist = await db.waitlist.findFirst({
      where: {
        eventId,
        userId: (session.user as any).id,
      },
    })

    if (existingWaitlist) {
      return NextResponse.json({ error: 'You are already on this waitlist' }, { status: 400 })
    }

    // Add to waitlist
    const waitlistEntry = await db.waitlist.create({
      data: {
        eventId,
        userId: (session.user as any).id,
        notified: false,
      },
      include: {
        event: {
          select: {
            id: true,
            name: true,
            date: true,
            time: true,
            location: true,
          },
        },
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
      },
    })

    return NextResponse.json(waitlistEntry, { status: 201 })
  } catch (error) {
    console.error('Error adding to waitlist:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// DELETE /api/admin/event-hub/waitlist/[id] - Remove user from waitlist (P1)
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || (session.user as any).role !== 'admin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    await db.waitlist.delete({
      where: {
        id: params.id,
        userId: (session.user as any).id,
      },
    })

    return NextResponse.json({ message: 'Removed from waitlist successfully' })
  } catch (error) {
    console.error('Error removing from waitlist:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
