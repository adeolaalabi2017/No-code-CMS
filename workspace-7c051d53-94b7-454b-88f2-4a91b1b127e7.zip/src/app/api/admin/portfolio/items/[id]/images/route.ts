import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

// POST /api/admin/portfolio/items/[id]/images - Add portfolio item image (P1)
export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || (session.user as any).role !== 'admin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await req.json()
    const { url, alt, caption, position } = body

    if (!url) {
      return NextResponse.json({ error: 'Image URL is required' }, { status: 400 })
    }

    // Verify portfolio item exists
    const item = await db.portfolioItem.findUnique({
      where: { id: params.id },
    })

    if (!item) {
      return NextResponse.json({ error: 'Portfolio item not found' }, { status: 404 })
    }

    // Create portfolio item image
    const image = await db.portfolioImage.create({
      data: {
        url,
        alt,
        caption,
        position: position || 0,
        portfolioItemId: params.id,
      },
    })

    return NextResponse.json(image, { status: 201 })
  } catch (error) {
    console.error('Error creating portfolio item image:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// PUT /api/admin/portfolio/items/[id]/images/[imageId] - Update portfolio item image (P1)
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string; imageId: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || (session.user as any).role !== 'admin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await req.json()
    const { url, alt, caption, position } = body

    // Update image
    const image = await db.portfolioImage.update({
      where: {
        id: params.imageId,
        portfolioItemId: params.id,
      },
      data: {
        url,
        alt,
        caption,
        position: position || 0,
      },
    })

    return NextResponse.json(image)
  } catch (error) {
    console.error('Error updating portfolio item image:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// DELETE /api/admin/portfolio/items/[id]/images/[imageId] - Delete portfolio item image (P1)
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string; imageId: string } }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || (session.user as any).role !== 'admin') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Delete image
    await db.portfolioImage.delete({
      where: {
        id: params.imageId,
        portfolioItemId: params.id,
      },
    })

    return NextResponse.json({ message: 'Portfolio item image deleted successfully' })
  } catch (error) {
    console.error('Error deleting portfolio item image:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
