import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

// GET /api/admin/portfolio/items - Get all portfolio items
export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const type = searchParams.get('type')
    const status = searchParams.get('status')
    const search = searchParams.get('search')

    const where: any = {}
    if (type) {
      where.type = type
    }
    if (status) {
      where.status = status
    }
    if (search) {
      where.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ]
    }

    const items = await db.portfolioItem.findMany({
      where,
      include: {
        images: {
          orderBy: { position: 'asc' },
        },
        tags: {
          include: {
            tag: true,
          },
        },
      },
      orderBy: [
        { type: 'asc' },
        { createdAt: 'desc' },
      ],
    })

    return NextResponse.json(items)
  } catch (error) {
    console.error('Error fetching portfolio items:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// POST /api/admin/portfolio/items - Create a new portfolio item
export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await req.json()
    const { title, slug, description, type, status, tags } = body

    if (!title || !slug || !type) {
      return NextResponse.json({ error: 'Title, slug, and type are required' }, { status: 400 })
    }

    const item = await db.portfolioItem.create({
      data: {
        title,
        slug,
        description,
        type,
        status: status || 'published',
      },
      include: {
        images: {
          orderBy: { position: 'asc' },
        },
        tags: {
          include: {
            tag: true,
          },
        },
      },
    })

    // Add tags if provided
    if (tags && tags.length > 0) {
      await Promise.all(
        tags.map((tagId: string) =>
          db.portfolioTag.create({
            data: {
              portfolioItemId: item.id,
              tagId,
            },
          })
        )
      )
    }

    return NextResponse.json(item, { status: 201 })
  } catch (error) {
    console.error('Error creating portfolio item:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
