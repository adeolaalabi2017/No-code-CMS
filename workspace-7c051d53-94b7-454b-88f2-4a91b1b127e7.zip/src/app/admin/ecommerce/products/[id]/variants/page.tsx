'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Package, Plus, MoreHorizontal, Edit, Trash2, Eye, Tag, CheckCircle, XCircle, Loader2, Settings, Box } from 'lucide-react'
import { toast } from 'sonner'

interface ProductVariant {
  id: string
  name: string
  sku: string
  price: number
  stock: number
  color: string
  size: string
  material: string
  status: string
  productId: string
}

export default function ProductVariantsPage({
  params,
}: {
  params: { id: string }
}) {
  const { data: session } = useSession()
  const [variants, setVariants] = useState<ProductVariant[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [editingVariant, setEditingVariant] = useState<ProductVariant | null>(null)
  const [variantFormData, setVariantFormData] = useState({
    name: '',
    sku: '',
    price: 0,
    stock: 0,
    color: '',
    size: '',
    material: '',
    status: 'active',
  })

  const isAdmin = (session?.user as any)?.role === 'admin'

  const fetchVariants = async () => {
    try {
      const response = await fetch(`/api/admin/ecommerce/products/${params.id}/variants`)
      if (!response.ok) throw new Error('Failed to fetch variants')

      const data = await response.json()
      setVariants(data)
    } catch (error) {
      console.error('Error fetching variants:', error)
      toast.error('Failed to load variants')
    } finally {
      setIsLoading(false)
    }
  }

  const handleCreateVariant = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!variantFormData.name.trim()) {
      toast.error('Variant name is required')
      return
    }

    setIsSubmitting(true)
    try {
      const response = await fetch(`/api/admin/ecommerce/products/${params.id}/variants`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...variantFormData,
          productId: params.id,
        }),
      })

      if (!response.ok) throw new Error('Failed to create variant')

      toast.success('Product variant created successfully')
      setIsDialogOpen(false)
      setVariantFormData({
        name: '',
        sku: '',
        price: 0,
        stock: 0,
        color: '',
        size: '',
        material: '',
        status: 'active',
      })
      fetchVariants()
    } catch (error) {
      toast.error('Failed to create variant')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleUpdateVariant = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!editingVariant) return

    setIsSubmitting(true)
    try {
      const response = await fetch(`/api/admin/ecommerce/variants/${editingVariant.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(variantFormData),
      })

      if (!response.ok) throw new Error('Failed to update variant')

      toast.success('Product variant updated successfully')
      setIsDialogOpen(false)
      setEditingVariant(null)
      setVariantFormData({
        name: '',
        sku: '',
        price: 0,
        stock: 0,
        color: '',
        size: '',
        material: '',
        status: 'active',
      })
      fetchVariants()
    } catch (error) {
      toast.error('Failed to update variant')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteVariant = async (variantId: string) => {
    if (!confirm('Are you sure you want to delete this variant?')) return

    try {
      const response = await fetch(`/api/admin/ecommerce/variants/${variantId}`, {
        method: 'DELETE',
      })

      if (!response.ok) throw new Error('Failed to delete variant')

      toast.success('Product variant deleted successfully')
      fetchVariants()
    } catch (error) {
      toast.error('Failed to delete variant')
    }
  }

  const handleEditVariant = (variant: ProductVariant) => {
    setVariantFormData({
      name: variant.name,
      sku: variant.sku,
      price: variant.price,
      stock: variant.stock,
      color: variant.color,
      size: variant.size,
      material: variant.material,
      status: variant.status,
    })
    setEditingVariant(variant)
    setIsDialogOpen(true)
  }

  const handleToggleStatus = async (variantId: string, currentStatus: string) => {
    const newStatus = currentStatus === 'active' ? 'inactive' : 'active'
    
    try {
      const response = await fetch(`/api/admin/ecommerce/variants/${variantId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      })

      if (!response.ok) throw new Error('Failed to update variant status')

      toast.success(`Variant ${newStatus === 'active' ? 'activated' : 'deactivated'}`)
      fetchVariants()
    } catch (error) {
      toast.error('Failed to update variant status')
    }
  }

  useEffect(() => {
    fetchVariants()
  }, [params.id])

  const getStatusBadge = (status: string) => {
    const styles = {
      active: 'bg-green-100 text-green-800',
      inactive: 'bg-red-100 text-red-800',
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[status as keyof typeof styles]}`}>
        {status}
      </span>
    )
  }

  const formatPrice = (price: number) => {
    return `$${price.toFixed(2)}`
  }

  const getTotalStock = () => {
    return variants.reduce((total, variant) => total + variant.stock, 0)
  }

  const getTotalValue = () => {
    return variants.reduce((total, variant) => total + (variant.price * variant.stock), 0)
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Product Variants</h1>
            <p className="text-muted-foreground">Loading variants...</p>
          </div>
        </div>
        <Card>
          <CardContent className="p-6">
            <div className="h-96 bg-muted animate-pulse rounded" />
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Product Variants</h1>
          <p className="text-muted-foreground">Manage product variations and inventory</p>
        </div>
        <div className="flex items-center gap-2">
          {isAdmin && (
            <Button onClick={() => {
              setEditingVariant(null)
              setVariantFormData({
                name: '',
                sku: '',
                price: 0,
                stock: 0,
                color: '',
                size: '',
                material: '',
                status: 'active',
              })
              setIsDialogOpen(true)
            }}>
              <Plus className="mr-2 h-4 w-4" />
              Add Variant
            </Button>
          )}
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total Variants
            </CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{variants.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total Stock
            </CardTitle>
            <Box className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{getTotalStock()}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total Value
            </CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatPrice(getTotalValue())}</div>
          </CardContent>
        </Card>
      </div>

      {variants.length === 0 ? (
        <Card>
          <CardContent className="p-12">
            <div className="text-center">
              <Package className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No variants yet</h3>
              <p className="text-muted-foreground">
                {isAdmin ? 'Add your first variant to create product variations' : 'Ask an admin to add product variants'}
              </p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>All Variants</CardTitle>
            <CardDescription>
              Manage product variations and inventory
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Variant</TableHead>
                  <TableHead>SKU</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Stock</TableHead>
                  <TableHead>Color</TableHead>
                  <TableHead>Size</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Value</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {variants.map((variant) => (
                  <TableRow key={variant.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="flex-1">
                          <div className="font-medium">{variant.name}</div>
                          {variant.color && (
                            <Badge variant="outline" className="text-xs mt-1">
                              <Tag className="h-3 w-3" />
                              {variant.color}
                            </Badge>
                          )}
                          {variant.size && (
                            <Badge variant="outline" className="text-xs mt-1">
                              <Settings className="h-3 w-3" />
                              {variant.size}
                            </Badge>
                          )}
                          {variant.material && (
                            <Badge variant="outline" className="text-xs mt-1">
                              <Box className="h-3 w-3" />
                              {variant.material}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="font-mono text-sm">{variant.sku}</div>
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">{formatPrice(variant.price)}</div>
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">{variant.stock}</div>
                    </TableCell>
                    <TableCell>
                      {getStatusBadge(variant.status)}
                    </TableCell>
                    <TableCell>
                      <div className="text-2xl font-bold">{formatPrice(variant.price * variant.stock)}</div>
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <Eye className="mr-2 h-4 w-4" />
                            View Details
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleEditVariant(variant)}>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit Variant
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handleToggleStatus(variant.id, variant.status)}>
                            {variant.status === 'active' ? (
                              <XCircle className="mr-2 h-4 w-4 text-destructive" />
                            ) : (
                              <CheckCircle className="mr-2 h-4 w-4 text-green-600" />
                            )}
                            {variant.status === 'active' ? 'Deactivate' : 'Activate'}
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Settings className="mr-2 h-4 w-4" />
                            Manage Inventory (coming soon)
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            onClick={() => handleDeleteVariant(variant.id)}
                            className="text-destructive"
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete Variant
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Add/Edit Variant Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <form onSubmit={editingVariant ? handleUpdateVariant : handleCreateVariant}>
            <DialogHeader>
              <DialogTitle>
                {editingVariant ? 'Edit Product Variant' : 'Create Product Variant'}
              </DialogTitle>
              <DialogDescription>
                {editingVariant ? 'Update variant information' : 'Add new variant to product'}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="variant-name">Variant Name *</Label>
                  <Input
                    id="variant-name"
                    value={variantFormData.name}
                    onChange={(e) => setVariantFormData({ ...variantFormData, name: e.target.value })}
                    placeholder="e.g. Small Blue T-Shirt"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="variant-sku">SKU</Label>
                  <Input
                    id="variant-sku"
                    value={variantFormData.sku}
                    onChange={(e) => setVariantFormData({ ...variantFormData, sku: e.target.value })}
                    placeholder="e.g. SKU-001"
                  />
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="variant-price">Price ($) *</Label>
                  <Input
                    id="variant-price"
                    type="number"
                    min="0"
                    step="0.01"
                    value={variantFormData.price}
                    onChange={(e) => setVariantFormData({ ...variantFormData, price: parseFloat(e.target.value) })}
                    placeholder="0.00"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="variant-stock">Stock *</Label>
                  <Input
                    id="variant-stock"
                    type="number"
                    min="0"
                    value={variantFormData.stock}
                    onChange={(e) => setVariantFormData({ ...variantFormData, stock: parseInt(e.target.value) })}
                    placeholder="0"
                    required
                  />
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="variant-color">Color</Label>
                  <Input
                    id="variant-color"
                    value={variantFormData.color}
                    onChange={(e) => setVariantFormData({ ...variantFormData, color: e.target.value })}
                    placeholder="e.g. #0066FF"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="variant-size">Size</Label>
                  <Input
                    id="variant-size"
                    value={variantFormData.size}
                    onChange={(e) => setVariantFormData({ ...variantFormData, size: e.target.value })}
                    placeholder="e.g. S, M, L, XL"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="variant-material">Material</Label>
                  <Input
                    id="variant-material"
                    value={variantFormData.material}
                    onChange={(e) => setVariantFormData({ ...variantFormData, material: e.target.value })}
                    placeholder="e.g. Cotton, Polyester"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="variant-status">Status</Label>
                <Select
                  id="variant-status"
                  value={variantFormData.status}
                  onValueChange={(value) => setVariantFormData({ ...variantFormData, status: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsDialogOpen(false)}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {editingVariant ? 'Saving...' : 'Creating...'}
                  </>
                ) : (
                  <>
                    {editingVariant ? (
                      <Edit className="mr-2 h-4 w-4" />
                    ) : (
                      <Plus className="mr-2 h-4 w-4" />
                    )}
                    {editingVariant ? 'Update Variant' : 'Create Variant'}
                  </>
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
