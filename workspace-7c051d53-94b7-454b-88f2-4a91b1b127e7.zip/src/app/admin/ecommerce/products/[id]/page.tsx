'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, Plus, Image as ImageIcon, Upload, Trash2, Edit, DollarSign, Package, Loader2, MoreHorizontal, Eye } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { toast } from 'sonner'
import Link from 'next/link'

interface ProductImage {
  id: string
  url: string
  alt: string | null
  caption: string | null
  position: number
  productId: string
}

interface Product {
  id: string
  name: string
  slug: string
  description: string | null
  price: number
  stock: number
  status: string
  categoryId: string | null
  createdAt: string
  publishedAt: string | null
  images: ProductImage[]
  category: {
    id: string
    name: string
  } | null
  _count: {
    cartItems: number
    orderItems: number
  }
}

export default function ProductDetailPage({
  params,
}: {
  params: { id: string }
}) {
  const { data: session } = useSession()
  const [product, setProduct] = useState<Product | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isImageDialogOpen, setIsImageDialogOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isDeletingImage, setIsDeletingImage] = useState<string | null>(null)
  const [imageFormData, setImageFormData] = useState({
    url: '',
    alt: '',
    caption: '',
    position: 0,
  })
  const [categories, setCategories] = useState<any[]>([])

  const isAdmin = (session?.user as any)?.role === 'admin'

  const fetchProduct = async () => {
    try {
      const response = await fetch(`/api/admin/ecommerce/products/${params.id}`)
      if (!response.ok) throw new Error('Failed to fetch product')

      const data = await response.json()
      setProduct(data)
    } catch (error) {
      console.error('Error fetching product:', error)
      toast.error('Failed to load product data')
    } finally {
      setIsLoading(false)
    }
  }

  const fetchCategories = async () => {
    try {
      const response = await fetch('/api/admin/categories')
      if (!response.ok) throw new Error('Failed to fetch categories')
      const data = await response.json()
      setCategories(data)
    } catch (error) {
      console.error('Error fetching categories:', error)
    }
  }

  useEffect(() => {
    fetchProduct()
    fetchCategories()
  }, [params.id])

  const handleAddImage = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!imageFormData.url.trim()) {
      toast.error('Image URL is required')
      return
    }

    setIsSubmitting(true)
    try {
      const response = await fetch(`/api/admin/ecommerce/products/${params.id}/images`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(imageFormData),
      })

      if (!response.ok) throw new Error('Failed to add product image')

      toast.success('Product image added successfully')
      setIsImageDialogOpen(false)
      setImageFormData({
        url: '',
        alt: '',
        caption: '',
        position: 0,
      })
      fetchProduct()
    } catch (error) {
      toast.error('Failed to add product image')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteImage = async (imageId: string) => {
    if (!confirm('Are you sure you want to delete this image?')) return

    setIsDeletingImage(imageId)
    try {
      const response = await fetch(`/api/admin/ecommerce/products/${params.id}/images/${imageId}`, {
        method: 'DELETE',
      })

      if (!response.ok) throw new Error('Failed to delete product image')

      toast.success('Product image deleted successfully')
      fetchProduct()
    } catch (error) {
      toast.error('Failed to delete product image')
    } finally {
      setIsDeletingImage(null)
    }
  }

  const formatPrice = (price: number) => {
    return `$${price.toFixed(2)}`
  }

  const getStatusBadge = (status: string) => {
    const styles = {
      active: 'bg-green-100 text-green-800',
      inactive: 'bg-gray-100 text-gray-800',
      out_of_stock: 'bg-red-100 text-red-800',
      draft: 'bg-yellow-100 text-yellow-800',
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[status as keyof typeof styles]}`}>
        {status}
      </span>
    )
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Link href="/admin/ecommerce">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Product Details</h1>
            <p className="text-muted-foreground">Loading product...</p>
          </div>
        </div>
        <Card>
          <CardContent className="p-6">
            <div className="h-96 bg-muted animate-pulse rounded" />
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!product) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Link href="/admin/ecommerce">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Product Not Found</h1>
            <p className="text-muted-foreground">The product you're looking for doesn't exist</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/admin/ecommerce">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{product.name}</h1>
            <p className="text-muted-foreground">/{product.slug}</p>
          </div>
        </div>
        <Badge className={product.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
          {product.status}
        </Badge>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Product Information</CardTitle>
              <CardDescription>
                Product details and settings
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <div className="text-sm text-muted-foreground">Price</div>
                    <div className="text-2xl font-bold">{formatPrice(product.price)}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Stock</div>
                    <div className="text-2xl font-bold">{product.stock}</div>
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <div className="text-sm text-muted-foreground">Cart Items</div>
                    <div className="text-2xl font-bold">{product._count.cartItems}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Order Items</div>
                    <div className="text-2xl font-bold">{product._count.orderItems}</div>
                  </div>
                </div>

                <div>
                  <div className="text-sm text-muted-foreground">Status</div>
                  {getStatusBadge(product.status)}
                </div>

                {product.category && (
                  <div>
                    <div className="text-sm text-muted-foreground">Category</div>
                    <Badge variant="secondary">{product.category.name}</Badge>
                  </div>
                )}

                <div>
                  <div className="text-sm text-muted-foreground">Created</div>
                  <div className="text-sm">
                    {new Date(product.createdAt).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                    })}
                  </div>
                </div>

                {product.publishedAt && (
                  <div>
                    <div className="text-sm text-muted-foreground">Published</div>
                    <div className="text-sm">
                      {new Date(product.publishedAt).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                      })}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Product Description</CardTitle>
                <CardDescription>
                  Product details and description
                </CardDescription>
                {isAdmin && (
                  <Button variant="ghost" size="icon">
                    <Edit className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="text-sm text-muted-foreground mb-2">Name</div>
                  <div className="font-semibold text-lg">{product.name}</div>
                </div>

                <div>
                  <div className="text-sm text-muted-foreground mb-2">Slug</div>
                  <div className="font-mono text-sm">/{product.slug}</div>
                </div>

                {product.description && (
                  <div>
                    <div className="text-sm text-muted-foreground mb-2">Description</div>
                    <p className="text-sm">{product.description}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Product Images</CardTitle>
                <CardDescription>
                  Manage product gallery
                </CardDescription>
                {isAdmin && (
                  <Dialog open={isImageDialogOpen} onOpenChange={setIsImageDialogOpen}>
                    <DialogTrigger asChild>
                      <Button size="icon">
                        <Plus className="h-4 w-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <form onSubmit={handleAddImage}>
                        <DialogHeader>
                          <DialogTitle>Add Product Image</DialogTitle>
                          <DialogDescription>
                            Add an image to the product gallery
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <div className="space-y-2">
                            <Label htmlFor="image-url">Image URL *</Label>
                            <Input
                              id="image-url"
                              value={imageFormData.url}
                              onChange={(e) => setImageFormData({ ...imageFormData, url: e.target.value })}
                              placeholder="https://example.com/image.jpg"
                              required
                              disabled={isSubmitting}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="image-alt">Alt Text</Label>
                            <Input
                              id="image-alt"
                              value={imageFormData.alt}
                              onChange={(e) => setImageFormData({ ...imageFormData, alt: e.target.value })}
                              placeholder="Product image alt text"
                              disabled={isSubmitting}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="image-caption">Caption</Label>
                            <Textarea
                              id="image-caption"
                              value={imageFormData.caption}
                              onChange={(e) => setImageFormData({ ...imageFormData, caption: e.target.value })}
                              placeholder="Image caption"
                              disabled={isSubmitting}
                              rows={2}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="image-position">Position</Label>
                            <Input
                              id="image-position"
                              type="number"
                              min="0"
                              value={imageFormData.position}
                              onChange={(e) => setImageFormData({ ...imageFormData, position: parseInt(e.target.value) })}
                              placeholder="0"
                              disabled={isSubmitting}
                            />
                          </div>
                        </div>
                        <DialogFooter>
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => setIsImageDialogOpen(false)}
                            disabled={isSubmitting}
                          >
                            Cancel
                          </Button>
                          <Button type="submit" disabled={isSubmitting}>
                            {isSubmitting ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Adding...
                              </>
                            ) : (
                              <>
                                <Upload className="mr-2 h-4 w-4" />
                                Add Image
                              </>
                            )}
                          </Button>
                        </DialogFooter>
                      </form>
                    </DialogContent>
                  </Dialog>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {product.images.length === 0 ? (
                <div className="text-center py-12">
                  <ImageIcon className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No images yet</h3>
                  <p className="text-muted-foreground">
                    {isAdmin ? 'Add the first image to your product gallery' : 'Ask an admin to add images'}
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {product.images.map((image, index) => (
                    <div key={image.id} className="flex gap-4">
                      <div className="relative w-32 h-32 rounded-lg overflow-hidden border">
                        <img
                          src={image.url}
                          alt={image.alt || product.name}
                          className="w-full h-full object-cover"
                        />
                        {isAdmin && (
                          <div className="absolute top-2 right-2">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8 bg-white/80 hover:bg-white">
                                  {isDeletingImage === image.id ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  ) : (
                                    <MoreHorizontal className="h-4 w-4" />
                                  )}
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem>
                                  <Eye className="mr-2 h-4 w-4" />
                                  View Image (coming soon)
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Edit className="mr-2 h-4 w-4" />
                                  Edit Image (coming soon)
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem
                                  onClick={() => handleDeleteImage(image.id)}
                                  className="text-destructive"
                                  disabled={isDeletingImage === image.id}
                                >
                                  <Trash2 className="mr-2 h-4 w-4" />
                                  Delete Image
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        )}
                      </div>
                      <div className="flex-1 space-y-2">
                        {index === 0 && (
                          <Badge variant="secondary">Cover</Badge>
                        )}
                        {image.alt && (
                          <div>
                            <div className="text-xs text-muted-foreground">Alt Text</div>
                            <div className="text-sm">{image.alt}</div>
                          </div>
                        )}
                        {image.caption && (
                          <div>
                            <div className="text-xs text-muted-foreground">Caption</div>
                            <div className="text-sm">{image.caption}</div>
                          </div>
                        )}
                        <div className="flex items-center gap-2">
                          <div className="text-xs text-muted-foreground">Position</div>
                          <Badge variant="outline">{image.position}</Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
