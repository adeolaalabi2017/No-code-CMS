'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, ShoppingBag, Package, DollarSign, User, Calendar, Loader2, Eye, MoreHorizontal, Edit, ChevronRight, Truck } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { toast } from 'sonner'
import Link from 'next/link'

interface OrderItem {
  id: string
  quantity: number
  price: number
  orderId: string
  product: {
    id: string
    name: string
    images: {
      id: string
      url: string
      alt: string | null
      position: number
    }[]
    category: {
      id: string
      name: string
    } | null
  }
}

interface Order {
  id: string
  total: number
  status: string
  createdAt: string
  items: OrderItem[]
  user: {
    id: string
    name: string
    email: string
    image: string
  }
}

export default function OrderDetailPage({
  params,
}: {
  params: { id: string }
}) {
  const { data: session } = useSession()
  const [order, setOrder] = useState<Order | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const isAdmin = (session?.user as any)?.role === 'admin'

  const fetchOrder = async () => {
    try {
      const response = await fetch(`/api/admin/ecommerce/orders/${params.id}`)
      if (!response.ok) throw new Error('Failed to fetch order')

      const data = await response.json()
      setOrder(data)
    } catch (error) {
      console.error('Error fetching order:', error)
      toast.error('Failed to load order data')
    } finally {
      setIsLoading(false)
    }
  }

  const handleUpdateStatus = async (status: string) => {
    setIsSubmitting(true)
    try {
      const response = await fetch(`/api/admin/ecommerce/orders/${params.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      })

      if (!response.ok) throw new Error('Failed to update order status')

      toast.success('Order status updated successfully')
      fetchOrder()
    } catch (error) {
      toast.error('Failed to update order status')
    } finally {
      setIsSubmitting(false)
    }
  }

  useEffect(() => {
    fetchOrder()
  }, [params.id])

  const formatPrice = (price: number) => {
    return `$${price.toFixed(2)}`
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    })
  }

  const getStatusBadge = (status: string) => {
    const styles = {
      pending: 'bg-yellow-100 text-yellow-800',
      processing: 'bg-blue-100 text-blue-800',
      completed: 'bg-green-100 text-green-800',
      cancelled: 'bg-red-100 text-red-800',
      refunded: 'bg-purple-100 text-purple-800',
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[status as keyof typeof styles]}`}>
        {status}
      </span>
    )
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Link href="/admin/ecommerce">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Order Details</h1>
            <p className="text-muted-foreground">Loading order...</p>
          </div>
        </div>
        <Card>
          <CardContent className="p-6">
            <div className="h-96 bg-muted animate-pulse rounded" />
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!order) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Link href="/admin/ecommerce">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Order Not Found</h1>
            <p className="text-muted-foreground">The order you're looking for doesn't exist</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/admin/ecommerce">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Order Details</h1>
            <p className="text-muted-foreground">/{order.id.slice(0, 8)}</p>
          </div>
        </div>
        <Badge className={order.status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
          {order.status}
        </Badge>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total Order Value
            </CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{formatPrice(order.total)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Number of Items
            </CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{order.items.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Order Status
            </CardTitle>
            {isAdmin && (
              <Button variant="ghost" size="icon">
                <Edit className="h-4 w-4" />
              </Button>
            )}
          </CardHeader>
          <CardContent>
            {getStatusBadge(order.status)}
            {isAdmin && (
              <div className="mt-4 space-y-2">
                <div className="grid gap-2 md:grid-cols-3">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleUpdateStatus('processing')}
                    disabled={isSubmitting}
                  >
                    <Truck className="mr-1 h-3 w-3" />
                    Processing
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleUpdateStatus('completed')}
                    disabled={isSubmitting}
                  >
                    <Package className="mr-1 h-3 w-3" />
                    Completed
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleUpdateStatus('cancelled')}
                    disabled={isSubmitting}
                  >
                    <DollarSign className="mr-1 h-3 w-3" />
                    Cancelled
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Customer Information</CardTitle>
            <CardDescription>
              Order customer details
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                {order.user.image ? (
                  <img
                    src={order.user.image}
                    alt={order.user.name || ''}
                    className="h-16 w-16 rounded-full object-cover"
                  />
                ) : (
                  <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                    <User className="h-8 w-8 text-primary/60" />
                  </div>
                )}
                <div>
                  <div className="font-medium text-lg">{order.user.name}</div>
                  <div className="text-sm text-muted-foreground">{order.user.email}</div>
                </div>
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <div className="text-sm text-muted-foreground">Order Date</div>
                  <div className="font-medium">{formatDate(order.createdAt)}</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Order Items</CardTitle>
            <CardDescription>
              All products in this order
            </CardDescription>
          </CardHeader>
          <CardContent>
            {order.items.length === 0 ? (
              <div className="text-center py-12">
                <ShoppingBag className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No items in order</h3>
                <p className="text-muted-foreground">
                  This order doesn't have any items yet
                </p>
              </div>
            ) : (
              <div className="rounded-md border">
                <Table>
                  <TableBody>
                    {order.items.map((item, index) => (
                      <TableRow key={item.id}>
                        <TableCell className="w-20">
                          {item.product.images.length > 0 ? (
                            <img
                              src={item.product.images[0].url}
                              alt={item.product.images[0].alt || item.product.name}
                              className="h-14 w-14 rounded object-cover"
                            />
                          ) : (
                            <div className="h-14 w-14 rounded bg-primary/10 flex items-center justify-center">
                              <Package className="h-7 w-7 text-primary/60" />
                            </div>
                          )}
                        </TableCell>
                        <TableCell className="flex-1">
                          <div className="space-y-1">
                            <div className="font-medium">{item.product.name}</div>
                            {item.product.category && (
                              <Badge variant="secondary" className="text-xs">
                                {item.product.category.name}
                              </Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="space-y-1">
                            <div>
                              <div className="text-sm text-muted-foreground">Price</div>
                              <div className="font-semibold">{formatPrice(item.price)}</div>
                            </div>
                            <div>
                              <div className="text-sm text-muted-foreground">Quantity</div>
                              <Badge variant="outline" className="text-xs">
                                {item.quantity}
                              </Badge>
                            </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="space-y-1">
                            <div>
                              <div className="text-sm text-muted-foreground">Total</div>
                              <div className="font-semibold text-lg">{formatPrice(item.price * item.quantity)}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <Eye className="mr-2 h-4 w-4" />
                                View Product
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <ChevronRight className="mr-2 h-4 w-4" />
                                View Order Item (coming soon)
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
