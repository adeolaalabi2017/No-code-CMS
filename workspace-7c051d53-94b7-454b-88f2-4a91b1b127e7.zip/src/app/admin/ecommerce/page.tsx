'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { MoreHorizontal, Plus, Search, ShoppingCart, Package, Layers, Trash2, Edit, DollarSign, Loader2, ShoppingBag, Eye, X, Users } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { toast } from 'sonner'

interface Product {
  id: string
  name: string
  slug: string
  description: string | null
  price: number
  stock: number
  status: string
  categoryId: string | null
  createdAt: string
  category: {
    id: string
    name: string
  } | null
  images: {
    id: string
    url: string
    alt: string | null
    position: number
  }[]
  _count: {
    cartItems: number
  }
}

interface CartItem {
  id: string
  quantity: number
  product: {
    id: string
    name: string
    price: number
    images: {
      id: string
      url: string
      alt: string | null
      position: number
    }[]
  }
}

interface Order {
  id: string
  total: number
  status: string
  createdAt: string
  items: {
    product: {
      id: string
      name: string
    }
    quantity: number
    price: number
  }[]
  user: {
    id: string
    name: string
    email: string
  }
}

export default function EcommercePage() {
  const { data: session } = useSession()
  const [activeTab, setActiveTab] = useState<'products' | 'cart' | 'orders'>('products')
  const [isLoading, setIsLoading] = useState(true)
  const [isProductDialogOpen, setIsProductDialogOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isDeleting, setIsDeleting] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [categories, setCategories] = useState<any[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [cartItems, setCartItems] = useState<CartItem[]>([])
  const [orders, setOrders] = useState<Order[]>([])

  const [formData, setFormData] = useState({
    name: '',
    slug: '',
    description: '',
    price: '',
    stock: '0',
    categoryId: '',
    status: 'active',
  })

  const isAdmin = (session?.user as any)?.role === 'admin'

  const fetchCategories = async () => {
    try {
      const response = await fetch('/api/admin/categories')
      if (!response.ok) throw new Error('Failed to fetch categories')
      const data = await response.json()
      setCategories(data)
    } catch (error) {
      console.error('Error fetching categories:', error)
    }
  }

  const fetchProducts = async () => {
    try {
      const params = new URLSearchParams()
      if (statusFilter !== 'all') params.append('status', statusFilter)
      if (searchQuery) params.append('search', searchQuery)

      const response = await fetch(`/api/admin/ecommerce/products?${params.toString()}`)
      if (!response.ok) throw new Error('Failed to fetch products')
      const data = await response.json()
      setProducts(data)
    } catch (error) {
      toast.error('Failed to load products')
    } finally {
      setIsLoading(false)
    }
  }

  const fetchCart = async () => {
    try {
      const response = await fetch('/api/admin/ecommerce/cart')
      if (!response.ok) throw new Error('Failed to fetch cart')
      const data = await response.json()
      setCartItems(data)
    } catch (error) {
      toast.error('Failed to load cart')
    }
  }

  const fetchOrders = async () => {
    try {
      const response = await fetch('/api/admin/ecommerce/orders')
      if (!response.ok) throw new Error('Failed to fetch orders')
      const data = await response.json()
      setOrders(data)
    } catch (error) {
      toast.error('Failed to load orders')
    }
  }

  useEffect(() => {
    fetchCategories()
    if (activeTab === 'products') {
      fetchProducts()
    } else if (activeTab === 'cart') {
      fetchCart()
    } else if (activeTab === 'orders') {
      fetchOrders()
    }
  }, [activeTab, statusFilter, searchQuery])

  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.name.trim() || !formData.slug.trim() || !formData.price) {
      toast.error('Name, slug, and price are required')
      return
    }

    setIsSubmitting(true)
    try {
      const response = await fetch('/api/admin/ecommerce/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          stock: parseInt(formData.stock) || 0,
          price: parseFloat(formData.price),
        }),
      })

      if (!response.ok) throw new Error('Failed to create product')

      toast.success('Product created successfully')
      setIsProductDialogOpen(false)
      setFormData({
        name: '',
        slug: '',
        description: '',
        price: '',
        stock: '0',
        categoryId: '',
        status: 'active',
      })
      fetchProducts()
    } catch (error) {
      toast.error('Failed to create product')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleAddToCart = async (productId: string) => {
    try {
      const response = await fetch('/api/admin/ecommerce/cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId, quantity: 1 }),
      })

      if (!response.ok) throw new Error('Failed to add to cart')

      toast.success('Added to cart successfully')
      fetchCart()
      fetchProducts()
    } catch (error) {
      toast.error('Failed to add to cart')
    }
  }

  const handleUpdateCartItem = async (cartItemId: string, newQuantity: number) => {
    try {
      const response = await fetch(`/api/admin/ecommerce/cart/${cartItemId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ quantity: newQuantity }),
      })

      if (!response.ok) throw new Error('Failed to update cart')

      fetchCart()
    } catch (error) {
      toast.error('Failed to update cart')
    }
  }

  const handleRemoveFromCart = async (cartItemId: string) => {
    try {
      const response = await fetch(`/api/admin/ecommerce/cart/${cartItemId}`, {
        method: 'DELETE',
      })

      if (!response.ok) throw new Error('Failed to remove from cart')

      toast.success('Removed from cart successfully')
      fetchCart()
    } catch (error) {
      toast.error('Failed to remove from cart')
    }
  }

  const handleDeleteProduct = async (productId: string, name: string) => {
    if (!confirm(`Are you sure you want to delete product "${name}"?`)) return

    setIsDeleting(productId)
    try {
      const response = await fetch(`/api/admin/ecommerce/products/${productId}`, {
        method: 'DELETE',
      })

      if (!response.ok) throw new Error('Failed to delete product')

      toast.success('Product deleted successfully')
      fetchProducts()
    } catch (error) {
      toast.error('Failed to delete product')
    } finally {
      setIsDeleting(null)
    }
  }

  const handleUpdateOrderStatus = async (orderId: string, status: string) => {
    try {
      const response = await fetch(`/api/admin/ecommerce/orders/${orderId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      })

      if (!response.ok) throw new Error('Failed to update order')

      toast.success('Order status updated successfully')
      fetchOrders()
    } catch (error) {
      toast.error('Failed to update order status')
    }
  }

  const getStatusBadge = (status: string) => {
    const styles = {
      active: 'bg-green-100 text-green-800',
      inactive: 'bg-gray-100 text-gray-800',
      out_of_stock: 'bg-red-100 text-red-800',
      draft: 'bg-yellow-100 text-yellow-800',
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[status as keyof typeof styles]}`}>
        {status}
      </span>
    )
  }

  const formatPrice = (price: number) => {
    return `$${price.toFixed(2)}`
  }

  const calculateCartTotal = () => {
    return cartItems.reduce((total, item) => {
      return total + (item.product.price * item.quantity)
    }, 0)
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">E-commerce</h1>
          <p className="text-muted-foreground">Manage your online store</p>
        </div>
        <Card>
          <CardContent className="p-6">
            <div className="space-y-4">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="h-24 bg-muted animate-pulse rounded" />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">E-commerce</h1>
          <p className="text-muted-foreground">Manage your online store</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList>
                <TabsTrigger value="products">
                  <Package className="mr-2 h-4 w-4" />
                  Products
                  {products.length > 0 && (
                    <Badge variant="secondary" className="ml-2">
                      {products.length}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="cart">
                  <ShoppingCart className="mr-2 h-4 w-4" />
                  Cart
                  {cartItems.length > 0 && (
                    <Badge variant="secondary" className="ml-2">
                      {cartItems.length}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="orders">
                  <ShoppingBag className="mr-2 h-4 w-4" />
                  Orders
                  {orders.length > 0 && (
                    <Badge variant="secondary" className="ml-2">
                      {orders.length}
                    </Badge>
                  )}
                </TabsTrigger>
              </TabsList>
            </Tabs>
            <Input
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-[250px]"
            />
          </div>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            {/* Products Tab */}
            <TabsContent value="products">
              <div className="space-y-4">
                <div className="flex items-center justify-between mb-4">
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-[150px]">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                      <SelectItem value="out_of_stock">Out of Stock</SelectItem>
                      <SelectItem value="draft">Draft</SelectItem>
                    </SelectContent>
                  </Select>
                  {isAdmin && (
                    <Dialog open={isProductDialogOpen} onOpenChange={setIsProductDialogOpen}>
                      <DialogTrigger asChild>
                        <Button>
                          <Plus className="mr-2 h-4 w-4" />
                          New Product
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <form onSubmit={handleCreateProduct}>
                          <DialogHeader>
                            <DialogTitle>Create Product</DialogTitle>
                            <DialogDescription>
                              Add a new product to your store
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4 py-4">
                            <div className="grid gap-4 md:grid-cols-2">
                              <div className="space-y-2">
                                <Label htmlFor="product-name">Name *</Label>
                                <Input
                                  id="product-name"
                                  value={formData.name}
                                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                  placeholder="Product name"
                                  required
                                  disabled={isSubmitting}
                                />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="product-slug">Slug *</Label>
                                <Input
                                  id="product-slug"
                                  value={formData.slug}
                                  onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                                  placeholder="product-slug"
                                  required
                                  disabled={isSubmitting}
                                />
                              </div>
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="product-description">Description</Label>
                              <Textarea
                                id="product-description"
                                value={formData.description}
                                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                placeholder="Product description"
                                disabled={isSubmitting}
                                rows={3}
                              />
                            </div>
                            <div className="grid gap-4 md:grid-cols-2">
                              <div className="space-y-2">
                                <Label htmlFor="product-price">Price *</Label>
                                <Input
                                  id="product-price"
                                  type="number"
                                  step="0.01"
                                  min="0"
                                  value={formData.price}
                                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                                  placeholder="99.99"
                                  required
                                  disabled={isSubmitting}
                                />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="product-stock">Stock</Label>
                                <Input
                                  id="product-stock"
                                  type="number"
                                  min="0"
                                  value={formData.stock}
                                  onChange={(e) => setFormData({ ...formData, stock: e.target.value })}
                                  placeholder="100"
                                  disabled={isSubmitting}
                                />
                              </div>
                            </div>
                            <div className="grid gap-4 md:grid-cols-2">
                              <div className="space-y-2">
                                <Label htmlFor="product-category">Category</Label>
                                <Select
                                  value={formData.categoryId}
                                  onValueChange={(value) => setFormData({ ...formData, categoryId: value })}
                                  disabled={isSubmitting}
                                >
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select category" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="">No category</SelectItem>
                                    {categories.map((cat) => (
                                      <SelectItem key={cat.id} value={cat.id}>
                                        {cat.name}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="product-status">Status</Label>
                                <Select
                                  value={formData.status}
                                  onValueChange={(value) => setFormData({ ...formData, status: value })}
                                  disabled={isSubmitting}
                                >
                                  <SelectTrigger>
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="active">Active</SelectItem>
                                    <SelectItem value="inactive">Inactive</SelectItem>
                                    <SelectItem value="out_of_stock">Out of Stock</SelectItem>
                                    <SelectItem value="draft">Draft</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                          </div>
                          <DialogFooter>
                            <Button
                              type="button"
                              variant="outline"
                              onClick={() => setIsProductDialogOpen(false)}
                              disabled={isSubmitting}
                            >
                              Cancel
                            </Button>
                            <Button type="submit" disabled={isSubmitting}>
                              {isSubmitting ? 'Creating...' : 'Create Product'}
                            </Button>
                          </DialogFooter>
                        </form>
                      </DialogContent>
                    </Dialog>
                  )}
                </div>

                {products.length === 0 ? (
                  <div className="text-center py-12">
                    <Package className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">No products yet</h3>
                    <p className="text-muted-foreground">
                      {isAdmin ? 'Create your first product to get started' : 'Ask an admin to create products'}
                    </p>
                  </div>
                ) : (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Product</TableHead>
                          <TableHead>Price</TableHead>
                          <TableHead>Stock</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Cart</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {products.map((product) => (
                          <TableRow key={product.id}>
                            <TableCell>
                              <div className="flex items-center gap-3">
                                {product.images.length > 0 ? (
                                  <img
                                    src={product.images[0].url}
                                    alt={product.images[0].alt || product.name}
                                    className="h-10 w-10 rounded object-cover"
                                  />
                                ) : (
                                  <div className="h-10 w-10 rounded bg-primary/10 flex items-center justify-center">
                                    <Package className="h-5 w-5 text-primary/60" />
                                  </div>
                                )}
                                <div>
                                  <div className="font-medium">{product.name}</div>
                                  <div className="text-sm text-muted-foreground">/{product.slug}</div>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              {formatPrice(product.price)}
                            </TableCell>
                            <TableCell>
                              {product.stock}
                            </TableCell>
                            <TableCell>{getStatusBadge(product.status)}</TableCell>
                            <TableCell>
                              {product.category ? (
                                <Badge variant="secondary">
                                  {product.category.name}
                                </Badge>
                              ) : (
                                <span className="text-sm text-muted-foreground">-</span>
                              )}
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary">
                                {product._count.cartItems}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" disabled={isDeleting === product.id}>
                                    {isDeleting === product.id ? (
                                      <Loader2 className="h-4 w-4 animate-spin" />
                                    ) : (
                                      <MoreHorizontal className="h-4 w-4" />
                                    )}
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem onClick={() => handleAddToCart(product.id)}>
                                    <ShoppingCart className="mr-2 h-4 w-4" />
                                    Add to Cart
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem>
                                    <Eye className="mr-2 h-4 w-4" />
                                    View Product (coming soon)
                                  </DropdownMenuItem>
                                  <DropdownMenuItem>
                                    <Edit className="mr-2 h-4 w-4" />
                                    Edit Product (coming soon)
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem
                                    onClick={() => handleDeleteProduct(product.id, product.name)}
                                    className="text-destructive"
                                    disabled={isDeleting === product.id}
                                  >
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    Delete Product
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </div>
            </TabsContent>

            {/* Cart Tab */}
            <TabsContent value="cart">
              {cartItems.length === 0 ? (
                <div className="text-center py-12">
                  <ShoppingCart className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">Your cart is empty</h3>
                  <p className="text-muted-foreground">
                    Browse products and add items to your cart
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border-b">
                    <h3 className="text-lg font-semibold">Your Cart ({cartItems.length} items)</h3>
                    <div className="text-xl font-bold">
                      Total: {formatPrice(calculateCartTotal())}
                    </div>
                  </div>
                  <div className="rounded-md border">
                    <Table>
                      <TableBody>
                        {cartItems.map((item) => (
                          <TableRow key={item.id}>
                            <TableCell>
                              <div className="flex items-center gap-3">
                                {item.product.images.length > 0 ? (
                                  <img
                                    src={item.product.images[0].url}
                                    alt={item.product.images[0].alt || item.product.name}
                                    className="h-12 w-12 rounded object-cover"
                                  />
                                ) : (
                                  <div className="h-12 w-12 rounded bg-primary/10 flex items-center justify-center">
                                    <Package className="h-6 w-6 text-primary/60" />
                                  </div>
                                )}
                                <div>
                                  <div className="font-medium">{item.product.name}</div>
                                  <div className="text-sm text-muted-foreground">
                                    {formatPrice(item.product.price)} x {item.quantity}
                                  </div>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleUpdateCartItem(item.id, item.quantity - 1)}
                                  disabled={item.quantity <= 1}
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                                <span className="font-medium">{item.quantity}</span>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleUpdateCartItem(item.id, item.quantity + 1)}
                                  disabled={item.quantity >= 99}
                                >
                                  <Plus className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                            <TableCell>
                              {formatPrice(item.product.price * item.quantity)}
                            </TableCell>
                            <TableCell className="text-right">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleRemoveFromCart(item.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              )}
            </TabsContent>

            {/* Orders Tab */}
            <TabsContent value="orders">
              {orders.length === 0 ? (
                <div className="text-center py-12">
                  <ShoppingBag className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No orders yet</h3>
                  <p className="text-muted-foreground">
                    Orders will appear here once customers checkout
                  </p>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Order ID</TableHead>
                        <TableHead>Customer</TableHead>
                        <TableHead>Total</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Items</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {orders.map((order) => (
                        <TableRow key={order.id}>
                          <TableCell className="font-medium">{order.id.slice(0, 8)}...</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                                <Users className="h-4 w-4 text-primary/60" />
                              </div>
                              <div>
                                <div className="text-sm font-medium">{order.user.name}</div>
                                <div className="text-xs text-muted-foreground">{order.user.email}</div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="text-lg font-bold">
                            {formatPrice(order.total)}
                          </TableCell>
                          <TableCell>{getStatusBadge(order.status)}</TableCell>
                          <TableCell>
                            {new Date(order.createdAt).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'short',
                              day: 'numeric',
                            })}
                          </TableCell>
                          <TableCell>
                            <Badge variant="secondary">{order.items.length} items</Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuSeparator />
                                {isAdmin && order.status === 'pending' && (
                                  <>
                                    <DropdownMenuItem onClick={() => handleUpdateOrderStatus(order.id, 'processing')}>
                                      <Package className="mr-2 h-4 w-4" />
                                      Mark Processing
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onClick={() => handleUpdateOrderStatus(order.id, 'completed')}>
                                      <Eye className="mr-2 h-4 w-4" />
                                      Mark Completed
                                    </DropdownMenuItem>
                                  </>
                                )}
                                <DropdownMenuSeparator />
                                <DropdownMenuItem>
                                  <Eye className="mr-2 h-4 w-4" />
                                  View Order Details (coming soon)
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Trash2 className="mr-2 h-4 w-4" />
                                  Delete Order (coming soon)
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
