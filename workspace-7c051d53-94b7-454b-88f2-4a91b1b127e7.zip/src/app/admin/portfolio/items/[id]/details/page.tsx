'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs'
import { FolderKanban, LayoutGrid, LayoutList, Plus, MoreHorizontal, Edit, Trash2, Eye, Settings, Loader2, Image as ImageIcon, Download, ExternalLink, Code, Briefcase, Award, MessageSquare, Calendar, Link, Github, Twitter, Linkedin, User } from 'lucide-react'
import { toast } from 'sonner'

interface PortfolioItem {
  id: string
  title: string
  slug: string
  description: string | null
  type: string
  status: string
  projectId: string
  technologies: string | null
  stack: string | null
  githubUrl: string | null
  dribbbleUrl: string | null
  behanceUrl: string | null
  startDate: string
  endDate: string | null
  images: {
    id: string
    url: string
    alt: string | null
    caption: string | null
    position: number
  }[]
  _count: {
    images: number
    views: number
  }
  createdAt: string
}

interface CaseStudy {
  id: string
  title: string
  slug: string
  client: string
  role: string
  project: string
  result: string
  metrics: string | null
  images: string[]
  createdAt: string
}

export default function PortfolioItemDetailsPage({
  params,
}: {
  params: { id: string }
}) {
  const { data: session } = useSession()
  const [item, setItem] = useState<PortfolioItem | null>(null)
  const [caseStudies, setCaseStudies] = useState<CaseStudy[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false)
  const [isImageDialogOpen, setIsImageDialogOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [imageFormData, setImageFormData] = useState({
    url: '',
    alt: '',
    caption: '',
    position: 0,
  })
  const [isEditing, setIsEditing] = useState<string | null>(null)

  const isAdmin = (session?.user as any)?.role === 'admin'

  const fetchItem = async () => {
    try {
      const response = await fetch(`/api/admin/portfolio/items/${params.id}`)
      if (!response.ok) throw new Error('Failed to fetch portfolio item')

      const data = await response.json()
      setItem(data)
    } catch (error) {
      console.error('Error fetching item:', error)
      toast.error('Failed to load item data')
    } finally {
      setIsLoading(false)
    }
  }

  const fetchCaseStudies = async () => {
    try {
      const response = await fetch(`/api/admin/portfolio/items/${params.id}/case-studies`)
      if (!response.ok) throw new Error('Failed to fetch case studies')

      const data = await response.json()
      setCaseStudies(data)
    } catch (error) {
      console.error('Error fetching case studies:', error)
      toast.error('Failed to load case studies')
    }
  }

  useEffect(() => {
    fetchItem()
    fetchCaseStudies()
  }, [params.id])

  const handleUpdateStatus = async (newStatus: string) => {
    try {
      const response = await fetch(`/api/admin/portfolio/items/${params.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      })

      if (!response.ok) throw new Error('Failed to update item status')

      toast.success('Item status updated successfully')
      fetchItem()
    } catch (error) {
      toast.error('Failed to update item status')
    }
  }

  const handleDeleteImage = async (imageId: string) => {
    if (!confirm('Are you sure you want to delete this image?')) return

    try {
      const response = await fetch(`/api/admin/portfolio/items/${params.id}/images/${imageId}`, {
        method: 'DELETE',
      })

      if (!response.ok) throw new Error('Failed to delete image')

      toast.success('Image deleted successfully')
      fetchItem()
    } catch (error) {
      toast.error('Failed to delete image')
    }
  }

  const handleAddImage = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!imageFormData.url.trim()) {
      toast.error('Image URL is required')
      return
    }

    setIsSubmitting(true)
    try {
      const response = await fetch(`/api/admin/portfolio/items/${params.id}/images`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(imageFormData),
      })

      if (!response.ok) throw new Error('Failed to add image')

      toast.success('Image added successfully')
      setIsImageDialogOpen(false)
      setImageFormData({
        url: '',
        alt: '',
        caption: '',
        position: 0,
      })
      fetchItem()
    } catch (error) {
      toast.error('Failed to add image')
    } finally {
      setIsSubmitting(false)
    }
  }

  const getStatusBadge = (status: string) => {
    const styles = {
      draft: 'bg-gray-100 text-gray-800',
      published: 'bg-green-100 text-green-800',
      archived: 'bg-purple-100 text-purple-800',
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[status as keyof typeof styles]}`}>
        {status}
      </span>
    )
  }

  const getTypeBadge = (type: string) => {
    const styles = {
      project: 'bg-blue-100 text-blue-800',
      experience: 'bg-purple-100 text-purple-800',
      testimonial: 'bg-pink-100 text-pink-800',
    }
    const icons = {
      project: <Briefcase className="h-3 w-3" />,
      experience: <Award className="h-3 w-3" />,
      testimonial: <MessageSquare className="h-3 w-3" />,
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[type as keyof typeof styles]}`}>
        {icons[type as keyof typeof icons]}
        {type}
      </span>
    )
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Portfolio Item</h1>
            <p className="text-muted-foreground">Loading portfolio item...</p>
        </div>
        <Card>
          <CardContent className="p-6">
                <div className="h-96 bg-muted animate-pulse rounded" />
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!item) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Item Not Found</h1>
            <p className="text-muted-foreground">The portfolio item you're looking for doesn't exist</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{item.title}</h1>
          <p className="text-muted-foreground">/{item.slug}</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon">
            <Link href="/admin/portfolio">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Item Information Card */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Project Information
              </CardTitle>
              {isAdmin && (
                <Button variant="ghost" size="icon">
                  <Edit className="h-4 w-4" />
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <div className="text-sm text-muted-foreground">Type</div>
                  <div className="font-semibold">{getTypeBadge(item.type)}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Status</div>
                  <div>{getStatusBadge(item.status)}</div>
                </div>
              </div>

              <div>
                <div className="text-sm text-muted-foreground">Project ID</div>
                <div className="font-mono text-sm">{item.projectId}</div>
              </div>

              <div>
                <div className="text-sm text-muted-foreground">Technologies</div>
                <div className="font-medium">{item.technologies || '-'}</div>
              </div>

              <div>
                <div className="text-sm text-muted-foreground">Tech Stack</div>
                <div className="font-medium">{item.stack || '-'}</div>
              </div>

              <div>
                <div className="text-sm text-muted-foreground">Start Date</div>
                <div className="font-medium">{new Date(item.startDate).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'short',
                  day: 'numeric',
                })}</div>
              </div>

              <div>
                <div className="text-sm text-muted-foreground">End Date</div>
                <div className="font-medium">{item.endDate ? new Date(item.endDate).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'short',
                  day: 'numeric',
                }) : '-'}</div>
              </div>
            </div>

            {item.description && (
              <div>
                <div className="text-sm text-muted-foreground">Description</div>
                <p className="text-sm mt-1">{item.description}</p>
              </div>
            )}
          </div>
          </CardContent>
        </Card>

        {/* Images Card */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Project Gallery
              </CardTitle>
              <div className="flex items-center gap-2">
                <div className="text-sm text-muted-foreground">{item._count.images} images</div>
                {isAdmin && (
                  <Button variant="ghost" size="icon" onClick={() => setIsImageDialogOpen(true)}>
                    <Plus className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {item.images.length === 0 ? (
              <div className="text-center py-12">
                <ImageIcon className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No images yet</h3>
                <p className="text-muted-foreground">
                  {isAdmin ? 'Add images to showcase this project' : 'Ask an admin to add images'}
                </p>
              </div>
            ) : (
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {item.images.map((image, index) => (
                  <div key={image.id} className="relative">
                    <div className="aspect-square rounded-lg overflow-hidden border">
                      <img
                        src={image.url}
                        alt={image.alt || item.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    {index === 0 && (
                      <Badge className="absolute top-2 left-2" variant="secondary">
                        Cover
                      </Badge>
                    )}
                    {isAdmin && (
                      <div className="absolute top-2 right-2">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8 bg-white/80 hover:bg-white">
                              {index === 0 ? (
                                <Eye className="h-4 w-4" />
                              ) : (
                                <Settings className="h-4 w-4" />
                              )}
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                              <Eye className="mr-2 h-4 w-4" />
                              Set as Cover
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit Image (coming soon)
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onClick={() => handleDeleteImage(image.id)}
                              className="text-destructive"
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Delete Image
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Case Studies Card */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Case Studies & Success Stories
              </CardTitle>
              <div className="text-sm text-muted-foreground">{caseStudies.length} case studies</div>
            </div>
          </CardHeader>
          <CardContent>
            {caseStudies.length === 0 ? (
              <div className="text-center py-12">
                <MessageSquare className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No case studies yet</h3>
                <p className="text-muted-foreground">
                  {isAdmin ? 'Add case studies to showcase your work and results' : 'Ask an admin to add case studies'}
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {caseStudies.map((caseStudy) => (
                  <div key={caseStudy.id} className="p-4 bg-muted/30 rounded-lg">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <div className="font-medium">{caseStudy.title}</div>
                        <div className="text-xs text-muted-foreground">
                          {caseStudy.client} • {caseStudy.role}
                        </div>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {new Date(caseStudy.createdAt).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric',
                        })}
                      </div>
                    </div>
                    {caseStudy.result && (
                      <Badge variant="secondary">
                        {caseStudy.result}
                      </Badge>
                    )}
                    {caseStudy.metrics && (
                      <Badge variant="outline">
                        {caseStudy.metrics}
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm mt-2">{caseStudy.description || 'No description'}</p>
                  <div className="flex items-center gap-4 mt-3">
                    {caseStudy.images.slice(0, 3).map((image) => (
                      <img
                        key={image}
                        src={image}
                        alt={caseStudy.title}
                        className="h-16 w-16 rounded-md object-cover"
                      />
                    ))}
                    <a
                      href={`https://github.com/${item.githubUrl}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline flex items-center gap-2"
                    >
                      <Github className="h-4 w-4" />
                      View Project
                    </a>
                    {item.dribbbleUrl && (
                      <a
                        href={`https://dribbble.com/${item.dribbbleUrl}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-pink-600 hover:underline flex items-center gap-2"
                      >
                        <ImageIcon className="h-4 w-4" />
                        Dribbble
                      </a>
                    )}
                    {item.behanceUrl && (
                      <a
                        href={`https://behance.net/${item.behanceUrl}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-900 hover:underline flex items-center gap-2"
                      >
                        <Twitter className="h-4 w-4" />
                        Behance
                      </a>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Add Image Dialog */}
      <Dialog open={isImageDialogOpen} onOpenChange={setIsImageDialogOpen}>
        <form onSubmit={handleAddImage}>
          <DialogHeader>
            <DialogTitle>Add Portfolio Image</DialogTitle>
            <DialogDescription>
              Add an image to the project gallery
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="image-url">Image URL *</Label>
              <Input
                id="image-url"
                value={imageFormData.url}
                onChange={(e) => setImageFormData({ ...imageFormData, url: e.target.value })}
                placeholder="https://example.com/image.jpg"
                required
                disabled={isSubmitting}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="image-alt">Alt Text</Label>
              <Input
                id="image-alt"
                value={imageFormData.alt}
                onChange={(e) => setImageFormData({ ...imageFormData, alt: e.target.value })}
                placeholder="Project image alt text"
                disabled={isSubmitting}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="image-caption">Caption</Label>
              <Input
                id="image-caption"
                value={imageFormData.caption}
                onChange={(e) => setImageFormData({ ...imageFormData, caption: e.target.value })}
                placeholder="Image caption"
                disabled={isSubmitting}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="image-position">Position</Label>
              <Input
                id="image-position"
                type="number"
                min="0"
                value={imageFormData.position}
                onChange={(e) => setImageFormData({ ...imageFormData, position: parseInt(e.target.value) })}
                placeholder="0"
                disabled={isSubmitting}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsImageDialogOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Adding...
                </>
              ) : (
                <>
                  <Upload className="mr-2 h-4 w-4" />
                  Add Image
                </>
              )}
            </Button>
          </DialogFooter>
        </form>
      </Dialog>
    </div>
  )
}
