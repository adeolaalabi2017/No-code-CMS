'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, Building2, Phone, Mail, Globe, MapPin, Plus, Star, Loader2, MoreHorizontal, Eye, Edit, Trash2 } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { toast } from 'sonner'
import Link from 'next/link'

interface Listing {
  id: string
  title: string
  slug: string
  description: string | null
  price: number | null
  status: string
  vendorId: string
  vendor: {
    id: string
    name: string
    email: string
    phone: string | null
  }
  location: string | null
  address: string | null
  phone: string | null
  email: string | null
  website: string | null
  createdAt: string
  publishedAt: string | null
  images: {
    id: string
    url: string
    alt: string | null
    caption: string | null
    position: number
  }[]
  _count: {
    listings: number
  }
}

interface Review {
  id: string
  rating: number
  title: string | null
  content: string
  status: string
  createdAt: string
  author: {
    id: string
    name: string
    email: string
    image: string
  }
  listing: {
    id: string
    title: string
    slug: string
  }
}

export default function BusinessProfilePage({
  params,
}: {
  params: { id: string }
}) {
  const { data: session } = useSession()
  const [listing, setListing] = useState<Listing | null>(null)
  const [reviews, setReviews] = useState<Review[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isDeletingReview, setIsDeletingReview] = useState<string | null>(null)
  const [isReviewDialogOpen, setIsReviewDialogOpen] = useState(false)
  const [isSubmittingReview, setIsSubmittingReview] = useState(false)
  const [reviewFormData, setReviewFormData] = useState({
    rating: 5,
    title: '',
    content: '',
    status: 'pending',
  })

  const isAdmin = (session?.user as any)?.role === 'admin'

  const fetchListing = async () => {
    try {
      const response = await fetch(`/api/admin/directory/listings`)
      if (!response.ok) throw new Error('Failed to fetch listings')

      const data = await response.json()
      const foundListing = data.find((l: Listing) => l.id === params.id)

      if (foundListing) {
        setListing(foundListing)
      } else {
        toast.error('Listing not found')
      }
    } catch (error) {
      console.error('Error fetching listing:', error)
      toast.error('Failed to load listing data')
    } finally {
      setIsLoading(false)
    }
  }

  const fetchReviews = async () => {
    try {
      const response = await fetch(`/api/admin/directory/views?listingId=${params.id}`)
      if (!response.ok) throw new Error('Failed to fetch reviews')

      const data = await response.json()
      setReviews(data)
    } catch (error) {
      console.error('Error fetching reviews:', error)
      toast.error('Failed to load reviews')
    }
  }

  useEffect(() => {
    fetchListing()
    fetchReviews()
  }, [params.id])

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!reviewFormData.rating || !reviewFormData.content.trim()) {
      toast.error('Rating and content are required')
      return
    }

    setIsSubmittingReview(true)
    try {
      const response = await fetch('/api/admin/directory/views', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...reviewFormData,
          listingId: params.id,
        }),
      })

      if (!response.ok) throw new Error('Failed to submit review')

      toast.success('Review submitted successfully')
      setIsReviewDialogOpen(false)
      setReviewFormData({
        rating: 5,
        title: '',
        content: '',
        status: 'pending',
      })
      fetchReviews()
      fetchListing()
    } catch (error) {
      toast.error('Failed to submit review')
    } finally {
      setIsSubmittingReview(false)
    }
  }

  const handleDeleteReview = async (reviewId: string) => {
    if (!confirm('Are you sure you want to delete this review?')) return

    setIsDeletingReview(reviewId)
    try {
      const response = await fetch(`/api/admin/directory/views/${reviewId}`, {
        method: 'DELETE',
      })

      if (!response.ok) throw new Error('Failed to delete review')

      toast.success('Review deleted successfully')
      fetchReviews()
      fetchListing()
    } catch (error) {
      toast.error('Failed to delete review')
    } finally {
      setIsDeletingReview(null)
    }
  }

  const getRatingStars = (rating: number) => {
    return '★'.repeat(rating) + '☆'.repeat(5 - rating)
  }

  const getStatusBadge = (status: string) => {
    const styles = {
      active: 'bg-green-100 text-green-800',
      pending: 'bg-yellow-100 text-yellow-800',
      suspended: 'bg-red-100 text-red-800',
      draft: 'bg-gray-100 text-gray-800',
      published: 'bg-blue-100 text-blue-800',
      archived: 'bg-purple-100 text-purple-800',
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[status as keyof typeof styles]}`}>
        {status}
      </span>
    )
  }

  const getReviewStatusBadge = (status: string) => {
    const styles = {
      pending: 'bg-yellow-100 text-yellow-800',
      approved: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800',
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[status as keyof typeof styles]}`}>
        {status}
      </span>
    )
  }

  const calculateAverageRating = () => {
    if (reviews.length === 0) return 0
    const sum = reviews.reduce((acc, review) => acc + review.rating, 0)
    return Math.round(sum / reviews.length)
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Link href="/admin/directory">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Business Profile</h1>
            <p className="text-muted-foreground">Loading business data...</p>
          </div>
        </div>
        <Card>
          <CardContent className="p-6">
            <div className="h-96 bg-muted animate-pulse rounded" />
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!listing) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Link href="/admin/directory">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Business Not Found</h1>
            <p className="text-muted-foreground">The business you're looking for doesn't exist</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/admin/directory">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{listing.title}</h1>
            <p className="text-muted-foreground">/{listing.slug}</p>
          </div>
        </div>
        <Badge className={listing.status === 'published' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
          {listing.status}
        </Badge>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Business Information</CardTitle>
              <CardDescription>
                Contact details and business description
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="text-sm text-muted-foreground mb-2">Business Name</div>
                  <div className="font-semibold text-lg">{listing.title}</div>
                </div>

                {listing.description && (
                  <div>
                    <div className="text-sm text-muted-foreground mb-2">Description</div>
                    <p className="text-sm">{listing.description}</p>
                  </div>
                )}

                <div className="grid gap-4 md:grid-cols-3">
                  <div>
                    <div className="text-sm text-muted-foreground">Location</div>
                    <div className="font-medium flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span>{listing.location || '-'}</span>
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Phone</div>
                    <div className="font-medium flex items-center gap-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span>{listing.phone || listing.vendor.phone || '-'}</span>
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Website</div>
                    <div className="font-medium flex items-center gap-2">
                      <Globe className="h-4 w-4 text-muted-foreground" />
                      {listing.website ? (
                        <a
                          href={listing.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:underline"
                        >
                          Visit Website
                        </a>
                      ) : '-'}
                    </div>
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <div className="text-sm text-muted-foreground">Vendor</div>
                    <div className="font-medium">{listing.vendor.name}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Vendor Email</div>
                    <div className="font-medium text-sm">{listing.vendor.email}</div>
                  </div>
                </div>

                <div className="space-y-2 pt-4 border-t">
                  <div className="flex items-center gap-2">
                    <div className="text-sm text-muted-foreground">Status</div>
                    {getStatusBadge(listing.status)}
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-sm text-muted-foreground">Published</div>
                    <div className="text-sm">
                      {listing.publishedAt ? new Date(listing.publishedAt).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                      }) : '-'}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Business Gallery</CardTitle>
                <CardDescription>
                  Business images and media
                </CardDescription>
              </div>
            </CardHeader>
            <CardContent>
              {listing.images.length === 0 ? (
                <div className="text-center py-12">
                  <Building2 className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No images yet</h3>
                  <p className="text-muted-foreground">
                    {isAdmin ? 'Add images to this business' : 'Ask an admin to add images'}
                  </p>
                </div>
              ) : (
                <div className="grid gap-4 md:grid-cols-3">
                  {listing.images.map((image, index) => (
                    <div key={image.id} className="relative">
                      <div className="aspect-square rounded-lg overflow-hidden border">
                        <img
                          src={image.url}
                          alt={image.alt || listing.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      {index === 0 && (
                        <Badge className="absolute top-2 right-2" variant="secondary">
                          Cover
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Customer Reviews</CardTitle>
              <CardDescription>
                All reviews for this business
              </CardDescription>
              <div className="flex items-center gap-2">
                {reviews.length > 0 && (
                  <div className="flex items-center gap-1">
                    <div className="text-sm text-muted-foreground">Average Rating</div>
                    <div className="text-lg font-semibold">{getRatingStars(calculateAverageRating())}</div>
                  </div>
                )}
                <Badge variant="secondary">{reviews.length}</Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {reviews.length === 0 ? (
              <div className="text-center py-12">
                <Star className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No reviews yet</h3>
                <p className="text-muted-foreground">
                  {isAdmin ? 'Create reviews to get started' : 'Be the first to review this business'}
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex gap-4">
                  <select
                    value={reviews[0]?.status || 'all'}
                    onChange={(e) => {
                      const status = e.target.value
                      const filteredReviews = status === 'all'
                        ? reviews
                        : reviews.filter((review) => review.status === status)
                      setReviews(filteredReviews)
                    }}
                    className="border border-border rounded-md px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
                  >
                    <option value="all">All Reviews ({reviews.length})</option>
                    <option value="pending">Pending ({reviews.filter((r: Review) => r.status === 'pending').length})</option>
                    <option value="approved">Approved ({reviews.filter((r: Review) => r.status === 'approved').length})</option>
                    <option value="rejected">Rejected ({reviews.filter((r: Review) => r.status === 'rejected').length})</option>
                  </select>

                  {isAdmin && (
                    <Button
                      variant="outline"
                      onClick={() => setIsReviewDialogOpen(true)}
                    >
                      <Plus className="mr-2 h-4 w-4" />
                      Write Review
                    </Button>
                  )}
                </div>

                <div className="space-y-4">
                  {reviews.map((review) => (
                    <div key={review.id} className="p-4 bg-muted/30 rounded-lg space-y-3">
                      <div className="flex items-start gap-3">
                        {review.author.image ? (
                          <img
                            src={review.author.image}
                            alt={review.author.name || ''}
                            className="h-12 w-12 rounded-full object-cover"
                          />
                        ) : (
                          <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                            <Globe className="h-6 w-6 text-primary/60" />
                          </div>
                        )}
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="font-medium">{review.author.name}</div>
                            <div className="flex items-center gap-2">
                              <div className="text-lg">{getRatingStars(review.rating)}</div>
                              {getReviewStatusBadge(review.status)}
                            </div>
                            </div>
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {new Date(review.createdAt).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'short',
                              day: 'numeric',
                            })}
                          </div>
                          {review.title && (
                            <div className="font-medium text-sm">{review.title}</div>
                          )}
                          <p className="text-sm">{review.content}</p>
                          <div className="pt-3 border-t">
                            <div className="flex items-center justify-between">
                              <div className="text-xs text-muted-foreground">For: {review.listing.title}</div>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" disabled={isDeletingReview === review.id}>
                                    {isDeletingReview === review.id ? (
                                      <Loader2 className="h-4 w-4 animate-spin" />
                                    ) : (
                                      <MoreHorizontal className="h-4 w-4" />
                                    )}
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem>
                                    <Eye className="mr-2 h-4 w-4" />
                                    View Full Review
                                  </DropdownMenuItem>
                                  <DropdownMenuItem>
                                    <Edit className="mr-2 h-4 w-4" />
                                    Edit Status (coming soon)
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem
                                    onClick={() => handleDeleteReview(review.id)}
                                    className="text-destructive"
                                    disabled={isDeletingReview === review.id}
                                  >
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    Delete Review
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

      <Dialog open={isReviewDialogOpen} onOpenChange={setIsReviewDialogOpen}>
        <DialogContent>
          <form onSubmit={handleSubmitReview}>
            <DialogHeader>
              <DialogTitle>Write a Review</DialogTitle>
              <DialogDescription>
                Share your experience with {listing.title}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="rating">Rating *</Label>
                <select
                  id="rating"
                  value={reviewFormData.rating}
                  onChange={(e) => setReviewFormData({ ...reviewFormData, rating: parseInt(e.target.value) })}
                  className="w-full border border-border rounded-md px-3 py-2 bg-background focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
                >
                  <option value={1}>1 Star</option>
                  <option value={2}>2 Stars</option>
                  <option value={3}>3 Stars</option>
                  <option value={4}>4 Stars</option>
                  <option value={5}>5 Stars</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={reviewFormData.title}
                  onChange={(e) => setReviewFormData({ ...reviewFormData, title: e.target.value })}
                  placeholder="Review title (optional)"
                  disabled={isSubmittingReview}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="content">Review Content *</Label>
                <textarea
                  id="content"
                  value={reviewFormData.content}
                  onChange={(e) => setReviewFormData({ ...reviewFormData, content: e.target.value })}
                  placeholder="Share your experience..."
                  rows={4}
                  className="w-full min-h-[120px] rounded-md border border-input px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus:ring-2 focus:ring-inset focus:ring-offset-2"
                  required
                  disabled={isSubmittingReview}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsReviewDialogOpen(false)}
                disabled={isSubmittingReview}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmittingReview}>
                {isSubmittingReview ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  <>
                    <Plus className="mr-2 h-4 w-4" />
                    Submit Review
                  </>
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
