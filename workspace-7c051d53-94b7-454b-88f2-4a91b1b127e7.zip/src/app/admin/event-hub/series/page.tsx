'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Calendar, Plus, MoreHorizontal, Edit, Trash2, Eye, QrCode, Download, Check, Loader2, Settings, MapPin, Clock, Ticket } from 'lucide-react'
import { toast } from 'sonner'

interface EventSeries {
  id: string
  name: string
  description: string
  recurring: boolean
  frequency: string
  createdAt: string
  eventCount: number
}

interface EventSeriesFormData {
  name: string
  description: string
  recurring: boolean
  frequency: string
}

export default function EventSeriesPage() {
  const { data: session } = useSession()
  const [series, setSeries] = useState<EventSeries[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [editingSeries, setEditingSeries] = useState<EventSeries | null>(null)
  const [seriesFormData, setSeriesFormData] = useState<EventSeriesFormData>({
    name: '',
    description: '',
    recurring: false,
    frequency: 'weekly',
  })

  const isAdmin = (session?.user as any)?.role === 'admin'

  const fetchSeries = async () => {
    try {
      const response = await fetch('/api/admin/event-hub/series')
      if (!response.ok) throw new Error('Failed to fetch event series')

      const data = await response.json()
      setSeries(data)
    } catch (error) {
      console.error('Error fetching series:', error)
      toast.error('Failed to load event series')
    } finally {
      setIsLoading(false)
    }
  }

  const handleCreateSeries = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!seriesFormData.name.trim()) {
      toast.error('Series name is required')
      return
    }

    setIsSubmitting(true)
    try {
      const response = await fetch('/api/admin/event-hub/series', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(seriesFormData),
      })

      if (!response.ok) throw new Error('Failed to create event series')

      toast.success('Event series created successfully')
      setIsDialogOpen(false)
      setSeriesFormData({
        name: '',
        description: '',
        recurring: false,
        frequency: 'weekly',
      })
      fetchSeries()
    } catch (error) {
      toast.error('Failed to create event series')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleUpdateSeries = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!seriesFormData.name.trim()) {
      toast.error('Series name is required')
      return
    }

    setIsSubmitting(true)
    try {
      const response = await fetch(`/api/admin/event-hub/series/${editingSeries.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(seriesFormData),
      })

      if (!response.ok) throw new Error('Failed to update event series')

      toast.success('Event series updated successfully')
      setIsDialogOpen(false)
      setSeriesFormData({
        name: '',
        description: '',
        recurring: false,
        frequency: 'weekly',
      })
      setEditingSeries(null)
      fetchSeries()
    } catch (error) {
      toast.error('Failed to update event series')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteSeries = async (seriesId: string) => {
    if (!confirm('Are you sure you want to delete this event series?')) return

    try {
      const response = await fetch(`/api/admin/event-hub/series/${seriesId}`, {
        method: 'DELETE',
      })

      if (!response.ok) throw new Error('Failed to delete event series')

      toast.success('Event series deleted successfully')
      fetchSeries()
    } catch (error) {
      toast.error('Failed to delete event series')
    }
  }

  useEffect(() => {
    fetchSeries()
  }, [])

  const getRecurringBadge = (recurring: boolean) => {
    return recurring ? (
      <Badge className="bg-green-100 text-green-800">
        Recurring
      </Badge>
    ) : (
      <Badge className="bg-gray-100 text-gray-800">
        One-Time
      </Badge>
    )
  }

  const getFrequencyBadge = (frequency: string) => {
    return (
      <Badge variant="outline">
        {frequency}
      </Badge>
    )
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Event Series</h1>
          <p className="text-muted-foreground">Loading event series...</p>
        </div>
        <Card>
          <CardContent className="p-6">
            <div className="h-96 bg-muted animate-pulse rounded" />
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Event Series</h1>
          <p className="text-muted-foreground">Manage recurring event series and templates</p>
        </div>
        {isAdmin && (
          <Button onClick={() => {
            setEditingSeries(null)
            setSeriesFormData({
              name: '',
              description: '',
              recurring: false,
              frequency: 'weekly',
            })
            setIsDialogOpen(true)
          }}>
            <Plus className="mr-2 h-4 w-4" />
            Create Series
          </Button>
        )}
      </div>

      {series.length === 0 ? (
        <Card>
          <CardContent className="p-12">
            <div className="text-center">
              <Calendar className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">No event series yet</h3>
              <p className="text-muted-foreground">
                {isAdmin ? 'Create your first event series to set up recurring events' : 'Ask an admin to create event series'}
              </p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>All Series</CardTitle>
            <CardDescription>
              Manage your event series and recurring schedules
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Series Name</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Recurring</TableHead>
                  <TableHead>Frequency</TableHead>
                  <TableHead>Events</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {series.map((eventSeries) => (
                  <TableRow key={eventSeries.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <Calendar className="h-5 w-5 text-primary/60" />
                        </div>
                        <div>
                          <div className="font-medium">{eventSeries.name}</div>
                          {eventSeries.description && (
                            <div className="text-xs text-muted-foreground">{eventSeries.description}</div>
                          )}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      {getRecurringBadge(eventSeries.recurring)}
                    </TableCell>
                    <TableCell>
                      {eventSeries.recurring && getFrequencyBadge(eventSeries.frequency)}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">{eventSeries.eventCount}</Badge>
                    </TableCell>
                    <TableCell>
                      {new Date(eventSeries.createdAt).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                      })}
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <Eye className="mr-2 h-4 w-4" />
                            View Series
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit Series
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Settings className="mr-2 h-4 w-4" />
                            Manage Settings (coming soon)
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <Download className="mr-2 h-4 w-4" />
                            Export Calendar (coming soon)
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            <QrCode className="mr-2 h-4 w-4" />
                            Generate QR Codes (coming soon)
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            onClick={() => handleDeleteSeries(eventSeries.id)}
                            className="text-destructive"
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete Series
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Create/Edit Series Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <form onSubmit={editingSeries ? handleUpdateSeries : handleCreateSeries}>
          <DialogHeader>
            <DialogTitle>
              {editingSeries ? 'Edit Event Series' : 'Create Event Series'}
            </DialogTitle>
            <DialogDescription>
              {editingSeries ? 'Update event series information' : 'Create new event series for recurring events'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="series-name">Series Name *</Label>
              <Input
                id="series-name"
                value={seriesFormData.name}
                onChange={(e) => setSeriesFormData({ ...seriesFormData, name: e.target.value })}
                placeholder="Weekly Meetup"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="series-description">Description</Label>
              <textarea
                id="series-description"
                value={seriesFormData.description}
                onChange={(e) => setSeriesFormData({ ...seriesFormData, description: e.target.value })}
                placeholder="Weekly meetup series for community discussions"
                rows={3}
                className="w-full min-h-[80px] rounded-md border border-input px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
              />
            </div>

            <div className="flex items-center gap-4">
              <div className="space-y-2">
                <Label htmlFor="series-recurring">Recurring Series</Label>
                <Switch
                  id="series-recurring"
                  checked={seriesFormData.recurring}
                  onCheckedChange={(checked) => setSeriesFormData({ ...seriesFormData, recurring: checked })}
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Enable automatic event creation
              </p>
            </div>
              {seriesFormData.recurring && (
                <div className="space-y-2">
                  <Label htmlFor="series-frequency">Frequency</Label>
                  <Select value={seriesFormData.frequency} onValueChange={(value) => setSeriesFormData({ ...seriesFormData, frequency: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select frequency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="quarterly">Quarterly</SelectItem>
                      <SelectItem value="yearly">Yearly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <p className="text-xs text-muted-foreground">
                  How often should events be created?
                </p>
              </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsDialogOpen(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {editingSeries ? 'Saving...' : 'Creating...'}
                </>
              ) : (
                <>
                  {editingSeries ? (
                    <Edit className="mr-2 h-4 w-4" />
                  ) : (
                    <Plus className="mr-2 h-4 w-4" />
                  )}
                  {editingSeries ? 'Update Series' : 'Create Series'}
                </>
              )}
            </Button>
          </DialogFooter>
        </form>
      </Dialog>
    </div>
  )
}
