'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { MoreHorizontal, Plus, Search, Calendar, MapPin, Clock, Ticket as TicketIcon, Users, DollarSign, Edit, Trash2, Loader2, Eye, ChevronRight } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { toast } from 'sonner'

interface Event {
  id: string
  name: string
  slug: string
  description: string | null
  date: string
  time: string | null
  location: string | null
  price: number | null
  capacity: number | null
  status: string
  createdAt: string
  _count: {
    tickets: number
  }
}

interface Ticket {
  id: string
  name: string
  email: string
  quantity: number
  price: number
  eventId: string
  status: string
  createdAt: string
  event: {
    id: string
    name: string
    date: string
    time: string | null
    location: string | null
    price: number
  }
}

export default function EventHubPage() {
  const { data: session } = useSession()
  const [activeTab, setActiveTab] = useState<'events' | 'tickets'>('events')
  const [isLoading, setIsLoading] = useState(true)
  const [isEventDialogOpen, setIsEventDialogOpen] = useState(false)
  const [isTicketDialogOpen, setIsTicketDialogOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isDeleting, setIsDeleting] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [events, setEvents] = useState<Event[]>([])
  const [tickets, setTickets] = useState<Ticket[]>([])

  const [eventFormData, setEventFormData] = useState({
    name: '',
    slug: '',
    description: '',
    date: '',
    time: '',
    location: '',
    price: '',
    capacity: '',
    status: 'upcoming',
  })

  const [ticketFormData, setTicketFormData] = useState({
    name: '',
    email: '',
    quantity: '1',
    eventId: '',
  })

  const isAdmin = (session?.user as any)?.role === 'admin'

  const fetchEvents = async () => {
    try {
      const params = new URLSearchParams()
      if (statusFilter !== 'all') params.append('status', statusFilter)
      if (searchQuery) params.append('search', searchQuery)

      const response = await fetch(`/api/admin/event-hub/events?${params.toString()}`)
      if (!response.ok) throw new Error('Failed to fetch events')
      const data = await response.json()
      setEvents(data)
    } catch (error) {
      toast.error('Failed to load events')
    } finally {
      setIsLoading(false)
    }
  }

  const fetchTickets = async () => {
    try {
      const response = await fetch('/api/admin/event-hub/tickets')
      if (!response.ok) throw new Error('Failed to fetch tickets')
      const data = await response.json()
      setTickets(data)
    } catch (error) {
      toast.error('Failed to load tickets')
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    if (activeTab === 'events') {
      fetchEvents()
    } else if (activeTab === 'tickets') {
      fetchTickets()
    }
  }, [activeTab, statusFilter, searchQuery])

  const handleCreateEvent = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!eventFormData.name.trim() || !eventFormData.slug.trim() || !eventFormData.date) {
      toast.error('Name, slug, and date are required')
      return
    }

    setIsSubmitting(true)
    try {
      const response = await fetch('/api/admin/event-hub/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(eventFormData),
      })

      if (!response.ok) throw new Error('Failed to create event')

      toast.success('Event created successfully')
      setIsEventDialogOpen(false)
      setEventFormData({
        name: '',
        slug: '',
        description: '',
        date: '',
        time: '',
        location: '',
        price: '',
        capacity: '',
        status: 'upcoming',
      })
      fetchEvents()
    } catch (error) {
      toast.error('Failed to create event')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!ticketFormData.name.trim() || !ticketFormData.email.trim() || !ticketFormData.eventId) {
      toast.error('Name, email, and event are required')
      return
    }

    setIsSubmitting(true)
    try {
      const response = await fetch('/api/admin/event-hub/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(ticketFormData),
      })

      if (!response.ok) throw new Error('Failed to create ticket')

      toast.success('Ticket created successfully')
      setIsTicketDialogOpen(false)
      setTicketFormData({
        name: '',
        email: '',
        quantity: '1',
        eventId: '',
      })
      fetchTickets()
      fetchEvents()
    } catch (error) {
      toast.error('Failed to create ticket')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteEvent = async (eventId: string, name: string) => {
    if (!confirm(`Are you sure you want to delete event "${name}"?`)) return

    setIsDeleting(eventId)
    try {
      const response = await fetch(`/api/admin/event-hub/events/${eventId}`, {
        method: 'DELETE',
      })

      if (!response.ok) throw new Error('Failed to delete event')

      toast.success('Event deleted successfully')
      fetchEvents()
    } catch (error) {
      toast.error('Failed to delete event')
    } finally {
      setIsDeleting(null)
    }
  }

  const handleUpdateTicketStatus = async (ticketId: string, status: string) => {
    try {
      const response = await fetch(`/api/admin/event-hub/tickets/${ticketId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      })

      if (!response.ok) throw new Error('Failed to update ticket status')

      toast.success('Ticket status updated successfully')
      fetchTickets()
    } catch (error) {
      toast.error('Failed to update ticket status')
    }
  }

  const getStatusBadge = (status: string) => {
    const styles = {
      upcoming: 'bg-blue-100 text-blue-800',
      ongoing: 'bg-green-100 text-green-800',
      completed: 'bg-gray-100 text-gray-800',
      cancelled: 'bg-red-100 text-red-800',
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[status as keyof typeof styles]}`}>
        {status}
      </span>
    )
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    })
  }

  const formatPrice = (price: number | null) => {
    if (!price) return '-'
    return `$${price.toFixed(2)}`
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Event Hub</h1>
          <p className="text-muted-foreground">Manage events and tickets</p>
        </div>
        <Card>
          <CardContent className="p-6">
            <div className="space-y-4">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="h-24 bg-muted animate-pulse rounded" />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Event Hub</h1>
          <p className="text-muted-foreground">Manage events and tickets</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList>
                <TabsTrigger value="events">
                  <Calendar className="mr-2 h-4 w-4" />
                  Events
                  {events.length > 0 && (
                    <Badge variant="secondary" className="ml-2">
                      {events.length}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="tickets">
                  <TicketIcon className="mr-2 h-4 w-4" />
                  Tickets
                  {tickets.length > 0 && (
                    <Badge variant="secondary" className="ml-2">
                      {tickets.length}
                    </Badge>
                  )}
                </TabsTrigger>
              </TabsList>
            </Tabs>
            <Input
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-[250px]"
            />
          </div>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            {/* Events Tab */}
            <TabsContent value="events">
              <div className="space-y-4">
                <div className="flex items-center justify-between mb-4">
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-[150px]">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="upcoming">Upcoming</SelectItem>
                      <SelectItem value="ongoing">Ongoing</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                  {isAdmin && (
                    <Dialog open={isEventDialogOpen} onOpenChange={setIsEventDialogOpen}>
                      <DialogTrigger asChild>
                        <Button>
                          <Plus className="mr-2 h-4 w-4" />
                          New Event
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <form onSubmit={handleCreateEvent}>
                          <DialogHeader>
                            <DialogTitle>Create Event</DialogTitle>
                            <DialogDescription>
                              Add a new event to your hub
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4 py-4">
                            <div className="grid gap-4 md:grid-cols-2">
                              <div className="space-y-2 md:col-span-2">
                                <Label htmlFor="event-name">Event Name *</Label>
                                <Input
                                  id="event-name"
                                  value={eventFormData.name}
                                  onChange={(e) => setEventFormData({ ...eventFormData, name: e.target.value })}
                                  placeholder="Event name"
                                  required
                                  disabled={isSubmitting}
                                />
                              </div>
                              <div className="space-y-2 md:col-span-2">
                                <Label htmlFor="event-date">Date *</Label>
                                <Input
                                  id="event-date"
                                  type="date"
                                  value={eventFormData.date}
                                  onChange={(e) => setEventFormData({ ...eventFormData, date: e.target.value })}
                                  required
                                  disabled={isSubmitting}
                                />
                              </div>
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="event-slug">Slug *</Label>
                              <Input
                                id="event-slug"
                                value={eventFormData.slug}
                                onChange={(e) => setEventFormData({ ...eventFormData, slug: e.target.value })}
                                placeholder="event-slug"
                                required
                                disabled={isSubmitting}
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="event-time">Time</Label>
                              <Input
                                id="event-time"
                                type="time"
                                value={eventFormData.time}
                                onChange={(e) => setEventFormData({ ...eventFormData, time: e.target.value })}
                                placeholder="09:00"
                                disabled={isSubmitting}
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="event-location">Location</Label>
                              <Input
                                id="event-location"
                                value={eventFormData.location}
                                onChange={(e) => setEventFormData({ ...eventFormData, location: e.target.value })}
                                placeholder="Event venue or address"
                                disabled={isSubmitting}
                              />
                            </div>
                            <div className="grid gap-4 md:grid-cols-2">
                              <div className="space-y-2">
                                <Label htmlFor="event-price">Price</Label>
                                <Input
                                  id="event-price"
                                  type="number"
                                  step="0.01"
                                  min="0"
                                  value={eventFormData.price}
                                  onChange={(e) => setEventFormData({ ...eventFormData, price: e.target.value })}
                                  placeholder="99.99"
                                  disabled={isSubmitting}
                                />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="event-capacity">Capacity</Label>
                                <Input
                                  id="event-capacity"
                                  type="number"
                                  min="0"
                                  value={eventFormData.capacity}
                                  onChange={(e) => setEventFormData({ ...eventFormData, capacity: e.target.value })}
                                  placeholder="100"
                                  disabled={isSubmitting}
                                />
                              </div>
                            </div>
                            <div className="grid gap-4 md:grid-cols-2">
                              <div className="space-y-2">
                                <Label htmlFor="event-status">Status</Label>
                                <Select
                                  value={eventFormData.status}
                                  onValueChange={(value) => setEventFormData({ ...eventFormData, status: value })}
                                  disabled={isSubmitting}
                                >
                                  <SelectTrigger>
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="upcoming">Upcoming</SelectItem>
                                    <SelectItem value="ongoing">Ongoing</SelectItem>
                                    <SelectItem value="completed">Completed</SelectItem>
                                    <SelectItem value="cancelled">Cancelled</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                              <div className="space-y-2">
                                <Label htmlFor="event-description">Description</Label>
                                <Textarea
                                  id="event-description"
                                  value={eventFormData.description}
                                  onChange={(e) => setEventFormData({ ...eventFormData, description: e.target.value })}
                                  placeholder="Describe the event"
                                  disabled={isSubmitting}
                                  rows={3}
                                />
                              </div>
                            </div>
                          </div>
                          <DialogFooter>
                            <Button
                              type="button"
                              variant="outline"
                              onClick={() => setIsEventDialogOpen(false)}
                              disabled={isSubmitting}
                            >
                              Cancel
                            </Button>
                            <Button type="submit" disabled={isSubmitting}>
                              {isSubmitting ? 'Creating...' : 'Create Event'}
                            </Button>
                          </DialogFooter>
                        </form>
                      </DialogContent>
                    </Dialog>
                  )}
                </div>

                {events.length === 0 ? (
                  <div className="text-center py-12">
                    <Calendar className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">No events yet</h3>
                    <p className="text-muted-foreground">
                      {isAdmin ? 'Create your first event to get started' : 'Ask an admin to create events'}
                    </p>
                  </div>
                ) : (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Event</TableHead>
                          <TableHead>Date & Time</TableHead>
                          <TableHead>Location</TableHead>
                          <TableHead>Price</TableHead>
                          <TableHead>Capacity</TableHead>
                          <TableHead>Tickets</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {events.map((event) => (
                          <TableRow key={event.id}>
                            <TableCell>
                              <div className="space-y-1">
                                <div className="font-medium">{event.name}</div>
                                <div className="text-sm text-muted-foreground">/{event.slug}</div>
                                {event.description && (
                                  <p className="text-xs text-muted-foreground line-clamp-2">
                                    {event.description}
                                  </p>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="space-y-1">
                                <div className="flex items-center gap-2">
                                  <Calendar className="h-4 w-4 text-muted-foreground" />
                                  <span className="text-sm">{formatDate(event.date)}</span>
                                </div>
                                {event.time && (
                                  <div className="flex items-center gap-2">
                                    <Clock className="h-4 w-4 text-muted-foreground" />
                                    <span className="text-sm">{event.time}</span>
                                  </div>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <MapPin className="h-4 w-4 text-muted-foreground" />
                                <span className="text-sm">{event.location || '-'}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <DollarSign className="h-4 w-4 text-muted-foreground" />
                                <span className="font-medium">{formatPrice(event.price)}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Users className="h-4 w-4 text-muted-foreground" />
                                <span className="text-sm">{event.capacity || '-'}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary">
                                {event._count.tickets}
                              </Badge>
                            </TableCell>
                            <TableCell>{getStatusBadge(event.status)}</TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" disabled={isDeleting === event.id}>
                                    {isDeleting === event.id ? (
                                      <Loader2 className="h-4 w-4 animate-spin" />
                                    ) : (
                                      <MoreHorizontal className="h-4 w-4" />
                                    )}
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem>
                                    <Eye className="mr-2 h-4 w-4" />
                                    View Event (coming soon)
                                  </DropdownMenuItem>
                                  <DropdownMenuItem>
                                    <Edit className="mr-2 h-4 w-4" />
                                    Edit Event (coming soon)
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem
                                    onClick={() => handleDeleteEvent(event.id, event.name)}
                                    className="text-destructive"
                                    disabled={isDeleting === event.id}
                                  >
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    Delete Event
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </div>
            </TabsContent>

            {/* Tickets Tab */}
            <TabsContent value="tickets">
              {tickets.length === 0 ? (
                <div className="text-center py-12">
                  <TicketIcon className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No tickets yet</h3>
                  <p className="text-muted-foreground">
                    {isAdmin ? 'Create tickets for events or purchase them' : 'Ask an admin to create tickets'}
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-4">
                    <Dialog open={isTicketDialogOpen} onOpenChange={setIsTicketDialogOpen}>
                      <DialogTrigger asChild>
                        <Button>
                          <Plus className="mr-2 h-4 w-4" />
                          Create Ticket
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <form onSubmit={handleCreateTicket}>
                          <DialogHeader>
                            <DialogTitle>Create Ticket</DialogTitle>
                            <DialogDescription>
                              Create a new ticket for an event
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4 py-4">
                            <div className="grid gap-4 md:grid-cols-2">
                              <div className="space-y-2">
                                <Label htmlFor="ticket-name">Name *</Label>
                                <Input
                                  id="ticket-name"
                                  value={ticketFormData.name}
                                  onChange={(e) => setTicketFormData({ ...ticketFormData, name: e.target.value })}
                                  placeholder="Attendee name"
                                  required
                                  disabled={isSubmitting}
                                />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="ticket-email">Email *</Label>
                                <Input
                                  id="ticket-email"
                                  type="email"
                                  value={ticketFormData.email}
                                  onChange={(e) => setTicketFormData({ ...ticketFormData, email: e.target.value })}
                                  placeholder="email@example.com"
                                  required
                                  disabled={isSubmitting}
                                />
                              </div>
                            </div>
                            <div className="grid gap-4 md:grid-cols-2">
                              <div className="space-y-2 md:col-span-2">
                                <Label htmlFor="ticket-event">Event *</Label>
                                <Select
                                  value={ticketFormData.eventId}
                                  onValueChange={(value) => setTicketFormData({ ...ticketFormData, eventId: value })}
                                  disabled={isSubmitting}
                                >
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select event" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="">Select event</SelectItem>
                                    {events.map((evt) => (
                                      <SelectItem key={evt.id} value={evt.id}>
                                        {evt.name}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                              <div className="space-y-2">
                                <Label htmlFor="ticket-quantity">Quantity *</Label>
                                <Input
                                  id="ticket-quantity"
                                  type="number"
                                  min="1"
                                  max="100"
                                  value={ticketFormData.quantity}
                                  onChange={(e) => setTicketFormData({ ...ticketFormData, quantity: e.target.value })}
                                  placeholder="1"
                                  required
                                  disabled={isSubmitting}
                                />
                              </div>
                            </div>
                          </div>
                          <DialogFooter>
                            <Button
                              type="button"
                              variant="outline"
                              onClick={() => setIsTicketDialogOpen(false)}
                              disabled={isSubmitting}
                            >
                              Cancel
                            </Button>
                            <Button type="submit" disabled={isSubmitting}>
                              {isSubmitting ? 'Creating...' : 'Create Ticket'}
                            </Button>
                          </DialogFooter>
                        </form>
                      </DialogContent>
                    </Dialog>
                  </div>

                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Attendee</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Event</TableHead>
                          <TableHead>Date & Time</TableHead>
                          <TableHead>Quantity</TableHead>
                          <TableHead>Price</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {tickets.map((ticket) => (
                          <TableRow key={ticket.id}>
                            <TableCell>
                              <div className="font-medium">{ticket.name}</div>
                            </TableCell>
                            <TableCell>
                              <div className="text-sm">{ticket.email}</div>
                            </TableCell>
                            <TableCell>
                              <div className="space-y-1">
                                <div className="font-medium">{ticket.event.name}</div>
                                <div className="flex items-center gap-2">
                                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                                  <span className="text-xs text-muted-foreground">{formatDate(ticket.event.date)}</span>
                                  {ticket.event.time && (
                                    <span className="text-xs text-muted-foreground">{ticket.event.time}</span>
                                  )}
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <MapPin className="h-4 w-4 text-muted-foreground" />
                                <span className="text-sm">{ticket.event.location || '-'}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary">{ticket.quantity}</Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <DollarSign className="h-4 w-4 text-muted-foreground" />
                                <span className="font-medium">{formatPrice(ticket.price)}</span>
                              </div>
                            </TableCell>
                            <TableCell>{getStatusBadge(ticket.status)}</TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon">
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem
                                    onClick={() => handleUpdateTicketStatus(ticket.id, 'used')}
                                  >
                                    <Eye className="mr-2 h-4 w-4" />
                                    Mark as Used
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    onClick={() => handleUpdateTicketStatus(ticket.id, 'cancelled')}
                                    className="text-destructive"
                                  >
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    Cancel Ticket
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </div>
            </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
