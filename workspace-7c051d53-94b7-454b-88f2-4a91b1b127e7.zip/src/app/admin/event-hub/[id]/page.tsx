'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { ArrowLeft, Calendar, MapPin, Clock, Users, DollarSign, ShoppingBag, Plus, Image as ImageIcon, Upload, Trash2, Edit, Loader2, MoreHorizontal, Eye, Bell } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { toast } from 'sonner'
import Link from 'next/link'

interface EventImage {
  id: string
  url: string
  alt: string | null
  caption: string | null
  position: number
}

interface WaitlistEntry {
  id: string
  notified: boolean
  createdAt: string
  event: {
    id: string
    name: string
    date: string
    time: string | null
    location: string | null
  }
  user: {
    id: string
    name: string
    email: string
  }
}

interface Event {
  id: string
  name: string
  slug: string
  description: string | null
  date: string
  time: string | null
  location: string | null
  price: number | null
  capacity: number | null
  status: string
  createdAt: string
  images: EventImage[]
  _count: {
    tickets: number
    waitlist: number
  }
}

export default function EventDetailPage({
  params,
}: {
  params: { id: string }
}) {
  const { data: session } = useSession()
  const [event, setEvent] = useState<Event | null>(null)
  const [waitlist, setWaitlist] = useState<WaitlistEntry[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isDeletingImage, setIsDeletingImage] = useState<string | null>(null)
  const [isImageDialogOpen, setIsImageDialogOpen] = useState(false)
  const [imageFormData, setImageFormData] = useState({
    url: '',
    alt: '',
    caption: '',
    position: 0,
  })

  const isAdmin = (session?.user as any)?.role === 'admin'

  const fetchEvent = async () => {
    try {
      const response = await fetch(`/api/admin/event-hub/events`)
      if (!response.ok) throw new Error('Failed to fetch events')

      const data = await response.json()
      const foundEvent = data.find((e: Event) => e.id === params.id)

      if (foundEvent) {
        setEvent(foundEvent)
      } else {
        toast.error('Event not found')
      }
    } catch (error) {
      console.error('Error fetching event:', error)
      toast.error('Failed to load event data')
    } finally {
      setIsLoading(false)
    }
  }

  const fetchWaitlist = async () => {
    try {
      const response = await fetch(`/api/admin/event-hub/waitlist?eventId=${params.id}`)
      if (!response.ok) throw new Error('Failed to fetch waitlist')

      const data = await response.json()
      setWaitlist(data)
    } catch (error) {
      console.error('Error fetching waitlist:', error)
      toast.error('Failed to load waitlist')
    }
  }

  useEffect(() => {
    fetchEvent()
    fetchWaitlist()
  }, [params.id])

  const handleAddImage = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!imageFormData.url.trim()) {
      toast.error('Image URL is required')
      return
    }

    setIsSubmitting(true)
    try {
      const response = await fetch(`/api/admin/event-hub/events/${params.id}/images`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(imageFormData),
      })

      if (!response.ok) throw new Error('Failed to add event image')

      toast.success('Event image added successfully')
      setIsImageDialogOpen(false)
      setImageFormData({
        url: '',
        alt: '',
        caption: '',
        position: 0,
      })
      fetchEvent()
    } catch (error) {
      toast.error('Failed to add event image')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteImage = async (imageId: string) => {
    if (!confirm('Are you sure you want to delete this image?')) return

    setIsDeletingImage(imageId)
    try {
      const response = await fetch(`/api/admin/event-hub/events/${params.id}/images/${imageId}`, {
        method: 'DELETE',
      })

      if (!response.ok) throw new Error('Failed to delete event image')

      toast.success('Event image deleted successfully')
      fetchEvent()
    } catch (error) {
      toast.error('Failed to delete event image')
    } finally {
      setIsDeletingImage(null)
    }
  }

  const handleAddToWaitlist = async () => {
    setIsSubmitting(true)
    try {
      const response = await fetch('/api/admin/event-hub/waitlist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ eventId: params.id }),
      })

      if (!response.ok) throw new Error('Failed to add to waitlist')

      toast.success('Added to waitlist successfully')
      fetchWaitlist()
    } catch (error) {
      if (error instanceof Error && error.message.includes('already on this waitlist')) {
        toast.error('You are already on this waitlist')
      } else {
        toast.error('Failed to add to waitlist')
      }
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleRemoveFromWaitlist = async (waitlistId: string) => {
    setIsSubmitting(true)
    try {
      const response = await fetch(`/api/admin/event-hub/waitlist/${waitlistId}`, {
        method: 'DELETE',
      })

      if (!response.ok) throw new Error('Failed to remove from waitlist')

      toast.success('Removed from waitlist successfully')
      fetchWaitlist()
      fetchEvent()
    } catch (error) {
      toast.error('Failed to remove from waitlist')
    } finally {
      setIsSubmitting(false)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    })
  }

  const formatTime = (time: string | null) => {
    return time || '-'
  }

  const formatPrice = (price: number | null) => {
    if (!price) return '-'
    return `$${price.toFixed(2)}`
  }

  const getStatusBadge = (status: string) => {
    const styles = {
      upcoming: 'bg-blue-100 text-blue-800',
      ongoing: 'bg-green-100 text-green-800',
      completed: 'bg-gray-100 text-gray-800',
      cancelled: 'bg-red-100 text-red-800',
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[status as keyof typeof styles]}`}>
        {status}
      </span>
    )
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Link href="/admin/event-hub">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Event Details</h1>
            <p className="text-muted-foreground">Loading event...</p>
          </div>
        </div>
        <Card>
          <CardContent className="p-6">
            <div className="h-96 bg-muted animate-pulse rounded" />
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!event) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Link href="/admin/event-hub">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Event Not Found</h1>
            <p className="text-muted-foreground">The event you're looking for doesn't exist</p>
          </div>
        </div>
      </div>
    )
  }

  const calculateRevenue = () => {
    if (!event.price) return 0
    return event.price * event._count.tickets
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/admin/event-hub">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{event.name}</h1>
            <p className="text-muted-foreground">/{event.slug}</p>
          </div>
        </div>
        <Badge className={event.status === 'upcoming' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'}>
          {event.status}
        </Badge>
      </div>

      <div className="grid gap-6 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total Tickets Sold
            </CardTitle>
            <ShoppingBag className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{event._count.tickets}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Waitlist
            </CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{event._count.waitlist}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total Revenue
            </CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatPrice(calculateRevenue())}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Event Status
            </CardTitle>
            {isAdmin && (
              <Button variant="ghost" size="icon">
                <Edit className="h-4 w-4" />
              </Button>
            )}
          </CardHeader>
          <CardContent>
            {getStatusBadge(event.status)}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Event Information</CardTitle>
              <CardDescription>
                Event details and settings
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <div className="text-sm text-muted-foreground">Name</div>
                    <div className="font-semibold text-lg">{event.name}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Status</div>
                    {getStatusBadge(event.status)}
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <div className="text-sm text-muted-foreground">Date</div>
                    <div className="font-semibold text-lg">{formatDate(event.date)}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Time</div>
                    <div className="font-semibold text-lg">{formatTime(event.time)}</div>
                  </div>
                </div>

                {event.description && (
                  <div>
                    <div className="text-sm text-muted-foreground mb-2">Description</div>
                    <p className="text-sm">{event.description}</p>
                  </div>
                )}

                <div className="grid gap-4 md:grid-cols-3">
                  <div>
                    <div className="text-sm text-muted-foreground">Location</div>
                    <div className="font-medium flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span>{event.location || '-'}</span>
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Capacity</div>
                    <div className="font-semibold text-lg">{event.capacity ? `${event.capacity} tickets` : '-'}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Price</div>
                    <div className="font-semibold text-lg">{formatPrice(event.price)}</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Event Gallery</CardTitle>
              <CardDescription>
                Event images and media
              </CardDescription>
              <div className="flex items-center justify-between">
                <div className="text-sm text-muted-foreground">{event.images.length} images</div>
                {isAdmin && (
                  <Dialog open={isImageDialogOpen} onOpenChange={setIsImageDialogOpen}>
                    <DialogTrigger asChild>
                      <Button size="icon">
                        <Plus className="h-4 w-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <form onSubmit={handleAddImage}>
                        <DialogHeader>
                          <DialogTitle>Add Event Image</DialogTitle>
                          <DialogDescription>
                            Add an image to the event gallery
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <div className="space-y-2">
                            <Label htmlFor="image-url">Image URL *</Label>
                            <Input
                              id="image-url"
                              value={imageFormData.url}
                              onChange={(e) => setImageFormData({ ...imageFormData, url: e.target.value })}
                              placeholder="https://example.com/image.jpg"
                              required
                              disabled={isSubmitting}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="image-alt">Alt Text</Label>
                            <Input
                              id="image-alt"
                              value={imageFormData.alt}
                              onChange={(e) => setImageFormData({ ...imageFormData, alt: e.target.value })}
                              placeholder="Event image alt text"
                              disabled={isSubmitting}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="image-caption">Caption</Label>
                            <Input
                              id="image-caption"
                              value={imageFormData.caption}
                              onChange={(e) => setImageFormData({ ...imageFormData, caption: e.target.value })}
                              placeholder="Image caption"
                              disabled={isSubmitting}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="image-position">Position</Label>
                            <Input
                              id="image-position"
                              type="number"
                              min="0"
                              value={imageFormData.position}
                              onChange={(e) => setImageFormData({ ...imageFormData, position: parseInt(e.target.value) })}
                              placeholder="0"
                              disabled={isSubmitting}
                            />
                          </div>
                        </div>
                        <DialogFooter>
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => setIsImageDialogOpen(false)}
                            disabled={isSubmitting}
                          >
                            Cancel
                          </Button>
                          <Button type="submit" disabled={isSubmitting}>
                            {isSubmitting ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Adding...
                              </>
                            ) : (
                              <>
                                <Upload className="mr-2 h-4 w-4" />
                                Add Image
                              </>
                            )}
                          </Button>
                        </DialogFooter>
                      </form>
                    </DialogContent>
                  </Dialog>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {event.images.length === 0 ? (
                <div className="text-center py-12">
                  <ImageIcon className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No images yet</h3>
                  <p className="text-muted-foreground">
                    {isAdmin ? 'Add images to this event' : 'Ask an admin to add images'}
                  </p>
                </div>
              ) : (
                <div className="grid gap-4 md:grid-cols-3">
                  {event.images.map((image, index) => (
                    <div key={image.id} className="relative">
                      <div className="aspect-square rounded-lg overflow-hidden border">
                        <img
                          src={image.url}
                          alt={image.alt || event.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      {isAdmin && (
                        <div className="absolute top-2 right-2">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8 bg-white/80 hover:bg-white">
                                {isDeletingImage === image.id ? (
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                  <MoreHorizontal className="h-4 w-4" />
                                )}
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem>
                                <Eye className="mr-2 h-4 w-4" />
                                View Image (coming soon)
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Edit className="mr-2 h-4 w-4" />
                                Edit Image (coming soon)
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                onClick={() => handleDeleteImage(image.id)}
                                className="text-destructive"
                                disabled={isDeletingImage === image.id}
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                Delete Image
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      )}
                      {index === 0 && (
                        <Badge className="absolute top-2 left-2" variant="secondary">
                          Cover
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Waitlist Management</CardTitle>
              <CardDescription>
                Users waiting for event tickets
              </CardDescription>
            </CardHeader>
            <CardContent>
              {waitlist.length === 0 ? (
                <div className="text-center py-12">
                  <Bell className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">Waitlist is empty</h3>
                  <p className="text-muted-foreground">
                    {session && !isAdmin ? 'Join the waitlist to get notified when tickets become available' : 'Waitlist is empty'}
                  </p>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>User</TableHead>
                        <TableHead>Event</TableHead>
                        <TableHead>Joined</TableHead>
                        <TableHead>Notified</TableHead>
                        {isAdmin && <TableHead>Actions</TableHead>}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {waitlist.map((entry) => (
                        <TableRow key={entry.id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              {entry.user.name ? (
                                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                                  <Users className="h-5 w-5 text-primary/60" />
                                </div>
                              ) : (
                                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                                  <Users className="h-5 w-5 text-primary/60" />
                                </div>
                              )}
                              <div>
                                <div className="font-medium">{entry.user.name}</div>
                                <div className="text-xs text-muted-foreground">{entry.user.email}</div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="space-y-1">
                              <div className="font-medium">{entry.event.name}</div>
                              <div className="text-xs text-muted-foreground">{formatDate(entry.event.date)}</div>
                              {entry.event.time && (
                                <div className="text-xs text-muted-foreground">{formatTime(entry.event.time)}</div>
                              )}
                              {entry.event.location && (
                                <div className="text-xs text-muted-foreground flex items-center gap-2">
                                  <MapPin className="h-3 w-3 text-muted-foreground" />
                                  <span>{entry.event.location}</span>
                                </div>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            {new Date(entry.createdAt).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'short',
                              day: 'numeric',
                            })}
                          </TableCell>
                          <TableCell>
                            <Badge variant={entry.notified ? 'default' : 'secondary'}>
                              {entry.notified ? 'Notified' : 'Not Notified'}
                            </Badge>
                          </TableCell>
                          {isAdmin && (
                            <TableCell className="text-right">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleRemoveFromWaitlist(entry.id)}
                                disabled={isSubmitting}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          )}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}

              {session && !isAdmin && (
                <div className="mt-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleAddToWaitlist}
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <Bell className="mr-2 h-4 w-4 animate-pulse" />
                        Adding to Waitlist...
                      </>
                    ) : (
                      <>
                        <Bell className="mr-2 h-4 w-4" />
                        Join Waitlist
                      </>
                    )}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
