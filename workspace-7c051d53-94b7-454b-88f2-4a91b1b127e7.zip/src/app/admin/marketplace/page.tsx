'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { MoreHorizontal, Plus, Search, Store, User, Eye, Edit, Trash2, Package, Layers, Loader2, Mail, Phone } from 'lucide-react'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { toast } from 'sonner'

interface Vendor {
  id: string
  name: string
  slug: string
  email: string
  phone: string | null
  description: string | null
  status: string
  commission: number
  createdAt: string
  _count: {
    listings: number
  }
}

interface Listing {
  id: string
  title: string
  slug: string
  description: string | null
  price: number | null
  status: string
  vendorId: string
  vendor: {
    id: string
    name: string
    email: string
  }
  category: {
    id: string
    name: string
  } | null
  images: {
    id: string
    url: string
    alt: string | null
  }[]
  createdAt: string
  publishedAt: string | null
}

export default function MarketplacePage() {
  const { data: session } = useSession()
  const [activeTab, setActiveTab] = useState<'vendors' | 'listings'>('vendors')
  const [isLoading, setIsLoading] = useState(true)
  const [isVendorDialogOpen, setIsVendorDialogOpen] = useState(false)
  const [isListingDialogOpen, setIsListingDialogOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isDeleting, setIsDeleting] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [vendorData, setVendorData] = useState({
    name: '',
    slug: '',
    email: '',
    phone: '',
    description: '',
    commission: 0.1,
  })
  const [listingData, setListingData] = useState({
    title: '',
    slug: '',
    description: '',
    price: '',
    categoryId: '',
    vendorId: '',
  })

  const [vendors, setVendors] = useState<Vendor[]>([])
  const [listings, setListings] = useState<Listing[]>([])
  const [categories, setCategories] = useState<any[]>([])

  const isAdmin = (session?.user as any)?.role === 'admin'

  const fetchVendors = async () => {
    try {
      const params = new URLSearchParams()
      if (statusFilter !== 'all') params.append('status', statusFilter)
      if (searchQuery) params.append('search', searchQuery)

      const response = await fetch(`/api/admin/marketplace/vendors?${params.toString()}`)
      if (!response.ok) throw new Error('Failed to fetch vendors')
      const data = await response.json()
      setVendors(data)
    } catch (error) {
      toast.error('Failed to load vendors')
    } finally {
      setIsLoading(false)
    }
  }

  const fetchListings = async () => {
    try {
      const params = new URLSearchParams()
      if (statusFilter !== 'all') params.append('status', statusFilter)
      if (searchQuery) params.append('search', searchQuery)

      const response = await fetch(`/api/admin/marketplace/listings?${params.toString()}`)
      if (!response.ok) throw new Error('Failed to fetch listings')
      const data = await response.json()
      setListings(data)
    } catch (error) {
      toast.error('Failed to load listings')
    } finally {
      setIsLoading(false)
    }
  }

  const fetchCategories = async () => {
    try {
      const response = await fetch('/api/admin/categories')
      if (!response.ok) throw new Error('Failed to fetch categories')
      const data = await response.json()
      setCategories(data)
    } catch (error) {
      console.error('Error fetching categories:', error)
    }
  }

  useEffect(() => {
    fetchVendors()
    fetchCategories()
    if (activeTab === 'listings') {
      fetchListings()
    }
  }, [activeTab, statusFilter, searchQuery])

  const handleCreateVendor = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!vendorData.name.trim() || !vendorData.slug.trim() || !vendorData.email.trim()) {
      toast.error('Name, slug, and email are required')
      return
    }

    setIsSubmitting(true)
    try {
      const response = await fetch('/api/admin/marketplace/vendors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(vendorData),
      })

      if (!response.ok) throw new Error('Failed to create vendor')

      toast.success('Vendor created successfully')
      setIsVendorDialogOpen(false)
      setVendorData({
        name: '',
        slug: '',
        email: '',
        phone: '',
        description: '',
        commission: 0.1,
      })
      fetchVendors()
    } catch (error) {
      toast.error('Failed to create vendor')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleCreateListing = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!listingData.title.trim() || !listingData.slug.trim() || !listingData.vendorId) {
      toast.error('Title, slug, and vendor are required')
      return
    }

    setIsSubmitting(true)
    try {
      const response = await fetch('/api/admin/marketplace/listings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...listingData,
          price: listingData.price ? parseFloat(listingData.price) : null,
        }),
      })

      if (!response.ok) throw new Error('Failed to create listing')

      toast.success('Listing created successfully')
      setIsListingDialogOpen(false)
      setListingData({
        title: '',
        slug: '',
        description: '',
        price: '',
        categoryId: '',
        vendorId: '',
      })
      fetchListings()
    } catch (error) {
      toast.error('Failed to create listing')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteVendor = async (vendorId: string, name: string) => {
    if (!confirm(`Are you sure you want to delete vendor "${name}"?`)) return

    setIsDeleting(vendorId)
    try {
      const response = await fetch(`/api/admin/marketplace/vendors/${vendorId}`, {
        method: 'DELETE',
      })

      if (!response.ok) throw new Error('Failed to delete vendor')

      toast.success('Vendor deleted successfully')
      fetchVendors()
    } catch (error) {
      toast.error('Failed to delete vendor')
    } finally {
      setIsDeleting(null)
    }
  }

  const handleDeleteListing = async (listingId: string, title: string) => {
    if (!confirm(`Are you sure you want to delete listing "${title}"?`)) return

    setIsDeleting(listingId)
    try {
      const response = await fetch(`/api/admin/marketplace/listings/${listingId}`, {
        method: 'DELETE',
      })

      if (!response.ok) throw new Error('Failed to delete listing')

      toast.success('Listing deleted successfully')
      fetchListings()
    } catch (error) {
      toast.error('Failed to delete listing')
    } finally {
      setIsDeleting(null)
    }
  }

  const getStatusBadge = (status: string) => {
    const styles = {
      active: 'bg-green-100 text-green-800',
      pending: 'bg-yellow-100 text-yellow-800',
      suspended: 'bg-red-100 text-red-800',
      draft: 'bg-gray-100 text-gray-800',
      published: 'bg-blue-100 text-blue-800',
      sold: 'bg-purple-100 text-purple-800',
    }
    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[status as keyof typeof styles]}`}>
        {status}
      </span>
    )
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Marketplace</h1>
          <p className="text-muted-foreground">Multi-vendor platform for your CMS</p>
        </div>
        <Card>
          <CardContent className="p-6">
            <div className="space-y-4">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="h-24 bg-muted animate-pulse rounded" />
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Marketplace</h1>
          <p className="text-muted-foreground">Multi-vendor platform for your CMS</p>
        </div>
        <div className="flex gap-2">
          <Input
            placeholder="Search..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-[250px]"
          />
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="suspended">Suspended</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>
            {activeTab === 'vendors' ? 'Vendors' : 'Listings'}
          </CardTitle>
          <CardDescription>
            {activeTab === 'vendors' ? 'Manage vendors and sellers' : 'Manage products and listings'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="vendors">
                <Store className="mr-2 h-4 w-4" />
                Vendors
              </TabsTrigger>
              <TabsTrigger value="listings">
                <Package className="mr-2 h-4 w-4" />
                Listings
              </TabsTrigger>
            </TabsList>

            <TabsContent value="vendors">
              {vendors.length === 0 ? (
                <div className="text-center py-12">
                  <Store className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No vendors yet</h3>
                  <p className="text-muted-foreground">
                    {isAdmin ? 'Create your first vendor to get started' : 'Ask an admin to create vendors'}
                  </p>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                            <TableHead>Vendor</TableHead>
                            <TableHead>Email</TableHead>
                            <TableHead>Phone</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Commission</TableHead>
                            <TableHead>Listings</TableHead>
                            <TableHead>Joined</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {vendors.map((vendor) => (
                        <TableRow key={vendor.id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                                <User className="h-5 w-5 text-primary/60" />
                              </div>
                              <div>
                                <div className="font-medium">{vendor.name}</div>
                                <div className="text-sm text-muted-foreground">/{vendor.slug}</div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Mail className="h-4 w-4 text-muted-foreground" />
                              <span className="text-sm">{vendor.email}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Phone className="h-4 w-4 text-muted-foreground" />
                              <span className="text-sm">{vendor.phone || '-'}</span>
                            </div>
                          </TableCell>
                          <TableCell>{getStatusBadge(vendor.status)}</TableCell>
                          <TableCell>{(vendor.commission * 100).toFixed(0)}%</TableCell>
                          <TableCell>{vendor._count.listings}</TableCell>
                          <TableCell>
                            {new Date(vendor.createdAt).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'short',
                              day: 'numeric',
                            })}
                          </TableCell>
                          <TableCell className="text-right">
                            {isAdmin && (
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" disabled={isDeleting === vendor.id}>
                                    {isDeleting === vendor.id ? (
                                      <Loader2 className="h-4 w-4 animate-spin" />
                                    ) : (
                                      <MoreHorizontal className="h-4 w-4" />
                                    )}
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem>
                                    <Eye className="mr-2 h-4 w-4" />
                                    View Vendor (coming soon)
                                  </DropdownMenuItem>
                                  <DropdownMenuItem>
                                    <Edit className="mr-2 h-4 w-4" />
                                    Edit Vendor (coming soon)
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem
                                    onClick={() => handleDeleteVendor(vendor.id, vendor.name)}
                                    className="text-destructive"
                                    disabled={isDeleting === vendor.id}
                                  >
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    Delete Vendor
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </TabsContent>

            <TabsContent value="listings">
              {listings.length === 0 ? (
                <div className="text-center py-12">
                  <Package className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No listings yet</h3>
                  <p className="text-muted-foreground">
                    Create listings or add vendors to get started
                  </p>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                            <TableHead>Listing</TableHead>
                            <TableHead>Vendor</TableHead>
                            <TableHead>Price</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Category</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {listings.map((listing) => (
                        <TableRow key={listing.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{listing.title}</div>
                              <div className="text-sm text-muted-foreground">/{listing.slug}</div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-medium">{listing.vendor.name}</span>
                              <span className="text-xs text-muted-foreground">{listing.vendor.email}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            {listing.price ? `$${listing.price.toFixed(2)}` : '-'}
                          </TableCell>
                          <TableCell>{getStatusBadge(listing.status)}</TableCell>
                          <TableCell>
                            {listing.category ? (
                              <Badge variant="secondary">
                                {listing.category.name}
                              </Badge>
                            ) : (
                              <span className="text-sm text-muted-foreground">-</span>
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" disabled={isDeleting === listing.id}>
                                  {isDeleting === listing.id ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  ) : (
                                    <MoreHorizontal className="h-4 w-4" />
                                  )}
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem>
                                  <Eye className="mr-2 h-4 w-4" />
                                  View Listing (coming soon)
                                </DropdownMenuItem>
                                <DropdownMenuItem>
                                  <Edit className="mr-2 h-4 w-4" />
                                  Edit Listing (coming soon)
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem
                                  onClick={() => handleDeleteListing(listing.id, listing.title)}
                                  className="text-destructive"
                                  disabled={isDeleting === listing.id}
                                >
                                  <Trash2 className="mr-2 h-4 w-4" />
                                  Delete Listing
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </TabsContent>
          </CardContent>
        </Card>

      <Dialog open={isVendorDialogOpen} onOpenChange={setIsVendorDialogOpen}>
        <DialogContent>
          <form onSubmit={handleCreateVendor}>
            <DialogHeader>
              <DialogTitle>Create Vendor</DialogTitle>
              <DialogDescription>
                Add a new vendor to your marketplace
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="vendor-name">Name *</Label>
                  <Input
                    id="vendor-name"
                    value={vendorData.name}
                    onChange={(e) => setVendorData({ ...vendorData, name: e.target.value })}
                    placeholder="Vendor Name"
                    required
                    disabled={isSubmitting}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="vendor-email">Email *</Label>
                  <Input
                    id="vendor-email"
                    type="email"
                    value={vendorData.email}
                    onChange={(e) => setVendorData({ ...vendorData, email: e.target.value })}
                    placeholder="vendor@example.com"
                    required
                    disabled={isSubmitting}
                  />
                </div>
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="vendor-phone">Phone</Label>
                  <Input
                    id="vendor-phone"
                    value={vendorData.phone}
                    onChange={(e) => setVendorData({ ...vendorData, phone: e.target.value })}
                    placeholder="+1 234 567 890"
                    disabled={isSubmitting}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="vendor-commission">Commission (%)</Label>
                  <Input
                    id="vendor-commission"
                    type="number"
                    step="0.01"
                    min="0"
                    max="100"
                    value={vendorData.commission}
                    onChange={(e) => setVendorData({ ...vendorData, commission: parseFloat(e.target.value) })}
                    placeholder="10"
                    disabled={isSubmitting}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="vendor-description">Description</Label>
                <Textarea
                  id="vendor-description"
                  value={vendorData.description}
                  onChange={(e) => setVendorData({ ...vendorData, description: e.target.value })}
                  placeholder="Describe vendor's business"
                  disabled={isSubmitting}
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsVendorDialogOpen(false)}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? 'Creating...' : 'Create Vendor'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={isListingDialogOpen} onOpenChange={setIsListingDialogOpen}>
        <DialogContent>
          <form onSubmit={handleCreateListing}>
            <DialogHeader>
              <DialogTitle>Create Listing</DialogTitle>
              <DialogDescription>
                Add a new listing to your marketplace
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="listing-title">Title *</Label>
                  <Input
                    id="listing-title"
                    value={listingData.title}
                    onChange={(e) => setListingData({ ...listingData, title: e.target.value })}
                    placeholder="Product title"
                    required
                    disabled={isSubmitting}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="listing-slug">Slug *</Label>
                  <Input
                    id="listing-slug"
                    value={listingData.slug}
                    onChange={(e) => setListingData({ ...listingData, slug: e.target.value })}
                    placeholder="product-slug"
                    required
                    disabled={isSubmitting}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="listing-description">Description</Label>
                <Textarea
                  id="listing-description"
                  value={listingData.description}
                  onChange={(e) => setListingData({ ...listingData, description: e.target.value })}
                  placeholder="Describe your product"
                  disabled={isSubmitting}
                  rows={3}
                />
              </div>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="listing-price">Price *</Label>
                  <Input
                    id="listing-price"
                    type="number"
                    step="0.01"
                    min="0"
                    value={listingData.price}
                    onChange={(e) => setListingData({ ...listingData, price: e.target.value })}
                    placeholder="99.99"
                    required
                    disabled={isSubmitting}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="listing-vendor">Vendor *</Label>
                  <Select
                    value={listingData.vendorId}
                    onValueChange={(value) => setListingData({ ...listingData, vendorId: value })}
                    disabled={isSubmitting}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select vendor" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Select vendor</SelectItem>
                      {vendors.map((vendor) => (
                        <SelectItem key={vendor.id} value={vendor.id}>
                          {vendor.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="listing-category">Category</Label>
                <Select
                  value={listingData.categoryId}
                  onValueChange={(value) => setListingData({ ...listingData, categoryId: value })}
                  disabled={isSubmitting}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">No category</SelectItem>
                    {categories.map((cat) => (
                      <SelectItem key={cat.id} value={cat.id}>
                        {cat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsListingDialogOpen(false)}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? 'Creating...' : 'Create Listing'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  )
}
